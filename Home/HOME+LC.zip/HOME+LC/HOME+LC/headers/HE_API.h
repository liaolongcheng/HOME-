//
//  HE_API.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-20.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#ifndef HOME_LC_HE_API_h
#define HOME_LC_HE_API_h

#define BASEURL @"http://121.199.31.154:3000"
#define BASEURL_IMAGE @"http://121.199.31.154:3000/images/"

#define EN @"en"
#define ORDER_BY_PUBLISH_TIME @"publishDate"
#define ORDER_BY_PUBLISH_TIME_DESC @"-publishDate"
#define ORDER_BY_STAR @"score"
#define ORDER_BY_STAR_DESC @"-score"

//关于房子的方法
#define HOUSE @"house"
//用户
#define USER @"user"


//登陆接口
#define LOING @"/users/login.json"
//注册接口
#define REGISTER @"/users/register.json"
#define USER_INFO_UPDATE @"/users/info.json"

//查看房源搜藏列表
#define LIST_FAVOUR_HOUSE @"/house/favorites.json"
//查看中介收藏列表
#define LIST_FAVOURITE_AGENT @"/agent/favorites.json"

//收藏中介
#define ADD_FAVOURITE_AGENT @"agent/favorite"
//所有联系过的房源
#define ALL_CONTACT_HOUSE @"/house/viewHistories.json"
//给房子打分
#define SEND_GREAD_HOUSE @"/house/grade"
//将当前房源添加到联系人
#define ADD_CURRENT_HOUSE_TO_CONTACT @"house/viewHistories"

//发送站内消息
#define SEND_MESSAGE @"/message/new.json"
//获取站内消息
#define LIST_RECEIVE_MSGS_URL @"/messages.json"
//删除收到的消息
#define DELETE_MESSAGE_RECEIVED @"/messages/delete/received.json"
//查看自己已经发送的站内信列表
#define LIST_SENT_MESSAGE @"/messages/sent.json"
//删除发送的消息
#define DELETE_MESSAGE_SENT @"/messages/delete/sent.json"


//发布房源
#define POST_HOUSE @"http://121.199.31.154:3000/houses/publish.json"
//查看自己收到的打分记录
#define AGENT_GREAD @"/agent/gradeList"
#define AGENT_SENT_GREAD @"/gradeList/sent.json"


#define INITURL(url) [NSString stringWithFormat:@"%@%@",BASEURL,url]
//floor/totalfloor


#endif
