//
//  HE_GlobalMacros.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-15.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#ifndef HOME_LC_HE_GlobalMacros_h
#define HOME_LC_HE_GlobalMacros_h

//写DLog
#ifdef DEBUG
//# define DLog(fmt, ...) NSLog((@"[文件名:%s]\n" "[函数名:%s]\n" "[行号:%d] \n" fmt), __FILE__, __FUNCTION__, __LINE__, ##__VA_ARGS__);
# define DLog(fmt, ...) NSLog((@"[%s->Line:%d->Content--->\n" fmt), __FUNCTION__, __LINE__, ##__VA_ARGS__);
#else
# define DLog(...);
#endif

//#ifdef DEBUG
//#define DLog(...) NSLog(__VA_ARGS__);
//#define DLog_METHOD NSLog(@"%s",__func__);
//#else
//#define DLog(...);
//#define DLog_METHOD;
//#endif


/*
 
  接口 host http://121.199.31.154:3000
 
 */

/**状态栏高度*/
#define STATUSBAR_HEIGHT 20
/**工具栏高度*/
#define TABBAR_HEIGHT 70
/**导航栏高度*/
#define NAVIGATIONBAR_HEIGHT 44
/**是否是iOS7或者以上*/
#define IS_SYSTEM_VERSION_MORE_THAN_SEVEN [[UIDevice currentDevice].systemVersion hasPrefix:@"7"]

/** rgb颜色转换（16进制->10进制）*/
#define UIColorFromRGB(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]

/**带有RGBA的颜色设置*/
#define COLOR(R, G, B, A) [UIColor colorWithRed:R/255.0 green:G/255.0 blue:B/255.0 alpha:A]

/** 获取RGB颜色*/
#define RGBA(r,g,b,a) [UIColor colorWithRed:r/255.0f green:g/255.0f blue:b/255.0f alpha:a]

/**windows对象*/
#define KEY_WINDOW  [[UIApplication sharedApplication] keyWindow]
#define ROOTVIEWCONTROLLER [[[UIApplication sharedApplication] keyWindow] rootViewController]
///**appdelegate*/
//#define BH_APPDELEGATE  (AppDelegate *)[[UIApplication sharedApplication] delegate]
//#define BH_PARENTCONTEXT ((AppDelegate *)[[UIApplication sharedApplication] delegate]).cdh.parentContext
//#define BH_CONTEXT ((AppDelegate *)[[UIApplication sharedApplication] delegate]).cdh.context
//#define BH_COREDATAHELPER ((AppDelegate *)[[UIApplication sharedApplication] delegate]).coreDataHelper
/**屏幕 宽高*/
#define SCREEN_WIDTH [[UIScreen mainScreen]bounds].size.width
#define SCREEN_HEIGHT [[UIScreen mainScreen]bounds].size.height

#define VIEW_WIDTH(aa) aa.frame.size.width
#define VIEW_HEIGHT(aa) aa.frame.size.height

/**程序主体颜色值*/
#define APP_COLOR RGBA(213, 36, 64, 1)

/**失去第一响应者*/
#define RESIGNFIRSTRESPONDER [[UIApplication sharedApplication].keyWindow endEditing:YES]

/**得到字符串的像素矩阵*/
#define GET_TEXT_SIZE(string,font) [UIDevice currentDevice].systemVersion.floatValue>=7.0?[string boundingRectWithSize:CGSizeMake(320, 150) options: NSStringDrawingTruncatesLastVisibleLine | NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading attributes:attribute context:nil]:[string sizeWithFont:[UIFont systemFontOfSize:font]]

/**获取MAINBUNDLE*/
#define MAIN_BUNDLE [NSBundle mainBundle]
/**获取bundle文件路径*/
#define LOAD_BANDLE_FILE(filename,extension) [[NSBundle mainBundle] pathForResource:filename ofType:extension]

/**读取单nib文件*/
#define LOAD_TABLEVIEWCELL(nibName) [[NSBundle mainBundle] loadNibNamed:nibName owner:nil options:nil][0]

/**加载图片  内存*/
#define LOAD_IMAGE(string) [UIImage imageNamed:string]
/**加载图片  从文件加载*/
#define LOAD_IMAGE_WITH_FILE(path) [UIImage imageWithContentsOfFile:path]




/**字体*/
#define FONT(x) [UIFont fontWithName:@"Arial" size:x]

/**弹出AlterView*/
#define BH_ALERT(msg)  [[[UIAlertView alloc]initWithTitle:@"系统提示" message:msg delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil] show]


/**设置数组值.*/
#define BH_SET_ARRAY(_arrayWith__,tempArray) _arrayWith__ = [NSArray arrayWithArray:tempArray]
#define BH_SET_MUTABLEARRAY(_arrayWith__,tempArray) _arrayWith__ = [NSMutableArray arrayWithArray:tempArray]
/**判断数组数量是否为空*/
#define ARRAY_COUNT_IS_NOT_ZERO(array) [array count] == 0 ? NO : YES
/**判断一个对象是否为nil*/
#define IS_NOT_NIL(class) class ? YES : NO


/**Documents路径*/
#define APP_DOCUMENTS_PATH  [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject]


//
/**用于指定图片上部和左边不缩放的像素*/
#define IMAGE_STRRTCHABLE(img,left,top) [img stretchableImageWithLeftCapWidth:left topCapHeight:top]


#define LONGITUDE @"121.48239"
#define LATITUDE @"31.22213"


#define DEFAULTIMAGE [UIImage imageNamed:@"icon72.png"]
#define INITOBJECT(name) [[name alloc] init]
#define IS_KONG_STRING(str) [str isEqualToString:@""]

#define USER_ISLOGIN [[HEUserLogin sharedLogin] isLogin]

//构建图片url
#define IMAGEURLCREATE(str) [NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BASEURL_IMAGE,str]]

#define TOST_SHOW(str) [HETost showTost:str]


#define POST_URL_LOG NSLog(@"POST_URL:   %@",[[NSString stringWithString:mutableRequest.URL.absoluteString] stringByAppendingString:query]); 

#define CHANGE_RATA @"CHANGERATA"

#endif
