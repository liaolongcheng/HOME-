//
//  HEUserLogin.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-21.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEUserLogin.h"

@implementation HEUserLogin

+(instancetype)sharedLogin
{
    static HEUserLogin *login;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        login=[[HEUserLogin alloc] init];
    });
    return login;
}
-(void)login:(void (^)())logSuccess :(void(^)())error
{
    [HttpHelper POST:INITURL(LOING) parameters:@{@"phone":self.phone,@"pass":self.passWord} svText:@"正在登陆..." errorsvText:@"登陆失败..." svMarkType:SVProgressHUDMaskTypeNone success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        //c99be4f351167b94d8ff8b9fd3e897e1
        DLog(@"登陆成功");
        _v=responseObject[@"__v"];
        _userId=responseObject[@"_id"];
        _access_token=responseObject[@"access_token"];
        _address=responseObject[@"address"];
        _company=responseObject[@"company"];
        _email=responseObject[@"email"];
        _level=responseObject[@"level"];
        _name=responseObject[@"name"];
        _phone=responseObject[@"phone"];
        _points=responseObject[@"points"];
        _profile_image=responseObject[@"profile_image"];
        _registerDate=responseObject[@"registerDate"];
        _type=responseObject[@"type"];
        logSuccess();
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [SVProgressHUD showErrorWithStatus:@"登陆失败..." duration:0.5];
    }];
    
    //15678261759_photo.jpg
}
-(BOOL)isLogin
{
    HEUserLogin *login=[[self class] sharedLogin];
    if (login.access_token)
    {
        return YES;
    }
    else
    {
        return NO;
    }
}

@end
