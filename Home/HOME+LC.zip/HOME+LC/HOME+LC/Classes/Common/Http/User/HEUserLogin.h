//
//  HEUserLogin.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-21.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HEUserLogin : NSObject

+(instancetype) sharedLogin;

//登录
-(void) login:(void(^)())logSuccess :(void(^)())error;
-(BOOL) isLogin;

@property (nonatomic,strong) NSString *phone;
@property (nonatomic,strong) NSString *passWord;
@property (nonatomic,strong) NSString *v;
@property (nonatomic,strong) NSString *access_token;
@property (nonatomic,strong) NSString *userId;
@property (nonatomic,strong) NSString *address;
@property (nonatomic,strong) NSString *company;
@property (nonatomic,strong) NSString *email;
@property (nonatomic,strong) NSString *level;
@property (nonatomic,strong) NSString *name;
@property (nonatomic,strong) NSString *points;
@property (nonatomic,strong) NSString *profile_image;
@property (nonatomic,strong) NSString *registerDate;
@property (nonatomic,strong) NSString *type;

@end
