//
//  HEAgentInfo.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-29.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HEAgentInfo : NSObject

@property (nonatomic,strong) NSString *publisherId;
@property (nonatomic,assign) NSInteger page;

@property (nonatomic,strong) NSString *houseId;

//得到中介详细信息
-(void)requestAgentInfoWith:(void (^)(id response))successBlock errorBlock:(void (^)())errorBlock;

//获取收藏的中介信息
-(void) requestFavouriteAgentWith:(void (^)(id response))successBlock errorBlock:(void (^)())errorBlock svType:(SVProgressHUDMaskType)svType;

//添加中介到当前用户
-(void) addAgentToFavourite:(void (^)(id response))successBlock errorBlock:(void (^)())errorBlock;

//删除收藏的中介
-(void) removeAgentFromFavourite:(void (^)(id response))successBlock errorBlock:(void (^)())errorBlock;

//将当前浏览房源添加到当前用户联系人中
-(void) addContactToCurrentUser:(void (^)(id response))successBlock errorBlock:(void (^)())errorBlock;

//查看自己收到的打分记录
-(void) requestAgentGread:(void (^)(id response))successBlock errorBlock:(void (^)())errorBlock svType:(SVProgressHUDMaskType) svType;

//查看自己的打分记录
-(void) requestAgentSentGread:(void (^)(id response))successBlock errorBlock:(void (^)())errorBlock svType:(SVProgressHUDMaskType) svType;


@end
