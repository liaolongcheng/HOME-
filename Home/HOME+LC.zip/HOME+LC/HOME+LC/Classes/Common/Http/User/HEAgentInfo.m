//
//  HEAgentInfo.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-29.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEAgentInfo.h"

@implementation HEAgentInfo

-(void)requestAgentInfoWith:(void (^)(id response))successBlock errorBlock:(void (^)())errorBlock
{
    
    NSString *urlString = [NSString stringWithFormat:@"%@/%@/%@/%@.json",BASEURL,USER,EN,self.publisherId];
    [HttpHelper GET:urlString parameters:nil svText:@"正在加载...." errorsvText:@"加载出错了..." svMarkType:SVProgressHUDMaskTypeNone success:^(AFHTTPRequestOperation *operation, id responseObject) {

        if (successBlock) {
            successBlock(responseObject);
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        if (errorBlock) {
            errorBlock();
        }
    }];
}

-(void)requestFavouriteAgentWith:(void (^)(id))successBlock errorBlock:(void (^)())errorBlock svType:(SVProgressHUDMaskType)svType
{
    NSString *urlString=[NSString stringWithFormat:@"%@%@?access_token=%@&page=%d",BASEURL,LIST_FAVOURITE_AGENT,[HEUserLogin sharedLogin].access_token,self.page];
    
    [HttpHelper GET:urlString parameters:nil svText:@"加载中..." errorsvText:@"获取中介列表失败..." svMarkType:svType success:^(AFHTTPRequestOperation *operation, id responseObject) {
        if (successBlock) {
            successBlock(responseObject);
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        if (errorBlock) {
            errorBlock();
        }
    }];
    
}

-(void)addAgentToFavourite:(void (^)(id))successBlock errorBlock:(void (^)())errorBlock
{
    NSString *urlString = [NSString stringWithFormat:@"%@/%@/%@.json",BASEURL,ADD_FAVOURITE_AGENT,self.publisherId];
    
    [HttpHelper POST:urlString parameters:@{@"access_token":[HEUserLogin sharedLogin].access_token} svText:@"正在请求..." errorsvText:@"收藏失败..." svMarkType:SVProgressHUDMaskTypeNil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        if (successBlock) {
            successBlock(responseObject);
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        if (errorBlock) {
            errorBlock();
        }
    }];
}
-(void)removeAgentFromFavourite:(void (^)(id))successBlock errorBlock:(void (^)())errorBlock
{
    NSString *urlString=[NSString stringWithFormat:@"%@/agent/favorite/%@.json?access_token=%@",BASEURL,self.publisherId,[HEUserLogin sharedLogin].access_token];
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager DELETE:urlString parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        if (successBlock) {
            successBlock(responseObject);
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        if (errorBlock) {
            errorBlock();
        }
    }];
}

-(void)addContactToCurrentUser:(void (^)(id))successBlock errorBlock:(void (^)())errorBlock
{
    NSString *urlString = [NSString stringWithFormat:@"%@/%@/%@.json",BASEURL,ADD_CURRENT_HOUSE_TO_CONTACT,self.houseId];
    
    [HttpHelper POST:urlString parameters:@{@"access_token":[HEUserLogin sharedLogin].access_token} svText:@"正在请求..." errorsvText:@"请求出错..." svMarkType:SVProgressHUDMaskTypeNil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        if (successBlock) {
            successBlock(responseObject);
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        if (errorBlock) {
            errorBlock();
        }

    }];
    
}

-(void) requestAgentGread:(void (^)(id response))successBlock errorBlock:(void (^)())errorBlock svType:(SVProgressHUDMaskType) svType
{
    NSString *urlString = [NSString stringWithFormat:@"%@%@/%@.json",BASEURL,AGENT_GREAD,self.publisherId];
   
    [HttpHelper GET:urlString parameters:Nil svText:@"正在加载..." errorsvText:@"加载出错..." svMarkType:svType success:^(AFHTTPRequestOperation *operation, id responseObject) {
        if (successBlock) {
            successBlock(responseObject);
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        if (errorBlock) {
            errorBlock();
        }

    }];
}
-(void)requestAgentSentGread:(void (^)(id))successBlock errorBlock:(void (^)())errorBlock svType:(SVProgressHUDMaskType)svType
{
    NSString *urlString = [NSString stringWithFormat:@"%@%@?access_token=%@&page=0",BASEURL,AGENT_SENT_GREAD,[HEUserLogin sharedLogin].access_token];
    [HttpHelper GET:urlString parameters:nil svText:@"正在请求..." errorsvText:@"请求出错..." svMarkType:svType success:^(AFHTTPRequestOperation *operation, id responseObject) {
        if (successBlock) {
            successBlock(responseObject);
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        if (errorBlock) {
            errorBlock();
        }
    }];
}

@end
