//
//  HEUserRegister.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-26.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//
typedef void(^registerSuccess)(id successObject);
typedef void(^registerError)();

#import <Foundation/Foundation.h>

@interface HEUserRegister : NSObject

@property (nonatomic,strong) NSString *phone;
@property (nonatomic,strong) NSString *name;
@property (nonatomic,strong) NSString *pass;
@property (nonatomic,strong) NSString *address;
@property (nonatomic,strong) NSString *company;
@property (nonatomic,strong) NSData *profile_image;
@property (nonatomic,strong) NSString *type;
@property (nonatomic,strong) NSString *token;
@property (nonatomic,strong) NSString *email;

+(instancetype) sharedRegister;
//用户注册
-(void)resiterUserWithSuccess:(registerSuccess) success registerError:(registerError) registerError;

//修改用户资料
-(void) updateUserInfoWithSuccess:(registerSuccess) success registerError:(registerError) registerError;

@end
