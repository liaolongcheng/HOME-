//
//  HEUserRegister.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-26.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEUserRegister.h"

@implementation HEUserRegister

+(instancetype)sharedRegister
{
    static HEUserRegister *registerObj=Nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        registerObj = [[HEUserRegister alloc] init];
    });
    return registerObj;
}
-(void)resiterUserWithSuccess:(registerSuccess)success registerError:(registerError)registerError
{
    HEUserRegister *registerObj=[[self class] sharedRegister];
    
    NSMutableDictionary *dic=[@{@"phone":registerObj.phone,@"name":registerObj.name,@"pass":self.pass,@"type":self.type,@"email":registerObj.email} mutableCopy];
 
    NSString *myType=[[HEUserRegister sharedRegister] type];
    if ([myType isEqualToString:@"seller"])
    {
        [dic setObject:self.address forKey:@"address"];
        [dic setObject:self.company forKey:@"company"];
    }
    [SVProgressHUD showWithStatus:@"正在请求..." maskType:SVProgressHUDMaskTypeClear clicType:SVProgressHUDClickDefult];
    
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager POST:INITURL(REGISTER) parameters:dic constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
       
        if ([[[self class] sharedRegister] profile_image])
        {
            [formData appendPartWithFileData:self.profile_image name:@"profile_image" fileName:@"photo.jpg" mimeType:@"image/jpeg"];
        }
        
    } success:^(AFHTTPRequestOperation *operation, id responseObject) {
        success(@{@"phone":responseObject[@"phone"],@"pass":self.pass});
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        registerError();
    }];
}

-(void)updateUserInfoWithSuccess:(registerSuccess)success registerError:(registerError)registerError
{
    HEUserRegister *registerObj=[[self class] sharedRegister];
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
    if (registerObj.phone)
    {
        [dic setObject:registerObj.phone forKey:@"phone"];
    }
    if (registerObj.name)
    {
        [dic setObject:registerObj.name forKey:@"name"];
    }
    if (registerObj.pass)
    {
        [dic setObject:registerObj.pass forKey:@"pass"];
    }
    if (registerObj.type)
    {
        [dic setObject:registerObj.type forKey:@"type"];
    }
    [dic setObject:[HEUserLogin sharedLogin].access_token forKey:@"access_token"];
 
    
    NSString *myType=[[HEUserRegister sharedRegister] type];
    if ([myType isEqualToString:@"seller"])
    {
        if (registerObj.address)
        {
            [dic setObject:registerObj.address forKey:@"address"];
        }
        if (registerObj.company)
        {
            [dic setObject:registerObj.company forKey:@"company"];
        }
        
    }
    [SVProgressHUD showWithStatus:@"正在请求..." maskType:SVProgressHUDMaskTypeClear clicType:SVProgressHUDClickDefult];
    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager POST:INITURL(USER_INFO_UPDATE) parameters:dic constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
      
        if ([[[self class] sharedRegister] profile_image])
        {
            [formData appendPartWithFileData:self.profile_image name:@"profile_image" fileName:@"photo.jpg" mimeType:@"image/jpeg"];
        }
    } success:^(AFHTTPRequestOperation *operation, id responseObject) {
        success(responseObject);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        registerError();
    }];
    
}
@end
