//
//  HEMessage.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-6-1.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEMessage.h"

@implementation HEMessage

-(void)sendMessageToUser:(void (^)(id))successBlock error:(void (^)())errorBlock
{
    NSString *urlString=[NSString stringWithFormat:@"%@%@",BASEURL,SEND_MESSAGE];
    
    [HttpHelper POST:urlString parameters:@{@"to":self.toUserId,@"message":self.messageContent,@"access_token":[HEUserLogin sharedLogin].access_token} svText:@"正在发送..." errorsvText:@"发送失败..." svMarkType:SVProgressHUDMaskTypeClear success:^(AFHTTPRequestOperation *operation, id responseObject) {
        if (successBlock) {
            successBlock(responseObject);
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        if (errorBlock) {
            errorBlock();
        }
    }];
}

-(void)requestZanMessage:(void (^)(id))successBlock error:(void (^)())errorBlock svType:(SVProgressHUDMaskType)svType
{
    NSString *urlString = [NSString stringWithFormat:@"%@%@?access_token=%@",BASEURL,LIST_RECEIVE_MSGS_URL,[HEUserLogin sharedLogin].access_token];
    
    [HttpHelper GET:urlString parameters:nil svText:@"正在请求..." errorsvText:@"请求出错..." svMarkType:svType success:^(AFHTTPRequestOperation *operation, id responseObject) {
        if (successBlock) {
            successBlock(responseObject);
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        if (errorBlock) {
            errorBlock();
        }
    }];
}
-(void)deleteMessageFromReceived:(void (^)(id))successBlock error:(void (^)())errorBlock svType:(SVProgressHUDMaskType)svType
{
    NSString *urlString=[NSString stringWithFormat:@"%@%@",BASEURL,DELETE_MESSAGE_RECEIVED];
    
    [HttpHelper POST:urlString parameters:@{@"messages":self.messagesIds,@"access_token":[HEUserLogin sharedLogin].access_token} svText:@"正在请求..." errorsvText:@"请求失败..." svMarkType:svType success:^(AFHTTPRequestOperation *operation, id responseObject) {
        [SVProgressHUD showSuccessWithStatus:@"删除成功..." duration:1.0];
        if (successBlock) {
            successBlock(responseObject);
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        if (errorBlock) {
            errorBlock();
        }
    }];
    
}

-(void)requestSentMessage:(void(^)(id responesObject)) successBlock error:(void(^)())errorBlock svType:(SVProgressHUDMaskType)svType
{
    NSString *urlString=[NSString stringWithFormat:@"%@%@?access_token=%@&page=%@",BASEURL,LIST_SENT_MESSAGE,[HEUserLogin sharedLogin].access_token,[NSString stringWithFormat:@"%d",self.page]];
    [HttpHelper GET:urlString parameters:nil svText:@"正在请求..." errorsvText:@"请求出错" svMarkType:svType success:^(AFHTTPRequestOperation *operation, id responseObject) {
        if (successBlock) {
            successBlock(responseObject);
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        if (errorBlock) {
            errorBlock();
        }
    }];
}

-(void)deleteMessageToSent:(void (^)(id))successBlock error:(void (^)())errorBlock svType:(SVProgressHUDMaskType)svType
{
    NSString *urlString = [NSString stringWithFormat:@"%@%@",BASEURL,DELETE_MESSAGE_SENT];
    [HttpHelper POST:urlString parameters:@{@"messages":self.messagesIds,@"access_token":[HEUserLogin sharedLogin].access_token} svText:@"正在请求..." errorsvText:@"请求出错..." svMarkType:svType success:^(AFHTTPRequestOperation *operation, id responseObject) {
        [SVProgressHUD showSuccessWithStatus:@"删除成功..." duration:1.0];
        if (successBlock) {
            successBlock(responseObject);
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        if (errorBlock) {
            errorBlock();
        }

    }];
}

@end
