//
//  HEMessage.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-6-1.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HEMessage : NSObject
@property (nonatomic,strong) NSString *toUserId;
@property (nonatomic,strong) NSString *messageContent;

@property (nonatomic,strong) NSString *messagesIds;

@property (nonatomic,assign) int page;

//发送站内消息
-(void) sendMessageToUser:(void(^)(id responesObject)) successBlock error:(void(^)())errorBlock;
//获取站内消息
-(void) requestZanMessage:(void(^)(id responesObject)) successBlock error:(void(^)())errorBlock svType:(SVProgressHUDMaskType)svType;

//删除收到的消息
-(void)deleteMessageFromReceived:(void(^)(id responesObject)) successBlock error:(void(^)())errorBlock svType:(SVProgressHUDMaskType)svType;
//获取当前用户站内已发送的站内信列表
-(void)requestSentMessage:(void(^)(id responesObject)) successBlock error:(void(^)())errorBlock svType:(SVProgressHUDMaskType)svType;
//删除站内发送的消息
-(void)deleteMessageToSent:(void(^)(id responesObject)) successBlock error:(void(^)())errorBlock svType:(SVProgressHUDMaskType)svType;



@end
