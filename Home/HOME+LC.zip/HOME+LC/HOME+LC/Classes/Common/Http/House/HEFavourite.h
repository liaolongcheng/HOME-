//
//  HEFavourite.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-27.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HEFavourite : NSObject

@property (nonatomic,assign) NSInteger page;

@property (nonatomic,assign) NSString *houseId;

//获取收藏房子的列表
-(void) retrievalFavoureteHouse:(void(^)(id responesObject))reteriealSuccess reteriealError:(void(^)())reteriealError svType:(SVProgressHUDMaskType) svType;

//将房子添加到收藏
-(void) addHouseToFavourite:(void(^)(id responesObject))reteriealSuccess reteriealError:(void(^)())reteriealError svType:(SVProgressHUDMaskType) svType;

//将房子从收藏中删除
-(void) removeHouseFromFavourite:(void(^)(id responesObject))reteriealSuccess reteriealError:(void(^)())reteriealError svType:(SVProgressHUDMaskType) svType;

@end
