//
//  HEHouseInfo.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-27.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HEHouseInfo : NSObject

@property (nonatomic,strong) NSString *houseId;
@property (nonatomic,assign) NSInteger page;
@property (nonatomic,assign) NSInteger score;
@property (nonatomic,strong) NSString *content;
@property (nonatomic,strong) NSString *publisherId;

@property (nonatomic,strong) NSString *nameZH;
@property (nonatomic,strong) NSString *nameEN;
@property (nonatomic,strong) NSString *houseType;
@property (nonatomic,assign) int floor;
@property (nonatomic,assign) int totalFloor;
@property (nonatomic,strong) NSString *longitude;
@property (nonatomic,strong) NSString *latitude;
@property (nonatomic,strong) NSString *area;
@property (nonatomic,strong) NSString *metro;
@property (nonatomic,strong) NSString *descriptionZH;
@property (nonatomic,strong) NSString *descriptionEN;
@property (nonatomic,strong) NSString *address;
@property (nonatomic,strong) NSString *price;
@property (nonatomic,assign) BOOL outspace;
@property (nonatomic,strong) NSString *size;
@property (nonatomic,assign) BOOL share;
@property (nonatomic,strong) NSString *bedrooms;
@property (nonatomic,strong) NSString *bathrooms;
@property (nonatomic,strong) NSString *livingrooms;
@property (nonatomic,strong) NSArray *housePhotos;


//得到房子的详细信息
-(void) requestHouseInfoWithSuccess:(void(^)(id houseInfo)) success requestError:(void(^)()) requestError;

//查看所有联系过的房源
-(void) requestAllContactHouseWith:(void(^)(id houseInfo)) success requestError:(void(^)()) requestError svType:(SVProgressHUDMaskType)svType;

//给房子打分
-(void) sendGreadToHouse:(void(^)(id houseInfo)) success requestError:(void(^)()) requestError svType:(SVProgressHUDMaskType)svType;

//发布一个房子
-(void) postHouse:(void(^)(id houseInfo)) success requestError:(void(^)()) requestError svType:(SVProgressHUDMaskType)svType;

//查看当前用户已经发布的房源
-(void) requestCurrentUserPostHouse:(void(^)(id houseInfo)) success requestError:(void(^)()) requestError svType:(SVProgressHUDMaskType)svType;

//删除当前用户发布的房源
-(void) deleteHouseForCurrentUser:(void(^)(id houseInfo)) success requestError:(void(^)()) requestError svType:(SVProgressHUDMaskType)svType;

//修改房源信息
-(void)updateHouseForCurrentUser:(void(^)(id houseInfo)) success requestError:(void(^)()) requestError svType:(SVProgressHUDMaskType)svType;


@end
