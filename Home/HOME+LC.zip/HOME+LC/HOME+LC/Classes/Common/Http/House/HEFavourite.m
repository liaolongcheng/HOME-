//
//  HEFavourite.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-27.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEFavourite.h"
#import "HEUserLogin.h"
#import "HEUserLogin.h"

@implementation HEFavourite

-(void)retrievalFavoureteHouse:(void (^)(id))reteriealSuccess reteriealError:(void (^)())reteriealError svType:(SVProgressHUDMaskType)svType
{
    NSString *urlString=[NSString stringWithFormat:@"%@%@?access_token=%@&page=%ld",BASEURL,LIST_FAVOUR_HOUSE,[HEUserLogin sharedLogin].access_token,(long)self.page];
    
    [HttpHelper GET:urlString parameters:nil svText:@"加载中...." errorsvText:@"加载出错..." svMarkType:svType success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        if (reteriealSuccess)
        {
            reteriealSuccess(responseObject);
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        if (reteriealError)
        {
            reteriealError();
        }
    }];
}
-(void)addHouseToFavourite:(void (^)(id))reteriealSuccess reteriealError:(void (^)())reteriealError svType:(SVProgressHUDMaskType)svType
{
    //favorite/house
    NSString *urlString=[NSString stringWithFormat:@"%@/%@/favorite/%@.json",BASEURL,HOUSE,self.houseId];
    [HttpHelper POST:urlString parameters:@{@"access_token":[HEUserLogin sharedLogin].access_token} svText:@"正在加载..." errorsvText:@"添加收藏失败..." svMarkType:svType success:^(AFHTTPRequestOperation *operation, id responseObject) {
        if (reteriealSuccess)
        {
            reteriealSuccess(responseObject);
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
       
        if (reteriealError) {
            reteriealError();
        }
    }];
}

-(void)removeHouseFromFavourite:(void (^)(id))reteriealSuccess reteriealError:(void (^)())reteriealError svType:(SVProgressHUDMaskType)svType
{
    NSString *urlString=[NSString stringWithFormat:@"%@/%@/favorite/%@.json?access_token=%@",BASEURL,HOUSE,self.houseId,[HEUserLogin sharedLogin].access_token];

    AFHTTPRequestOperationManager *manager=[AFHTTPRequestOperationManager manager];
    [manager DELETE:urlString parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        if (reteriealSuccess)
        {
            reteriealSuccess(responseObject);
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        if (reteriealError) {
            reteriealError();
        }

    }];
}
@end
