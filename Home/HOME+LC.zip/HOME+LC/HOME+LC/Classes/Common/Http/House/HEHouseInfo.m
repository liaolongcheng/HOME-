//
//  HEHouseInfo.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-27.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEHouseInfo.h"

@implementation HEHouseInfo


-(void) requestHouseInfoWithSuccess:(void(^)(id houseInfo)) success requestError:(void(^)()) requestError
{
    NSString *urlString = [NSString stringWithFormat:@"%@/%@/%@/%@.json",BASEURL,HOUSE,EN,self.houseId];
    
    [HttpHelper GET:urlString parameters:nil svText:@"加载中..." errorsvText:@"加载失败..." svMarkType:SVProgressHUDMaskTypeClear success:^(AFHTTPRequestOperation *operation, id responseObject) {
        if (success) {
            success(responseObject);
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        if (requestError)
        {
            requestError();
        }
    }];
    
}
-(void)requestAllContactHouseWith:(void (^)(id))success requestError:(void (^)())requestError svType:(SVProgressHUDMaskType)svType
{
    NSString *urlString=[NSString stringWithFormat:@"%@%@?access_token=%@&page=%d",BASEURL,ALL_CONTACT_HOUSE,[HEUserLogin sharedLogin].access_token,self.page];
    [HttpHelper GET:urlString parameters:nil svText:@"加载中..." errorsvText:@"加载失败..." svMarkType:svType success:^(AFHTTPRequestOperation *operation, id responseObject) {
        if (success) {
            success(responseObject);
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        if (requestError)
        {
            requestError();
        }
    }];
}
-(void)sendGreadToHouse:(void (^)(id))success requestError:(void (^)())requestError svType:(SVProgressHUDMaskType)svType
{
    NSString *str=[NSString stringWithFormat:@"%@%@/%@.json",BASEURL,SEND_GREAD_HOUSE,self.houseId];
   
    [HttpHelper POST:str parameters:@{@"score":@"1",@"publisher":self.publisherId,@"access_token":[HEUserLogin sharedLogin].access_token} svText:@"正在加载..." errorsvText:@"加载出错..." svMarkType:svType success:^(AFHTTPRequestOperation *operation, id responseObject)
    {
        if (success)
        {
            success(responseObject);
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        if (requestError)
        {
            requestError();
        }
    }];
}

-(void)postHouse:(void (^)(id))success requestError:(void (^)())requestError svType:(SVProgressHUDMaskType)svType
{

    NSMutableDictionary *parDic=[[NSMutableDictionary alloc] init];
    
   
    if (self.nameZH)
    {
        [parDic setObject:self.nameZH forKey:@"name_zh"];
    }
    [parDic setObject:self.nameEN forKey:@"name_en"];
    if (self.houseType)
    {
        [parDic setObject:self.houseType forKey:@"houseType"];
    }
    [parDic setObject:[NSString stringWithFormat:@"%d",self.floor] forKey:@"floor"];
    [parDic setObject:[NSString stringWithFormat:@"%d",self.totalFloor] forKey:@"totalFloor"];
    [parDic setObject:self.longitude forKey:@"longitude"];
    [parDic setObject:self.latitude forKey:@"latitude"];
    [parDic setObject:self.area forKey:@"area"];
    [parDic setObject:self.metro forKey:@"metro"];
    if (self.descriptionZH)
    {
        [parDic setObject:self.descriptionZH forKey:@"description_zh"];
    }
    [parDic setObject:self.descriptionEN forKey:@"description_en"];
    [parDic setObject:self.address forKey:@"address"];
    [parDic setObject:self.price forKey:@"price"];
    [parDic setObject:self.outspace == YES ? @"true":@"false" forKey:@"outspace"];
    [parDic setObject:self.size forKey:@"size"];
    [parDic setObject:self.share == YES ? @"true":@"false" forKey:@"share"];
    [parDic setObject:self.bedrooms forKey:@"bedrooms"];
    [parDic setObject:self.bathrooms forKey:@"bathrooms"];
    [parDic setObject:self.livingrooms forKey:@"livingrooms"];
    [parDic setObject:[HEUserLogin sharedLogin].access_token forKey:@"access_token"];
    if (self.houseType)
    {
        [parDic setObject:self.houseType forKey:@"houseType"];
    }
    
    [SVProgressHUD showWithStatus:@"正在加载..." maskType:svType clicType:SVProgressHUDClickDefult];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager POST:POST_HOUSE parameters:parDic constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        int i=0;
        for (UIImage *image in self.housePhotos)
        {
            [formData appendPartWithFileData:UIImageJPEGRepresentation(image, 1.0) name:[NSString stringWithFormat:@"file%d",i] fileName:[NSString stringWithFormat:@"photo%d.jpg",i] mimeType:@"image/jpeg"];
            i++;
        }
        
    } success:^(AFHTTPRequestOperation *operation, id responseObject) {
        [SVProgressHUD showSuccessWithStatus:@"post house success" duration:1.0];
        if (success)
        {
            //875627
            success(responseObject);
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [SVProgressHUD dismiss];
        
        if (requestError)
        {
            requestError();
        }
    }];
}

-(void)requestCurrentUserPostHouse:(void (^)(id))success requestError:(void (^)())requestError svType:(SVProgressHUDMaskType)svType
{
    //http://121.199.31.154:3000/houses/en/-publishDate/0.json?publisher=13678261759
    NSString *urlString = [NSString stringWithFormat:@"%@/houses/en/-publishDate/0.json?publisher=%@",BASEURL,self.publisherId];
    
    [HttpHelper GET:urlString parameters:nil svText:@"正在加载...." errorsvText:@"加载失败..." svMarkType:svType success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        if (success)
        {
            success(responseObject);
        }

    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        if (requestError)
        {
            requestError();
        }

    }];
    
}

-(void)deleteHouseForCurrentUser:(void (^)(id))success requestError:(void (^)())requestError svType:(SVProgressHUDMaskType)svType
{
    NSString *urlString = [NSString stringWithFormat:@"%@/houses/%@.json?access_token=%@",BASEURL,self.houseId,[HEUserLogin sharedLogin].access_token];
    
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [SVProgressHUD showWithStatus:@"正在请求..." maskType:SVProgressHUDMaskTypeClear clicType:SVProgressHUDClickDefult];
    [manager DELETE:urlString parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        [SVProgressHUD showSuccessWithStatus:@"删除成功..." duration:1.0];
        if (success)
        {
            success(responseObject);
        }

    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        [SVProgressHUD showErrorWithStatus:@"删除失败..." duration:1.0];
        if (requestError)
        {
            requestError();
        }
    }];
    
    
}

-(void)updateHouseForCurrentUser:(void (^)(id))success requestError:(void (^)())requestError svType:(SVProgressHUDMaskType)svType
{
    NSString *urlString = [NSString stringWithFormat:@"%@/houses/%@.json",BASEURL,self.houseId];
    
    NSMutableDictionary *parDic = [[NSMutableDictionary alloc] init];
  
    if (self.nameZH)
    {
        [parDic setObject:self.nameZH forKey:@"name_zh"];
    }
    [parDic setObject:self.nameEN forKey:@"name_en"];
    if (self.houseType)
    {
        [parDic setObject:self.houseType forKey:@"houseType"];
    }
    [parDic setObject:[NSString stringWithFormat:@"%d",self.floor] forKey:@"floor"];
    [parDic setObject:[NSString stringWithFormat:@"%d",self.totalFloor] forKey:@"totalFloor"];
    [parDic setObject:self.longitude forKey:@"longitude"];
    [parDic setObject:self.latitude forKey:@"latitude"];
    [parDic setObject:self.area forKey:@"area"];
    [parDic setObject:self.metro forKey:@"metro"];
    if (self.descriptionZH)
    {
        [parDic setObject:self.descriptionZH forKey:@"description_zh"];
    }
    [parDic setObject:self.descriptionEN forKey:@"description_en"];
    [parDic setObject:self.address forKey:@"address"];
    [parDic setObject:self.price forKey:@"price"];
    [parDic setObject:self.outspace == YES ? @"true":@"false" forKey:@"outspace"];
    [parDic setObject:self.size forKey:@"size"];
    [parDic setObject:self.share == YES ? @"true":@"false" forKey:@"share"];
    [parDic setObject:self.bedrooms forKey:@"bedrooms"];
    [parDic setObject:self.bathrooms forKey:@"bathrooms"];
    [parDic setObject:self.livingrooms forKey:@"livingrooms"];
    [parDic setObject:[HEUserLogin sharedLogin].access_token forKey:@"access_token"];
    if (self.houseType)
    {
        [parDic setObject:self.houseType forKey:@"houseType"];
    }

    [SVProgressHUD showWithStatus:@"正在加载..." maskType:svType clicType:SVProgressHUDClickDefult];
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    [manager POST:urlString parameters:parDic constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        int i=0;
        for (UIImage *image in self.housePhotos)
        {
            [formData appendPartWithFileData:UIImageJPEGRepresentation(image, 1.0) name:[NSString stringWithFormat:@"file%d",i] fileName:[NSString stringWithFormat:@"photo%d.jpg",i] mimeType:@"image/jpeg"];
            i++;
        }
        
    } success:^(AFHTTPRequestOperation *operation, id responseObject) {
       
        if (success)
        {
            //875627
            success(responseObject);
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [SVProgressHUD showErrorWithStatus:@"update house error" duration:1.0];
        
        if (requestError)
        {
            requestError();
        }
    }];

    
}
@end
