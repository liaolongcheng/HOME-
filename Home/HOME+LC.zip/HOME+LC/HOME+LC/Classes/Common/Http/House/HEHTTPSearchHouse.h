//
//  HEHTTPSearchHouse.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-20.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

typedef NS_ENUM(NSInteger, SearchConditionType)
{
    SearchConditionTypeWithNormal,
    SearchConditionTypeWithHotspot,
    SearchConditionTypeWithMetro,
    SearchConditionTypeWithNewly,
};


#import <Foundation/Foundation.h>

typedef void(^SearchSuccess)(NSMutableArray *responesArray);

@interface HEHTTPSearchHouse : NSObject


//返回语言
@property (nonatomic,strong) NSString *language;
//页数
@property (nonatomic,assign) NSInteger page;
//排序
@property (nonatomic,strong) NSString *orderBy;
//搜索内容
@property (nonatomic,strong) NSString *keyword;
//返回格式目前只支持json
@property (nonatomic,strong) NSString *format;
//当前经度
@property (nonatomic,strong) NSString *longitude;
//当前纬度
@property (nonatomic,strong) NSString *latitude;
//搜索公里数  （可选）
@property (nonatomic,strong) NSString *maxDistance;
//价格
@property (nonatomic,strong) NSString *price;
//卧室
@property (nonatomic,strong) NSString *bedrooms;
//地区标识（可选）
@property (nonatomic,strong) NSString *area;
//地铁标识 （可选）
@property (nonatomic,strong) NSString *metro;
//房子地板（可选）
@property (nonatomic,strong) NSString *floor;
//房子类型 （可选）
@property (nonatomic,strong) NSString *houseType;
//发布者 (可选)
@property (nonatomic,strong) NSString *publisher;
//房子的经度
@property (nonatomic,strong) NSString *houseLongitude;
//房子的纬度
@property (nonatomic,strong) NSString *houseLatitude;
@property (nonatomic,strong) NSString *star;
@property (nonatomic,assign) SearchConditionType searchType;

+(instancetype) sharedHouse;
-(void) clearUrl;
//普通状态下
-(void)searchWithNorMal:(SearchSuccess)block svType:(SVProgressHUDMaskType)svType;

@end
