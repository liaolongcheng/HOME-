//
//  HEHTTPSearchHouse.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-20.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEHTTPSearchHouse.h"

@implementation HEHTTPSearchHouse

+(instancetype)sharedHouse
{
    static HEHTTPSearchHouse *house;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        house=[[HEHTTPSearchHouse alloc] init];
    });
    return house;
}

-(void)search
{
    NSString *str=[NSString stringWithFormat:@"%@/house/%@/orderBy=%@/keyword=%@/longitude=%@/latitude=%@/price=%@/bedrooms=%@/page=%d/maxDistance=%d.json",BASEURL,EN,@"publishDate",@"",LONGITUDE,LATITUDE,@"1-3",@"1-4",1,2];
 
}

-(void)searchWithNorMal:(SearchSuccess)block svType:(SVProgressHUDMaskType)svType
{
    NSString *tempUrl;
    
    if (![[[[HEHTTPSearchHouse class] sharedHouse] createUrl] isEqualToString:@""])
    {
        tempUrl = [NSString stringWithFormat:@"/houses/en/%@/%d.json?%@",self.orderBy,self.page,[self createUrl]];
    }
    else
    {
        tempUrl = [NSString stringWithFormat:@"/houses/en/%@/%d.json",self.orderBy,self.page];
    }
    
    NSString *urlString = INITURL(tempUrl);
   
    [HttpHelper GET:urlString parameters:nil svText:@"加载中。。。" errorsvText:@"网络异常。。。" svMarkType:svType success:^(AFHTTPRequestOperation *operation, id responseObject)
    {
        if (block)
        {
            block([[NSMutableArray alloc] initWithArray:responseObject]);
        }
        
    } failure:nil];
}
-(NSString *) createUrl
{
    NSMutableString *urlStr=[[NSMutableString alloc] initWithString:@""];
   
    if (self.price)
    {
        [self appendUrl:[NSString stringWithFormat:@"price=%@",self.price] parentString:urlStr];
    }
    else if (self.bedrooms)
    {
        [self appendUrl:[NSString stringWithFormat:@"bedrooms=%@",self.bedrooms] parentString:urlStr];
    }
    
    if (self.area)
    {
        [self appendUrl:[NSString stringWithFormat:@"area=%@",self.area] parentString:urlStr];
    }
    else if (self.metro)
    {
        [self appendUrl:[NSString stringWithFormat:@"metro=%@",self.metro] parentString:urlStr];
    }
    
    return urlStr;
}

-(NSString *)appendUrl:(NSString *)urlString parentString:(NSMutableString *)parentString
{
    if ([parentString isEqualToString:@""])
    {
        [parentString appendFormat:@"%@",urlString];
    }
    else
    {
        [parentString appendFormat:@"%@%@",@"&",urlString];
    }
    return parentString;
}

-(void) clearUrl
{
    self.orderBy = nil;
    self.price = nil;
    self.bedrooms = nil;
    self.star = nil;
    
    HEHTTPSearchHouse *house=[[self class] sharedHouse];
   
    switch (house.searchType)
    {
        case SearchConditionTypeWithNormal:
        {
            self.metro = nil;
            self.area = nil;
        }
            break;
        case SearchConditionTypeWithHotspot:
        {
            house.metro=nil;
        }
            break;
        case SearchConditionTypeWithMetro:
        {
            house.area=nil;
        }
            break;
        case SearchConditionTypeWithNewly:
        {
            self.metro = nil;
            self.area = nil;
        }
        break;
    }

}

@end
