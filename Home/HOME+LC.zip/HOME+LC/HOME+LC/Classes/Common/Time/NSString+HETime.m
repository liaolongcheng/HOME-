//
//  NSString+HETime.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-25.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "NSString+HETime.h"

@implementation NSString (HETime)

+(NSString *)formatterTimeWithString:(NSString *)timeString
{
    NSRange rang = [timeString rangeOfString:@"T"];
    
    NSString *subTime=[timeString substringToIndex:rang.location];
    
    NSDateFormatter *formatter=[[NSDateFormatter alloc] init];
    
    [formatter setDateFormat:@"yyyy-MM-dd"];
 
    NSDate *parDate=[formatter dateFromString:subTime];
    
    NSTimeInterval intterval = [parDate timeIntervalSinceNow];
    
    int days = fabs(intterval) / (24*60*60);
    
    return [NSString stringWithFormat:@"%d days ago",days];
}
+(BOOL)expiredWithDateString:(NSString *)timeString
{
    NSDate *currentDate = [NSDate date];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy-MM-ddTHH:mm:ss"];
    NSRange range = [timeString rangeOfString:@"."];
    timeString = [timeString substringToIndex:range.location];
    NSDate *tempDate = [currentDate earlierDate:[formatter dateFromString:timeString]];
    if ([tempDate isEqual:currentDate])
    {
        return YES;
    }
    else
    {
        return NO;
    }
}

@end
