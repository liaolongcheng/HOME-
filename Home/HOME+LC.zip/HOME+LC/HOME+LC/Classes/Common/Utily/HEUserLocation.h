//
//  HEUserLocation.h
//  HOME+LC
//
//  Created by user on 14/11/1.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BMKUserLocation.h"

@interface HEUserLocation : NSObject

@property (strong, nonatomic) BMKUserLocation *location;

///经度
@property (nonatomic,strong) NSString *Longitude;
///纬度
@property (nonatomic,strong) NSString *Latitude;

+(instancetype) sharedUserLocation;

@end
