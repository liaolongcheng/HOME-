//
//  AreaAndLinesUtily.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-29.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "AreaAndLinesUtily.h"

static NSArray *AreaArray;
static NSMutableArray *AreaSomeArray;

static NSArray *metroArray;
static NSMutableArray *metroSomeArray;
static NSArray *houseArray;

@implementation AreaAndLinesUtily

+(instancetype)sharedAreaLines
{
    static AreaAndLinesUtily *area=nil;
   
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        
        area=[[AreaAndLinesUtily alloc] init];
        
        
        AreaArray=[NSArray arrayWithContentsOfFile:LOAD_BANDLE_FILE(@"areasInfo", @"plist")];
        AreaSomeArray = [[NSMutableArray alloc] init];
        for (int i=0; i<[AreaArray count]; i++)
        {
            [AreaSomeArray addObjectsFromArray:AreaArray[i][@"subways"]];
        }
        
        
        metroArray=[NSArray arrayWithContentsOfFile:LOAD_BANDLE_FILE(@"linesInfo", @"plist")];
        metroSomeArray = [[NSMutableArray alloc] init];
        for (int i=0; i<[metroArray count]; i++)
        {
            [metroSomeArray addObjectsFromArray:metroArray[i][@"subways"]];
        }
        
        houseArray = [NSArray arrayWithContentsOfFile:LOAD_BANDLE_FILE(@"houseTypeInfo", @"plist")];
        
    });
    return area;
}

-(NSString *)enNameWithAreaId:(NSString *)areaId
{
    NSString *subName = @"";
    NSString *parId = @"";
    for (int i=0; i<[AreaSomeArray count]; i++)
    {
        if ([[AreaSomeArray[i] allValues] containsObject:areaId])
        {
            subName = AreaSomeArray[i][@"enName"];
            parId = AreaSomeArray[i][@"parentId"];
            break;
        }
    }
    NSString *supName = @"";
    
    for (int j=0; j<[AreaArray count]; j++)
    {
        if ([[AreaArray[j] allValues] containsObject:parId])
        {
            supName = AreaArray[j][@"enName"];
            break;
        }
        
    }
    
    return [NSString stringWithFormat:@"%@ %@",supName,subName];
}

-(NSString *)enNameWithMetroId:(NSString *)metroId
{
    NSString *subName = @"";
    NSString *parId = @"";
    for (int i=0; i<[metroSomeArray count]; i++)
    {
        if ([[metroSomeArray[i] allValues] containsObject:metroId])
        {
            subName = metroSomeArray[i][@"enName"];
            parId = metroSomeArray[i][@"parentId"];
            break;
        }
    }
    NSString *supName = @"";
    
    for (int j=0; j<[metroArray count]; j++)
    {
        if ([[metroArray[j] allValues] containsObject:parId])
        {
            supName = metroArray[j][@"enName"];
            break;
        }
        
    }
    
    return [NSString stringWithFormat:@"%@ %@",supName,subName];
}

-(NSString *)enNameWithHouseTypeId:(NSString *)houseTypeId
{
    for (NSDictionary *houseType in houseArray)
    {
        if ([[houseType allValues] containsObject:houseTypeId])
        {
            return houseType[@"enName"];
        }
    }
    return nil;
}

-(NSInteger)parIndexWithAreaId:(NSString *)areaId
{
    NSString *parId = @"";
    for (int i=0; i<[AreaSomeArray count]; i++)
    {
        if ([[AreaSomeArray[i] allValues] containsObject:areaId])
        {
            parId = AreaSomeArray[i][@"parentId"];
            break;
        }
    }
    
    for (int j=0; j<[AreaArray count]; j++)
    {
        if ([[AreaArray[j] allValues] containsObject:parId])
        {
            return j;
        }
        
    }
    return 0;
}
-(NSInteger)parIndexWithMetroId:(NSString *)metroId
{
    NSString *parId = @"";
    for (int i=0; i<[metroSomeArray count]; i++)
    {
        if ([[metroSomeArray[i] allValues] containsObject:metroId])
        {
            parId = metroSomeArray[i][@"parentId"];
            break;
        }
    }
    
    for (int j=0; j<[metroArray count]; j++)
    {
        if ([[metroArray[j] allValues] containsObject:parId])
        {
            return j;
        }
        
    }
    
    return 0;
}

@end
