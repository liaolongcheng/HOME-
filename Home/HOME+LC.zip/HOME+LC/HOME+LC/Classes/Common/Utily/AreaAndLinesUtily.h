//
//  AreaAndLinesUtily.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-29.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AreaAndLinesUtily : NSObject

+(instancetype) sharedAreaLines;

-(NSString *) enNameWithAreaId:(NSString *)areaId;

-(NSString *) enNameWithMetroId:(NSString *)metroId;

-(NSString *) enNameWithHouseTypeId:(NSString *)houseTypeId;

-(NSInteger) parIndexWithAreaId:(NSString *)areaId;

-(NSInteger) parIndexWithMetroId:(NSString *)metroId;

@end
