//
//  HEUserLocation.m
//  HOME+LC
//
//  Created by user on 14/11/1.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEUserLocation.h"

@implementation HEUserLocation

+(instancetype) sharedUserLocation
{
    static HEUserLocation *userLocation = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        userLocation = [[HEUserLocation alloc] init];
    });
    return userLocation;
}

@end
