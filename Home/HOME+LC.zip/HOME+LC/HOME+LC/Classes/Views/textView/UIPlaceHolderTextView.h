//
//  UIPlaceHolderTextView.h
//  XCWeibo
//
//  Created by blwidow on 12-3-23.
//  Copyright 2012年 5clubs.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UIPlaceHolderTextView : UITextView
{
    NSString *placeholder;
    UIColor *placeholderColor;
    UILabel *placeHolderLabel;
}

@property (nonatomic, retain) UILabel  *placeHolderLabel;
@property (nonatomic, retain) NSString *placeholder;
@property (nonatomic, retain) UIColor  *placeholderColor;

@end
