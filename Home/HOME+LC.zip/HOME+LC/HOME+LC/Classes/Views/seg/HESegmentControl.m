//
//  HESegmentControl.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-14.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//
#define BASETAG 1000

#import "HESegmentControl.h"


@implementation HESegmentControl
{
    UIView *_contentView;
    NSInteger ButtonCount;
    SegSelected _selected;
    
    NSInteger selectTag;
}


- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        selectTag=1000;
    }
    return self;
}

-(instancetype)initWithSegType:(SegmentControlType)type selectedBlock:(SegSelected)selectedBlock frame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
       
    }
    return self;
}

-(void) initSome
{
    if (_backGroundView)
    {
        _backGroundView.frame=self.bounds;
        _contentView=_backGroundView;
        _contentView.userInteractionEnabled=YES;
        [self addSubview:_backGroundView];
    }
    else
    {
        _contentView=self;
    }
    
}

-(UIButton *) creaeteButton:(NSInteger) index
{
    CGFloat buttonWidth=(CGRectGetWidth(_contentView.frame)-((ButtonCount+1)*_marginWidth))/ButtonCount;
    
    CGFloat tempMarginWidth = (buttonWidth + _marginWidth) * index;
    
    CGFloat buttonHeight = CGRectGetHeight(_contentView.frame)-2*_marginHeight;
   
    UIButton *itemButton = [[UIButton alloc] initWithFrame:CGRectMake(_marginWidth + tempMarginWidth, _marginHeight,buttonWidth,buttonHeight)];
    
    [itemButton setBackgroundColor:_viewBackGroundColor == nil ? [UIColor whiteColor] : _viewBackGroundColor];
    
    if (_type == SegmentControlOnlyTitle)
    {
        [itemButton setTitleColor:_titleColor == nil ? [UIColor blackColor] : _titleColor forState:UIControlStateNormal];
        
        [itemButton setTitle:_titles[index] forState:UIControlStateNormal];
    }
    
    if (_type == SegmentControlOnlyIcon)
    {
        if (_isUseSetBackGround)
        {
            [itemButton setBackgroundImage:_NormalIcons[index] forState:UIControlStateNormal];
        }
        else
        {
            [itemButton setImage:_NormalIcons[index] forState:UIControlStateNormal];
            
        }
        
    }
    
    if (_type == SegmentControlTitleAndIcon)
    {
        
        [itemButton setTitleColor:_titleColor == nil ? [UIColor blackColor] : _titleColor forState:UIControlStateNormal];
        [itemButton setTitle:_titles[index] forState:UIControlStateNormal];
        if (_isUseSetBackGround)
        {
            [itemButton setBackgroundImage:_NormalIcons[index] forState:UIControlStateNormal];
        }
        else
        {
            [itemButton setImage:_NormalIcons[index] forState:UIControlStateNormal];
        }
        
    }
    
    if (_type == SegmentControlNormalIconAndSelectIcon)
    {
        if (_isUseSetBackGround)
        {
            [itemButton setBackgroundImage:_NormalIcons[index] forState:UIControlStateNormal];
            [itemButton setBackgroundImage:_SelectIcons[index] forState:UIControlStateSelected];
        }
        else
        {
            [itemButton setImage:_NormalIcons[index] forState:UIControlStateNormal];
            [itemButton setImage:_SelectIcons[index] forState:UIControlStateSelected];
        }
        
    }
    
    if (_type == SegmentControlTitleAndNormalIconSelectIcon)
    {
        [itemButton setTitleColor:_titleColor == nil ? [UIColor blackColor] : _titleColor forState:UIControlStateNormal];
        
        [itemButton setTitle:_titles[index] forState:UIControlStateNormal];
       
        if (_isUseSetBackGround)
        {
            [itemButton setBackgroundImage:_NormalIcons[index] forState:UIControlStateNormal];
            [itemButton setBackgroundImage:_SelectIcons[index] forState:UIControlStateSelected];
        }
        else
        {
            [itemButton setImage:_NormalIcons[index] forState:UIControlStateNormal];
            [itemButton setImage:_SelectIcons[index] forState:UIControlStateSelected];
        }
    }
    if (_type == SegmentControlTitleIconAndBackGround)
    {

     
        [itemButton setImage:_titleNormalIcons[index] forState:UIControlStateNormal];
        [itemButton setImage:_titleSelectedIcons[index] forState:UIControlStateSelected];
        
        [itemButton setBackgroundImage:_NormalIcons[index] forState:UIControlStateNormal];
        [itemButton setBackgroundImage:_SelectIcons[index] forState:UIControlStateSelected];
       
        if (index==0)
        {
            
            UIImage *sclImage=[_SelectIcons[index] stretchableImageWithLeftCapWidth:20 topCapHeight:20];
            [itemButton setBackgroundImage:sclImage forState:UIControlStateSelected];
        }

        if (index == [_SelectIcons count]-1)
        {
            UIImage *image=_SelectIcons[index];
            UIImage *sclImage=[image stretchableImageWithLeftCapWidth:image.size.width-20 topCapHeight:image.size.height-20];
            [itemButton setBackgroundImage:sclImage forState:UIControlStateSelected];
        }
        
       

    }
    itemButton.backgroundColor=[UIColor clearColor];
    
    itemButton.tag=BASETAG+index;
    
    [itemButton addTarget:self action:@selector(buttonClcik:) forControlEvents:UIControlEventTouchUpInside];
    
//    if (index != [_titles count]-1)
//    {
//    
////        if (self.slicpView)
////        {
////            UIView *silpView=[UIView alloc]
////            silpView.frame=CGRectMake(itemButton.frame.origin.x+itemButton.frame.size.width, itemButton.frame.origin.y, 0.5, itemButton.frame.size.height);
////            //  tempView.frame=CGRectMake((i+1)*frame.size.width/[Titles count], self.frame.size.height-8, 2, self.frame.size.height-16);
////            [[silpView layer] setShadowOffset:CGSizeMake(0, 0)];
////            [[silpView layer] setShadowRadius:1];
////            [[silpView layer] setShadowOpacity:2];
////            [[silpView layer] setShadowColor:silpView.backgroundColor.CGColor];
////            [self addSubview:silpView];
////            
////
////        }
//    }
    
    return itemButton;

}
-(void) addButton
{
    if (ButtonCount>0)
    {
        for (int i=0; i<ButtonCount; i++)
        {
            UIButton *itemButton = [self creaeteButton:i];
            [_contentView addSubview:itemButton];
        }
        
    }
}
-(void) initOnlyTitle
{
    ButtonCount = [_titles count];
    [self addButton];
}
-(void) initOnlyIcon
{
    ButtonCount = [_NormalIcons count];
    [self addButton];
}
-(void) initTitleAndIcon
{
    ButtonCount = [_titles count] >= [_NormalIcons count] ? [_NormalIcons count] : [_titles count];
    [self addButton];
}
-(void) initTitleAndSelectIcon
{
    ButtonCount = [_SelectIcons count] >= [_NormalIcons count] ? [_NormalIcons count] : [_SelectIcons count];
    [self addButton];
}
-(void) initTitleTitleAndSelectIcon
{
    NSArray *array=@[@([_titles count]),@([_NormalIcons count]),@([_SelectIcons count])];
    
    ButtonCount = [array[0] intValue];
    
    for (int i=0; i<3; i++)
    {
        if (ButtonCount>[array[i] intValue])
        {
            ButtonCount=[array[i] intValue];
        }
    }
    
    [self addButton];

}
-(void)initTitleIconAndBackGround
{
    NSArray *array=@[@([_titleSelectedIcons count]),@([_NormalIcons count]),@([_titleNormalIcons count]),@([_SelectIcons count])];
    
    ButtonCount = [array[0] intValue];
    
    for (int i=0; i<3; i++)
    {
        if (ButtonCount>[array[i] intValue])
        {
            ButtonCount=[array[i] intValue];
        }
    }
    
    [self addButton];
}


-(void)createSegmentControlWithSegType:(SegmentControlType)type selectedBlock:(SegSelected)selectedBlock;
{
    _type=type;
    _selected = [selectedBlock copy];
    [self initSome];
    switch (type)
    {
        case SegmentControlOnlyTitle:
            [self initOnlyTitle];
            break;
        case SegmentControlOnlyIcon:
            [self initOnlyIcon];
            break;
        case SegmentControlTitleAndIcon:
            [self initTitleAndIcon];
            break;
        case SegmentControlNormalIconAndSelectIcon:
            [self initTitleAndSelectIcon];
            break;
        case SegmentControlTitleAndNormalIconSelectIcon:
            [self initTitleTitleAndSelectIcon];
            break;
        case SegmentControlTitleIconAndBackGround:
            [self initTitleIconAndBackGround];
            break;
    }

}
-(void) buttonClcik:(UIButton *) btn
{

    UIButton *tempBtn = (UIButton *)[_contentView viewWithTag:selectTag];
    tempBtn.selected = NO;
    tempBtn.userInteractionEnabled=YES;
    selectTag = btn.tag;
    btn.selected = YES;
    if (_isDoubleClcik == YES)
    {
        btn.userInteractionEnabled=NO;
    }
    _selected(btn.tag - BASETAG,btn);

    
//    NSArray *views=[_contentView subviews];
//
//    for(UIView *ve in views)
//    {
//        if ([ve isKindOfClass:[UIButton class]])
//        {
//            UIButton *btnn=
//            if (ve.tag == btn.tag)
//            {
//            
//            }
//            else
//            {
//                
//            }
//            
//        }
//    }
    
//    UIButton *tempBtn=(UIButton *)[_contentView viewWithTag:selectTag];
//    tempBtn.selected=NO;
//    selectTag=btn.tag;
//    btn.selected=YES;
//    _selected(btn.tag-BASETAG,btn);
    
//    _selected(btn.tag-BASETAG,btn);
//    [self selectAtIndex:btn.tag-BASETAG];
    
    
    
}
-(void) selectAtIndex:(NSInteger)index
{

    UIButton *wantButton = (UIButton *)[_contentView viewWithTag:index + BASETAG];
    UIButton *currentButton = (UIButton *)[_contentView viewWithTag:selectTag];
    currentButton.selected = NO;
    if (_isDoubleClcik  == YES)
    {
         currentButton.userInteractionEnabled=YES;
    }
   
    wantButton.selected = YES;
    wantButton.userInteractionEnabled=NO;
    selectTag = index + BASETAG;
    
//    UIButton *tempButton=(UIButton *)[_contentView viewWithTag:selectTag];
//    tempButton.selected=NO;
//    
//    UIButton *currentButton=(UIButton *)[_contentView viewWithTag:BASETAG+index];
//    currentButton.selected=YES;
//    selectTag=currentButton.tag;
}
-(NSInteger) currentSelectIndex
{
    return selectTag-BASETAG;
}
-(UIView *) currentSelectView
{
     return [_contentView viewWithTag:selectTag];
}

-(UIView *)viewAtIndex:(NSInteger)index
{
    UIView *view=[_contentView viewWithTag:BASETAG+index];
    return view;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
