//
//  HESegmentControl.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-14.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

typedef NS_ENUM(NSInteger,SegmentControlType)
{
    SegmentControlOnlyTitle,
    SegmentControlOnlyIcon,
    SegmentControlTitleAndIcon,
    SegmentControlNormalIconAndSelectIcon,
    SegmentControlTitleAndNormalIconSelectIcon,
    SegmentControlTitleIconAndBackGround
};

typedef void(^SegSelected)(NSInteger selectIndex,UIView *selectView);

#import <UIKit/UIKit.h>

@interface HESegmentControl : UIView

@property (assign,nonatomic) SegmentControlType type;
@property (strong,nonatomic) UIView *backGroundView;
@property (strong,nonatomic) UIColor *titleColor;
@property (strong,nonatomic) UIColor *viewBackGroundColor;
@property (strong,nonatomic) UIView *slicpView;
@property (assign,nonatomic) BOOL isUseSetBackGround;

@property (strong,nonatomic) NSArray *titles;
@property (strong,nonatomic) NSArray *NormalIcons;
@property (strong,nonatomic) NSArray *SelectIcons;

//是否是单选
@property (assign,nonatomic) BOOL isDoubleClcik;

/*
 只有在SegmentControlIconAndBackGround时有效
 */
@property (strong,nonatomic) NSArray *titleNormalIcons;
@property (strong,nonatomic) NSArray *titleSelectedIcons;

@property (assign,nonatomic) CGFloat marginWidth;
@property (assign,nonatomic) CGFloat marginHeight;



-(void) createSegmentControlWithSegType:(SegmentControlType) type selectedBlock:(SegSelected)selectedBlock;

-(void) selectAtIndex:(NSInteger) index;

-(NSInteger) currentSelectIndex;
-(UIView *) currentSelectView;

-(UIView *) viewAtIndex:(NSInteger) index;


@end
