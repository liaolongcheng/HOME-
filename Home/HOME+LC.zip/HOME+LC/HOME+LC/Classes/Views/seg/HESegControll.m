//
//  HESegControll.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-14.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HESegControll.h"

@implementation HESegControll

static int selectIndext=1000;


- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        _titleColor=[UIColor blackColor];
        
    }
    return self;
}

-(id)initWithicons:(NSMutableArray *)Icons SelectIncons:(NSMutableArray *)selectIcons frame:(CGRect)frame
{
    self=[self initWithFrame:frame];
    if (self!=nil) {
        
        for(int i=0;i<[Icons count];i++)
        {
            UIButton *menuButton=[[UIButton alloc] initWithFrame:CGRectMake((i*(frame.size.width/[Icons count]))+(frame.size.width/[Icons count])*0.27, frame.size.height*0.2, (frame.size.width/[Icons count])*0.46, frame.size.height*0.6)];
            //[menuButton setImage:[Icons objectAtIndex:i] forState:UIControlStateNormal];
            [menuButton setBackgroundImage:[Icons objectAtIndex:i] forState:UIControlStateNormal];
            if ([selectIcons count]>i) {
                //[menuButton setImage:[selectIcons objectAtIndex:i] forState:UIControlStateSelected];
                [menuButton setBackgroundImage:[selectIcons objectAtIndex:i] forState:UIControlStateSelected];
            }
            [menuButton addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
            menuButton.tag=1000+i;
            [self addSubview:menuButton];
       
        }
    }
    
    return self;
}
-(id) initWithicon:(UIImage *) Icon SelectIncon:(UIImage *) selectIcon Titles:(NSArray *) Titles frame:(CGRect) frame
{
    self=[self initWithFrame:frame];
    if(self!=nil)
    {
        for(int i=0;i<[Titles count];i++)
        {
            UIButton *button=[[UIButton alloc] initWithFrame:CGRectMake(frame.size.width/[Titles count]*i, 0, frame.size.width/[Titles count], frame.size.height)];
            button.tag=1000+i;
            [button setBackgroundImage:Icon forState:UIControlStateNormal];
            [button setBackgroundImage:selectIcon forState:UIControlStateSelected];
            [button setTitle:[Titles objectAtIndex:i] forState:UIControlStateNormal];
            [button setTitle:[Titles objectAtIndex:i] forState:UIControlStateSelected];
            [button addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
            button.titleLabel.font=[UIFont systemFontOfSize:5*[Titles count]];
            [button setTitleColor:self.titleColor forState:UIControlStateNormal];
            [button setTitleColor:self.titleColor forState:UIControlStateSelected];
            [self addSubview:button];
           
        }
        
        for(int i=0;i<[Titles count];i++)
        {
            // UIView *tempView=[_slicpView copy];
            UIView *silpView=[[UIView alloc] initWithFrame:CGRectMake((i+1)*frame.size.width/[Titles count], 17, 0.5, self.frame.size.height-34)];
            //  tempView.frame=CGRectMake((i+1)*frame.size.width/[Titles count], self.frame.size.height-8, 2, self.frame.size.height-16);
            [[silpView layer] setShadowOffset:CGSizeMake(0, 0)];
            [[silpView layer] setShadowRadius:1];
            [[silpView layer] setShadowOpacity:2];
            [[silpView layer] setShadowColor:[UIColor blackColor].CGColor];
            silpView.backgroundColor=[UIColor blackColor];
            [self addSubview:silpView];
            
        }
    }
    return self;
}

-(void)setBackGroundView:(UIView *)backGroundView
{
    [_backGroundView  removeFromSuperview];
  
    _backGroundView.frame=self.bounds;
    _backGroundView.userInteractionEnabled=YES;
    [self insertSubview:_backGroundView atIndex:0];
 
}

-(void)setTitleColor:(UIColor *)titleColor
{
    _titleColor=titleColor;
    NSArray *subArray=[self subviews];
    for(int i=0;i<[subArray count];i++)
    {
        if ([[subArray objectAtIndex:i] isKindOfClass:[UIButton class]]) {
            UIButton *bt=[subArray objectAtIndex:i];
            bt.titleLabel.textColor=self.titleColor;
        }
    }
}

-(void) buttonClick:(UIButton *) btn
{
    
    UIButton *tempBtn=(UIButton *)[self viewWithTag:selectIndext];
    tempBtn.selected=NO;
    selectIndext=btn.tag;
    btn.selected=YES;
    [self.delegate SegSelectAtIndex:btn.tag-1000];
}


-(void) setSegSelectIndex:(int) indext
{
    UIButton *wantButton=(UIButton *)[self viewWithTag:indext+1000];
    UIButton *currentButton=(UIButton *)[self viewWithTag:selectIndext];
    currentButton.selected=NO;
    wantButton.selected=YES;
    selectIndext=indext+1000;
}


/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect
 {
 // Drawing code
 }
 */


@end
