//
//  HESegControll.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-14.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol SegDelegate <NSObject>

-(void) SegSelectAtIndex:(int) indext;

@end

@interface HESegControll : UIView
{
    UIView *_backView;
    UIColor *_titleColor;
    UIView *_slicpView;
}

@property (retain,nonatomic) UIView *backGroundView;
@property (retain,nonatomic) UIColor *titleColor;
@property (retain,nonatomic) UIView *slicpView;
@property (assign,nonatomic) id<SegDelegate> delegate;

-(id) initWithTitles:(NSMutableArray *) Titles frame:(CGRect) frame;
-(id) initWithicons:(NSMutableArray *) Icons frame:(CGRect) frame;
-(id) initWithicons:(NSMutableArray *) Icons Titles:(NSMutableArray *) Titles;
-(id) initWithicons:(NSMutableArray *) Icons SelectIncons:(NSMutableArray *) selectIcons frame:(CGRect) frame;
-(id) initWithicon:(UIImage *) Icon SelectIncon:(UIImage *) selectIcon Titles:(NSArray *) Titles frame:(CGRect) frame;

-(void) setSegSelectIndex:(int) indext;
@end
