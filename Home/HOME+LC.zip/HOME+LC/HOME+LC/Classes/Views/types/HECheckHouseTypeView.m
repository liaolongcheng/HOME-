//
//  HECheckHouseTypeView.m
//  HOME+LC
//
//  Created by user on 14/10/30.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HECheckHouseTypeView.h"
#import "AlertCustom.h"

@implementation HECheckHouseTypeView
{
    NSArray *_sourceArray;
    didSelectHouseTypeBlock _selBlock;
}


-(instancetype)initWithSelectHouseInfoBlock:(didSelectHouseTypeBlock)selBlock
{
    self = LOAD_TABLEVIEWCELL(@"HECheckHouseTypeView");

    if (self)
    {
        _selBlock = selBlock;
        self.myTableView.dataSource = self;
        self.myTableView.delegate = self;
        self.myTableView.backgroundColor = [UIColor clearColor];
        UIImageView *backImage = [[UIImageView alloc] initWithImage:LOAD_IMAGE(@"background2.png")];
        UIImage *tmpImage = IMAGE_STRRTCHABLE(backImage.image, 20, 20);
        backImage.image = tmpImage;
        self.myTableView.backgroundView = backImage;
        
        _sourceArray = [NSArray arrayWithContentsOfFile:LOAD_BANDLE_FILE(@"houseTypeInfo", @"plist")];
        
    }
    return self;
}


-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [_sourceArray count];
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *str = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:str];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:str];
        cell.backgroundColor = [UIColor clearColor];
        cell.textLabel.font = FONT(14);
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    cell.textLabel.text = _sourceArray[indexPath.row][@"enName"];
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 40;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    cell.accessoryType = UITableViewCellAccessoryCheckmark;
    double delayInSeconds = 0.5;
    _selBlock(_sourceArray[indexPath.row]);
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC));
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        [AlertCustom dismissWithView:self];
    });
}

@end
