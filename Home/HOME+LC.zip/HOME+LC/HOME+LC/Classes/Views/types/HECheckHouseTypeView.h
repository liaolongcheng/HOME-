//
//  HECheckHouseTypeView.h
//  HOME+LC
//
//  Created by user on 14/10/30.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//


#import <UIKit/UIKit.h>

typedef void(^didSelectHouseTypeBlock)(NSDictionary *houseTypeInfo);

@interface HECheckHouseTypeView : UIView<UITableViewDataSource,UITableViewDelegate>
@property (strong, nonatomic) IBOutlet UITableView *myTableView;


-(instancetype)initWithSelectHouseInfoBlock:(didSelectHouseTypeBlock)selBlock;


@end
