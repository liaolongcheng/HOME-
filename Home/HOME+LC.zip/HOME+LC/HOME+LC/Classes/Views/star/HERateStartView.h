//
//  HERateStartView.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-16.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol DYRateViewDelegate;
typedef enum {
    RateViewAlignmentLeft,
    RateViewAlignmentCenter,
    RateViewAlignmentRight
} RateViewAlignment;


@interface HERateStartView : UIView

{
    UIImage *_fullStarImage;
    UIImage *_emptyStarImage;
    CGPoint _origin;
    NSInteger _numOfStars;
}

@property(nonatomic, assign) RateViewAlignment alignment;
@property(nonatomic, assign) CGFloat rate;
@property(nonatomic, assign) CGFloat padding;
@property(nonatomic, assign) BOOL editable;
@property(nonatomic, retain) UIImage *fullStarImage;
@property(nonatomic, retain) UIImage *emptyStarImage;
@property(nonatomic, assign) NSObject<DYRateViewDelegate> *delegate;
@property(nonatomic, assign) NSInteger numOfStars;

- (instancetype)initWithFrame:(CGRect)frame;
- (instancetype)initWithFrame:(CGRect)rect fullStar:(UIImage *)fullStarImage emptyStar:(UIImage *)emptyStarImage;

@end

@protocol DYRateViewDelegate

- (void)rateView:(HERateStartView *)rateView changedToNewRate:(NSNumber *)rate;

@end

