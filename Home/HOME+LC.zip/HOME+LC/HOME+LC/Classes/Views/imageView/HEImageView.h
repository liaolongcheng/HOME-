//
//  HEImageView.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-17.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HEImageView : UIImageView

-(id)initWithFrame:(CGRect)frame;

@end
