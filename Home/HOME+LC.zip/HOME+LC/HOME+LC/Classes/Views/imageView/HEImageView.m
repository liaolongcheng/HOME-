//
//  HEImageView.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-17.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEImageView.h"

@implementation HEImageView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        
        UIEdgeInsets insets = UIEdgeInsetsMake(20.0f, 0.0f, 20.0f, 0.0f);
        UIImage *image=LOAD_IMAGE(@"background2.png");
        UIImage *tempImage= IMAGE_STRRTCHABLE(image, insets.left, insets.top);
        self.image = tempImage;
        self.backgroundColor=[UIColor redColor];
        
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
