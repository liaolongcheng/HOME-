
//
//  HECheckPhotoView.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-18.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HECheckPhotoView.h"
#import <QuartzCore/QuartzCore.h>
#import "AlertCustom.h"

static UIImagePickerController *_imagePicker;

@implementation HECheckPhotoView
{
    checkPhotoBlock _checkBlock;
    deletePhotoBlock _delteBlock;
    addAndReplBlock _addBlock;
  
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

-(instancetype)initWith:(checkPhotoBlock)ckeckBlock
{
    self=LOAD_TABLEVIEWCELL(@"HECheckPhotoView");
    if (self)
    {
        self.layer.masksToBounds=YES;
        self.layer.cornerRadius=5;
        _checkBlock=[ckeckBlock copy];
        self.title.text = [self titlePhoto];
        [self.leftButton setTitle:[self leftButtonTitle] forState:UIControlStateNormal];
        [self.rightButton setTitle:[self rightButtonTitle] forState:UIControlStateNormal];
    }
    return self;
}

-(instancetype)initWithDelete:(deletePhotoBlock)deleteBlock
{
    self=LOAD_TABLEVIEWCELL(@"HECheckPhotoView");
    if (self)
    {
        self.isDelete=YES;
       
        self.title.text = @"是否要删除这张照片?";
        [self.leftButton setTitle:@"ok" forState:UIControlStateNormal];
        [self.rightButton setTitle:@"Cancel" forState:UIControlStateNormal];
        
        self.layer.masksToBounds=YES;
        self.layer.cornerRadius=5;
        _delteBlock=[deleteBlock copy];
    }
    return self;
}
-(instancetype) initWithAddAndReplce:(addAndReplBlock)repBlock
{
    self=LOAD_TABLEVIEWCELL(@"HECheckPhotoView");
    if (self)
    {
        self.isUpdate = YES;
        _addBlock = repBlock;
        self.layer.masksToBounds=YES;
        self.layer.cornerRadius=5;
        self.title.text = @"update photo";
        [self.leftButton setTitle:@"add" forState:UIControlStateNormal];
        [self.rightButton setTitle:@"Replace" forState:UIControlStateNormal];
    }
    return self;
}


-(UIImagePickerController *) sharedImagePicker
{
   
    _imagePicker=[[UIImagePickerController alloc] init];
    _imagePicker.delegate=self;
    _imagePicker.allowsEditing=YES;
    return _imagePicker;
}
- (IBAction)leftButtonClick:(id)sender
{
    
    if (self.isDelete)
    {
        _delteBlock();
        [AlertCustom dismissWithView:self];
        return;
    }
    if (self.isUpdate)
    {
        _addBlock(YES);
        [AlertCustom dismissWithView:self];
        return;
    }
    
    [self sharedImagePicker];
    if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
    {
        BH_ALERT(@"相机不可用");
        return;
    }
    else
    {
        _imagePicker.sourceType=UIImagePickerControllerSourceTypeCamera;
        _imagePicker.mediaTypes=@[@"public.image"];
        
        [ROOTVIEWCONTROLLER presentViewController:_imagePicker animated:YES completion:^{
            [AlertCustom hiddenWithView:self];
        }];
    }
}

- (IBAction)rightButtonClcik:(id)sender
{
    if (_isDelete)
    {
        [AlertCustom dismissWithView:self];
        return;
    }
    if (_isUpdate)
    {
        _addBlock(NO);
        [AlertCustom dismissWithView:self];
        return;
    }
    
    [self sharedImagePicker];
    if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary])
    {
        BH_ALERT(@"相册不可用");
        return;
    }
    else
    {
        _imagePicker.sourceType=UIImagePickerControllerSourceTypePhotoLibrary;
        _imagePicker.mediaTypes=@[@"public.image"];
        
        [ROOTVIEWCONTROLLER presentViewController:_imagePicker animated:YES completion:^{
           
            [AlertCustom hiddenWithView:self];
            
        }];
        
    }
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    //判断当前的媒体类型
    if([[info objectForKey:UIImagePickerControllerMediaType] isEqualToString:@"public.image"])
    {
        //取得照片
        UIImage *im=[info objectForKey:UIImagePickerControllerEditedImage];
        _checkBlock(im);
        
    }
    [ROOTVIEWCONTROLLER dismissViewControllerAnimated:YES completion:^{
        [AlertCustom dismissWithView:self];
    }];
}
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [ROOTVIEWCONTROLLER dismissViewControllerAnimated:YES completion:^{
        [AlertCustom dismissWithView:self];
    }];
}

-(NSString *)titlePhoto
{
    return @"Add a photo";
}
-(NSString *)leftButtonTitle
{
    return @"Take photo";
}
-(NSString *)rightButtonTitle
{
    return @"Choose from Gallery";
}
@end
