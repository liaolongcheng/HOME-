//
//  HECheckPhotoView.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-18.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^checkPhotoBlock)(UIImage *ckeckedImage);
typedef void(^deletePhotoBlock)();
typedef void(^addAndReplBlock)(BOOL isleft);

@interface HECheckPhotoView : UIView<UINavigationControllerDelegate,UIImagePickerControllerDelegate>

@property (nonatomic,assign) BOOL isDelete;
@property (nonatomic,assign) BOOL isUpdate;
@property (strong, nonatomic) IBOutlet UILabel *title;
@property (strong, nonatomic) IBOutlet UIButton *leftButton;
@property (strong, nonatomic) IBOutlet UIButton *rightButton;

- (IBAction)leftButtonClick:(id)sender;
- (IBAction)rightButtonClcik:(id)sender;
-(instancetype) initWith:(checkPhotoBlock)ckeckBlock;
-(instancetype) initWithDelete:(deletePhotoBlock)deleteBlock;
-(instancetype) initWithAddAndReplce:(addAndReplBlock)repBlock;

-(NSString *) titlePhoto;
-(NSString *) leftButtonTitle;
-(NSString *) rightButtonTitle;



@end
