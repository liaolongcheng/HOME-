//
//  HETost.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-29.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HETost.h"

@implementation HETost
+(void) showTost:(NSString *) text
{
    UILabel *tostLable=[[UILabel alloc] initWithFrame:CGRectMake(0, 0, 200, 30)];
    tostLable.font=[UIFont fontWithName:@"Arial" size:13];
    CGSize size=[text sizeWithFont:tostLable.font constrainedToSize:CGSizeMake(tostLable.frame.size.width, MAXFLOAT) lineBreakMode:NSLineBreakByCharWrapping];
    tostLable.numberOfLines=0;
    tostLable.frame=CGRectMake(0, 10, 200, size.height);
    tostLable.text=text;
    tostLable.backgroundColor=[UIColor blackColor];
    tostLable.center=[[UIApplication sharedApplication] keyWindow].center;
    [[[UIApplication sharedApplication] keyWindow] addSubview:tostLable];
    tostLable.textColor=[UIColor whiteColor];
    tostLable.textAlignment=NSTextAlignmentCenter;
    tostLable.alpha=0;
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDelay:0.2];
    tostLable.alpha=0.8;
    [UIView commitAnimations];
    tostLable.layer.masksToBounds=YES;
    tostLable.layer.cornerRadius=5.0;
    [self performSelector:@selector(removeTost:) withObject:tostLable afterDelay:2.0];
}

+(void) removeTost:(NSObject *)obj
{
    UILabel *la=(UILabel *)obj;
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDelay:0.2];
    la.alpha=0.0;
    [UIView commitAnimations];
    [la removeFromSuperview];
}

@end
