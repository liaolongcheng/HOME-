//
//  HETost.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-29.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HETost : NSObject

+(void) showTost:(NSString *) text;

@end
