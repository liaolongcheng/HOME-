//
//  HESegmentControllExpand.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-16.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

@class HESegmentControllExpand;


#import "HESegmentControl.h"

typedef void(^SegExpandBlock)(HESegmentControllExpand *segExpand,NSInteger index,UIView *currentView);

@interface HESegmentControllExpand : UIView<UITableViewDataSource,UITableViewDelegate>

@property (nonatomic, strong) HESegmentControl *segmentControll;

@property (nonatomic, assign) BOOL selctTime;
@property (nonatomic, strong) NSString *selectPrice;
@property (nonatomic, strong) NSString *selectRoom;
@property (nonatomic, assign) BOOL selectStar;

-(void) createSegmentExpand:(SegExpandBlock) exPandBlock;

@end
