//
//  HESegmentControllExpand.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-16.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HESegmentControllExpand.h"

@implementation HESegmentControllExpand
{
 
    CGRect _frame;
    UITableView *priceList;
    UITableView *roomList;
    
    NSDictionary *priceListSource;
    NSDictionary *roomListSource;
    NSArray *priceListArray;
    NSArray *roomListArray;
    
    UIView *_tempView;
    
    SegExpandBlock _expandBlock;
    
}



-(id)initWithFrame:(CGRect)frame
{
    self=[super initWithFrame:frame];
    if (self)
    {
        _frame=frame;
        self.backgroundColor=[UIColor clearColor];
        self.frame=CGRectMake(frame.origin.x, frame.origin.y, CGRectGetWidth(frame), CGRectGetHeight(frame));
        _tempView=[[UIView alloc] initWithFrame:self.bounds];
        _tempView.frame=CGRectMake(_tempView.frame.origin.x, _tempView.frame.origin.y, _frame.size.width, SCREEN_HEIGHT-_frame.origin.x);
        _tempView.backgroundColor=[UIColor blackColor];
        _tempView.alpha=0.2;
        _tempView.hidden=YES;
        
        UITapGestureRecognizer *tap=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tempViewClick:)];
        [_tempView addGestureRecognizer:tap];
        
        [self addSubview:_tempView];
    priceListSource=@{@"Unlimited":@"1+",@"1000-5000":@"1-5",@"5000-7000":@"5-7",@"7000-10000":@"7-10",@"10000-130.":@"10-13",@"1300-150.":@"13-15",@"1500-200.":@"15-20",@">20000":@"20+"};
        
        roomListSource=@{@"Unlimited":@"1+",@"1 bedrooms":@"1",@"2 bedrooms":@"2",@"3 bedrooms":@"3",@">3 bedrooms":@"3+"};
        
        
        priceListArray  =@[@"Unlimited",@"1000-5000",@"5000-7000",@"7000-10000",@"10000-130.",@"1300-150.",@">20000"];
        
        roomListArray = @[@"Unlimited",@"1 bedrooms",@"2 bedrooms",@"3 bedrooms",@">3 bedrooms"];
        
    }
    return self;
}

-(HESegmentControl *)segmentControll
{
    if (!_segmentControll)
    {
        _segmentControll=({
            
            HESegmentControl *seg=[[HESegmentControl alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth(_frame), CGRectGetHeight(_frame))];
            UIImageView *imageView=[[UIImageView alloc] init];
            imageView.image=LOAD_IMAGE(@"seg_back.png");
            seg.backGroundView=imageView;
            seg.titles=@[@"time",@"price",@"Room",@"Star"];
            [seg createSegmentControlWithSegType:SegmentControlOnlyTitle selectedBlock:^(NSInteger selectIndex, UIView *selectView) {
                if (selectIndex == 0)
                {
                    [self hiddenSelectListView];
                    self.selctTime = !self.selctTime;
                    _expandBlock(self,selectIndex,selectView);
                }
                else if (selectIndex == 1)
                {
                    self.frame=CGRectMake(_frame.origin.x, _frame.origin.y, _frame.size.width, SCREEN_HEIGHT-_frame.origin.x);
                 
                    roomList.frame=CGRectMake(roomList.frame.origin.x, roomList.frame.origin.y, CGRectGetWidth(roomList.frame), 0);
                   
                    [UIView animateWithDuration:0.3 animations:^{
                        
                        priceList.frame=CGRectMake(priceList.frame.origin.x, priceList.frame.origin.y, CGRectGetWidth(priceList.frame), 30*[priceListArray count]);
                        
                        _tempView.hidden=NO;
                    }];
                }
                else if(selectIndex == 2)
                {
                    
                    self.frame=CGRectMake(_frame.origin.x, _frame.origin.y, _frame.size.width, SCREEN_HEIGHT-_frame.origin.x);
                    priceList.frame=CGRectMake(priceList.frame.origin.x, priceList.frame.origin.y, CGRectGetWidth(priceList.frame), 0);
                 
                    [UIView animateWithDuration:0.3 animations:^{
                        
                       roomList.frame=CGRectMake(roomList.frame.origin.x, roomList.frame.origin.y, CGRectGetWidth(roomList.frame), 30*[roomListArray count]);
                        
                        _tempView.hidden=NO;
                    }];
                }
                else if(selectIndex == 3)
                {
                    [self hiddenSelectListView];
                    self.selectStar = !self.selectStar;
                    _expandBlock(self,selectIndex,selectView);
                }
                
            }];

            seg;
        });
    }
    return _segmentControll;
}
-(void) hiddenSelectListView
{
    self.frame=CGRectMake(_frame.origin.x, _frame.origin.y, CGRectGetWidth(_frame), CGRectGetHeight(_frame));
    [UIView animateWithDuration:0.3 animations:^{
        priceList.frame=CGRectMake(priceList.frame.origin.x, priceList.frame.origin.y, CGRectGetWidth(priceList.frame), 0);
        roomList.frame=CGRectMake(roomList.frame.origin.x, roomList.frame.origin.y, CGRectGetWidth(roomList.frame), 0);
        _tempView.hidden=YES;
    }];
}

-(void) tempViewClick:(UIGestureRecognizer *) ges
{
    [self hiddenSelectListView];
}
-(void)createSegmentExpand:(SegExpandBlock)exPandBlock
{
    
    _expandBlock  = [exPandBlock copy];
    
    [self addSubview:self.segmentControll];
    
    UIButton *priceButton=(UIButton *)[self.segmentControll viewAtIndex:1];
    
    priceList = [[UITableView alloc] initWithFrame:CGRectMake(priceButton.frame.origin.x-10, priceButton.frame.origin.y+CGRectGetHeight(priceButton.frame), CGRectGetWidth(priceButton.frame)+20, 0) style:UITableViewStylePlain];
    priceList.tag=100;
    priceList.delegate=self;
    priceList.dataSource=self;
    [self addSubview:priceList];
    
    UIButton *roomsBurron=(UIButton *)[self.segmentControll viewAtIndex:2];
    
    roomList =  [[UITableView alloc] initWithFrame:CGRectMake(roomsBurron.frame.origin.x-10, roomsBurron.frame.origin.y+CGRectGetHeight(roomsBurron.frame), CGRectGetWidth(roomsBurron.frame)+20, 0) style:UITableViewStylePlain];
    roomList.tag=200;
    roomList.dataSource=self;
    roomList.delegate=self;
    [self addSubview:roomList];
    
    
//    UIButton *button=[[UIButton alloc] init];
//    button.frame=CGRectMake(30, 100, 40, 20);
//    [button setTitle:@"button1" forState:UIControlStateHighlighted];
//    [button setTitle:@"button" forState:UIControlStateNormal];
//    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
//    [self addSubview:button];
}

-(NSDictionary *) readDicInfoOfContentFile:(NSString *) fileName extension :(NSString *)extension
{

    NSDictionary *dic=[NSDictionary dictionaryWithContentsOfFile:LOAD_BANDLE_FILE(fileName, extension)];
    return dic;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView.tag==100)
    {
        return [priceListArray count];
    }
    if (tableView.tag == 200)
    {
        return [roomListArray count];
        
    }
    return 0;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *str=@"Cell";
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:str];
    if (!cell)
    {
        cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:str];
        cell.textLabel.font=FONT(10);
    }
    if (tableView.tag == 100)
    {

        cell.textLabel.text=priceListArray[indexPath.row];
    }
    if (tableView.tag == 200)
    {
        cell.textLabel.text = roomListArray[indexPath.row];
    }
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 30;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self hiddenSelectListView];
    if(tableView.tag == 100)
    {
        _selectPrice = priceListSource[priceListArray[indexPath.row]];
        _expandBlock(self,[_segmentControll currentSelectIndex],[_segmentControll currentSelectView]);
    }
    if (tableView.tag == 200)
    {
        _selectRoom = roomListSource[roomListArray[indexPath.row]];
        _expandBlock(self,[_segmentControll currentSelectIndex],[_segmentControll currentSelectView]);
    }
 
}

@end
