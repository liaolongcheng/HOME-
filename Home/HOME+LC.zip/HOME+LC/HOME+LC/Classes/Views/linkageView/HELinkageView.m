//
//  HELinkageView.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-18.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#define IMAGENAME @"line1.png"

#define MARGIN 5
#define ROWHEIGHT 25

#import "HELinkageView.h"

@interface HELinkageView ()
{
    UIView *_contentView;
    CGRect _frame;
    
    UILabel *_leftLable;
    UILabel *_rightLable;
    
    UITableView *_leftTableView;
    UITableView *_rightTableView;
    CGRect _leftTableViewFrame;
    CGRect _rightTableViewFrame;
    
    NSArray *_sourceArray;
    
    NSInteger _selectIndex;
    
    NSString *_fileName;
    
}

@end

@implementation HELinkageView

-(id)init
{
    self=[super init];
    if (self){
        
    }
    return self;
}

-(UIView *) mySuperTableView
{
    return [[self superview] superview];
}
-(void)didMoveToSuperview
{
    _contentView=[[UIView alloc] initWithFrame:self.bounds];
    _contentView.backgroundColor=[UIColor blackColor];
    _contentView.userInteractionEnabled=YES;

    _contentView.frame=CGRectMake(0, CGRectGetHeight(_frame), CGRectGetWidth(_frame), SCREEN_HEIGHT-_frame.origin.y-CGRectGetHeight(_frame));
    _contentView.alpha=0.2;
    _contentView.hidden=YES;
    [self addSubview:_contentView];

    UITapGestureRecognizer *contentViewTap=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hiddenTableView)];
    [_contentView addGestureRecognizer:contentViewTap];
    
    
    self.userInteractionEnabled=YES;
    
    _sourceArray=[self readArrayInfoOfContentFile:_fileName extension:@"plist"];
    
    _leftLable=[[UILabel alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth(_frame)*0.4, CGRectGetHeight(_frame))];
    _leftLable.userInteractionEnabled=YES;
    _leftLable.text=@"leftLable";
    _leftLable.textAlignment=NSTextAlignmentCenter;
    _leftLable.font=FONT(13);
    [self addSubview:_leftLable];
    
    UIGestureRecognizer *leftGes=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(leftClick:)];
    [_leftLable addGestureRecognizer:leftGes];
    
    UIImageView *leftImageView=[[UIImageView alloc] initWithFrame:CGRectMake(0, CGRectGetHeight(_frame), CGRectGetWidth(_frame)*0.4, 2)];
    leftImageView.userInteractionEnabled=NO;
    leftImageView.image=LOAD_IMAGE(IMAGENAME);
    [self addSubview:leftImageView];
    
    
    _leftTableViewFrame=CGRectMake(0, CGRectGetHeight(_frame),  CGRectGetWidth(_frame)*0.4, 0);
    _leftTableView=[[UITableView alloc] initWithFrame:_leftTableViewFrame style:UITableViewStylePlain];
    _leftTableView.dataSource=self;
    _leftTableView.delegate=self;
    _leftTableView.tag=100;
    [self addSubview:_leftTableView];
    
    
    _rightLable=[[UILabel alloc] initWithFrame:CGRectMake(leftImageView.frame.origin.x + CGRectGetWidth(leftImageView.frame)+MARGIN, 0, CGRectGetWidth(_frame)-CGRectGetWidth(leftImageView.frame)-2*MARGIN, CGRectGetHeight(_frame))];
    _rightLable.text=@"rightLable";
    _rightLable.textAlignment=NSTextAlignmentCenter;
    _rightLable.userInteractionEnabled=YES;
    _rightLable.font=FONT(13);
    [self addSubview:_rightLable];
    
    UIGestureRecognizer *rightGes=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(rightClick:)];
    [_rightLable addGestureRecognizer:rightGes];
    
    
    UIImageView *rightImageView=[[UIImageView alloc] initWithFrame:CGRectMake(leftImageView.frame.origin.x + CGRectGetWidth(leftImageView.frame)+MARGIN, leftImageView.frame.origin.y, CGRectGetWidth(_frame)-CGRectGetWidth(leftImageView.frame)-2*MARGIN, 2)];
    rightImageView.image=LOAD_IMAGE(IMAGENAME);
    [self addSubview:rightImageView];
    
    _rightTableViewFrame=CGRectMake(leftImageView.frame.origin.x + CGRectGetWidth(leftImageView.frame)+MARGIN, leftImageView.frame.origin.y, CGRectGetWidth(_frame)-CGRectGetWidth(leftImageView.frame)-2*MARGIN, 0);
    
    _rightTableView=[[UITableView alloc] initWithFrame:_rightTableViewFrame style:UITableViewStylePlain];
    _rightTableView.tag=200;
    _rightTableView.dataSource=self;
    _rightTableView.delegate=self;
    [self addSubview:_rightTableView];
    
    _leftLable.text=_sourceArray[0][@"enName"];
    _rightLable.text=_sourceArray[0][@"subways"][0][@"enName"];
}

-(void)willMoveToSuperview:(UIView *)newSuperview
{
   

}

-(id)initWithFrame:(CGRect)frame
{
    self=[super initWithFrame:frame];
    if (self)
    {
        _selectIndex=0;
        _frame=frame;
    }
    return self;
}

-(NSArray *) readArrayInfoOfContentFile:(NSString *) fileName extension :(NSString *)extension
{
    
    NSArray *array=[NSArray arrayWithContentsOfFile:LOAD_BANDLE_FILE(fileName, extension)];
    return array;
}

-(instancetype)initWithFrame:(CGRect)frame fileName:(NSString *)fileName
{
    self=[self initWithFrame:frame];
    if (self)
    {
        _fileName=fileName;
    }
    return self;
}
-(void)leftClick:(UIGestureRecognizer *) ges
{
    _leftTableView.frame=_leftTableViewFrame;
     self.frame=CGRectMake(_frame.origin.x, _frame.origin.y, _frame.size.width, SCREEN_HEIGHT-_frame.origin.y-_frame.size.height);
    
    NSInteger tempHeight = ROWHEIGHT * [_sourceArray count];
    
    if (tempHeight > SCREEN_HEIGHT - _frame.origin.y - _frame.size.height)
    {
        tempHeight = SCREEN_HEIGHT - _frame.origin.y - _frame.size.height;
    }
    NSLog(@"-------------->%d",tempHeight);
    
    [UIView animateWithDuration:0.3 animations:^{
       
        _leftTableView.frame=CGRectMake(_leftTableView.frame.origin.x, _leftTableView.frame.origin.y, _leftTableView.frame.size.width, tempHeight);
        _contentView.hidden=NO;
    }];
}
-(void) rightClick:(UIGestureRecognizer *) ges
{
    _rightTableView.frame=_rightTableViewFrame;
    
    self.frame=CGRectMake(_frame.origin.x, _frame.origin.y, _frame.size.width, SCREEN_HEIGHT-_frame.origin.y-_frame.size.height);
    
    NSInteger tempHeight = ROWHEIGHT * [_sourceArray[_selectIndex][@"subways"] count];
    
    if (tempHeight > SCREEN_HEIGHT - _frame.origin.y - _frame.size.height)
    {
        tempHeight = SCREEN_HEIGHT - _frame.origin.y - _frame.size.height;
    }
    NSLog(@"-------------->%d",tempHeight);
    
    [UIView animateWithDuration:0.3 animations:^{
        
        _rightTableView.frame=CGRectMake(_rightTableView.frame.origin.x, _rightTableView.frame.origin.y, _rightTableView.frame.size.width, tempHeight);
        _rightTableView.contentSize=CGSizeMake(_rightTableView.contentSize.width, ROWHEIGHT * [_sourceArray[_selectIndex][@"subways"] count]);
        _contentView.hidden=NO;
    }];
}

-(void) hiddenTableView
{
    [UIView animateWithDuration:0.3 animations:^{
       
        _leftTableView.frame=_leftTableViewFrame;
        _rightTableView.frame=_rightTableViewFrame;
        _contentView.hidden=YES;
        self.frame=_frame;
    }];
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView.tag==100)
    {
        return [_sourceArray count];
    }
    else
    {
        return [_sourceArray[_selectIndex][@"subways"] count];
    }
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *str=@"Cell";
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:str];
    if (!cell) {
        cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:str];
        cell.textLabel.font=FONT(11);
        cell.backgroundColor=[UIColor clearColor];
    }
    if (tableView.tag == 100)
    {
        cell.textLabel.text=_sourceArray[indexPath.row][@"enName"];
    }
    else
    {
        cell.textLabel.text=_sourceArray[_selectIndex][@"subways"][indexPath.row][@"enName"];
    }
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView.tag == 100)
    {
       _selectIndex=indexPath.row;
        _rightLable.text=_sourceArray[indexPath.row][@"subways"][0][@"enName"];
        [_rightTableView reloadData];
        //_selectBlock(_sourceArray[indexPath.row][@"id"]);
        _selectBlock(_sourceArray[indexPath.row][@"subways"][0][@"id"]);
        [self hiddenTableView];
    }
    else
    {
        _rightLable.text = _sourceArray[_selectIndex][@"subways"][indexPath.row][@"enName"];
         _selectBlock(_sourceArray[_selectIndex][@"subways"][indexPath.row][@"id"]);
        [self hiddenTableView];
        
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return ROWHEIGHT;
}

@end
