//
//  HELinkageTableView.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-6-14.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//
#define ROWHEIGHT 30
#define TABLE_MARGIN 20

#import "HELinkageTableView.h"
#import "AlertCustom.h"

@implementation HELinkageTableView
{
    UITableView *_tableView;
    NSArray *_sourceArray;
    HELinkTableViewClcikType _clickType;
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
      
    }
    return self;
}
-(void)show
{
    [AlertCustom showWithView:self];
}

-(instancetype)initWithWithArray:(HELinkTableViewClcikType)clickType array:(NSArray *)array
{
    self = [super initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH - (2 * TABLE_MARGIN), 0)];
    if (self)
    {
        self.backgroundColor = [UIColor clearColor];
        _sourceArray = array;
        _clickType = clickType;
        
        _tableView = [[UITableView alloc] initWithFrame:self.bounds];
        _tableView.backgroundColor = [UIColor clearColor];
        UIImageView *backImage = [[UIImageView alloc] initWithImage:LOAD_IMAGE(@"background2.png")];
        UIImage *tmpImage = IMAGE_STRRTCHABLE(backImage.image, 20, 20);
        backImage.image = tmpImage;
        //backImage.alpha = 0.8;
        _tableView.backgroundView = backImage;
        
        NSInteger tempHeight = [array count] * ROWHEIGHT;
        if (tempHeight > SCREEN_HEIGHT - (2 * TABLE_MARGIN))
        {
            tempHeight = SCREEN_HEIGHT - (2 * TABLE_MARGIN);
        }
        self.frame = CGRectMake(0, 0,SCREEN_WIDTH - (2 * TABLE_MARGIN), tempHeight);
        _tableView.frame = CGRectMake(0, 0, SCREEN_WIDTH - (2 * TABLE_MARGIN), tempHeight);
        [self addSubview:_tableView];
        _tableView.dataSource = self;
        _tableView.delegate = self;
        
        
    }
    return self;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [_sourceArray count];
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *str = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:str];
    if (!cell)
    {
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:str];
        cell.backgroundColor = [UIColor clearColor];
        cell.textLabel.font = FONT(13);
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    cell.textLabel.text = _sourceArray[indexPath.row][@"enName"];
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    cell.accessoryType = UITableViewCellAccessoryCheckmark;
    if (_selectBlock)
    {
        if (_clickType == HELinkTableViewClickLeft)
        {
            _selectBlock(_sourceArray[indexPath.row][@"subways"][0][@"id"],_sourceArray[indexPath.row][@"subways"][0][@"enName"],indexPath.row);
        }
        else
        {
            _selectBlock(_sourceArray[indexPath.row][@"id"],_sourceArray[indexPath.row][@"enName"],indexPath.row);
        }
        
    }
    [AlertCustom dismissWithView:self];
    
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return ROWHEIGHT;
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
