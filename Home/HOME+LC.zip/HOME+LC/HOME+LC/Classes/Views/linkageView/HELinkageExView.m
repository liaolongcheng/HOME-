//
//  HELinkageExView.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-6-14.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//
#define IMAGENAME @"line1.png"
#define MARGIN 5
#import "HELinkageExView.h"

@implementation HELinkageExView
{
    NSString *_fileName;
    CGRect _frame;
    NSArray *_sourceArray;
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

-(void)willMoveToSuperview:(UIView *)newSuperview
{
   
    
    _leftLable=[[UILabel alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth(_frame)*0.4, CGRectGetHeight(_frame))];
    _leftLable.userInteractionEnabled=YES;
    _leftLable.text=@"leftLable";
    _leftLable.textAlignment=NSTextAlignmentCenter;
    _leftLable.font=FONT(13);
    [self addSubview:_leftLable];
    
    _sourceArray=[self readArrayInfoOfContentFile:_fileName extension:@"plist"];
    
    UIGestureRecognizer *leftGes=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(leftClick:)];
    [_leftLable addGestureRecognizer:leftGes];
    
    UIImageView *leftImageView=[[UIImageView alloc] initWithFrame:CGRectMake(0, CGRectGetHeight(_frame), CGRectGetWidth(_frame)*0.4, 2)];
    leftImageView.userInteractionEnabled=NO;
    leftImageView.image=LOAD_IMAGE(IMAGENAME);
    [self addSubview:leftImageView];
    
    
    
    _rightLable=[[UILabel alloc] initWithFrame:CGRectMake(leftImageView.frame.origin.x + CGRectGetWidth(leftImageView.frame)+MARGIN, 0, CGRectGetWidth(_frame)-CGRectGetWidth(leftImageView.frame)-2*MARGIN, CGRectGetHeight(_frame))];
    _rightLable.text=@"rightLable";
    _rightLable.textAlignment=NSTextAlignmentCenter;
    _rightLable.userInteractionEnabled=YES;
    _rightLable.font=FONT(13);
    [self addSubview:_rightLable];
    
    UIGestureRecognizer *rightGes=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(rightClick:)];
    [_rightLable addGestureRecognizer:rightGes];
    
    
    UIImageView *rightImageView=[[UIImageView alloc] initWithFrame:CGRectMake(leftImageView.frame.origin.x + CGRectGetWidth(leftImageView.frame)+MARGIN, leftImageView.frame.origin.y, CGRectGetWidth(_frame)-CGRectGetWidth(leftImageView.frame)-2*MARGIN, 2)];
    rightImageView.image=LOAD_IMAGE(IMAGENAME);
    [self addSubview:rightImageView];
    
    _leftLable.text=_sourceArray[0][@"enName"];
    _rightLable.text=_sourceArray[0][@"subways"][0][@"enName"];
}

-(instancetype) initWithFrame:(CGRect)frame fileName:(NSString *)fileName
{
    self = [super initWithFrame:frame];
    if (self)
    {
         _fileName = fileName;
        _frame = frame;
        _selectIndex = 0;
    }
    return self;
}


-(NSArray *) readArrayInfoOfContentFile:(NSString *) fileName extension :(NSString *)extension
{
    
    NSArray *array=[NSArray arrayWithContentsOfFile:LOAD_BANDLE_FILE(fileName, extension)];
    return array;
}

-(void) leftClick:(UIGestureRecognizer *) ges
{
    HELinkageTableView *linkTableView = [[HELinkageTableView alloc] initWithWithArray:HELinkTableViewClickLeft array:_sourceArray];
    linkTableView.backgroundColor = [UIColor clearColor];
    linkTableView.selectBlock = ^(NSString *selId,NSString *selName,NSInteger selectIndex)
    {
        _selectIndex = selectIndex;
        _rightLable.text = selName;
        _leftLable.text = _sourceArray[selectIndex][@"enName"];
        if (_selectBlock)
        {
            _selectBlock(selId);
        }
  
    };
    [linkTableView show];
}


-(void) rightClick:(UIGestureRecognizer *) ges
{
    HELinkageTableView *linkTableView = [[HELinkageTableView alloc] initWithWithArray:HELinkTableViewClickRight array:_sourceArray[_selectIndex][@"subways"]];
    linkTableView.backgroundColor = [UIColor clearColor];
    linkTableView.selectBlock = ^(NSString *selId,NSString *selName,NSInteger selectIndex)
    {
        _rightLable.text = selName;
        if (_selectBlock)
        {
            _selectBlock(selId);
        }
     
    };
    [linkTableView show];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
