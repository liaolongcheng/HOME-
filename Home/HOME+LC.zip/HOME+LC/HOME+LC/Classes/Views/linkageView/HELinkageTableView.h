//
//  HELinkageTableView.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-6-14.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

typedef NS_ENUM(int, HELinkTableViewClcikType)
{
    HELinkTableViewClickLeft=0,
    HELinkTableViewClickRight=1
};

typedef void(^HELinkTableViewSelectBlock)(NSString *selectId,NSString *selectName,NSInteger selectIndex);

#import <UIKit/UIKit.h>
@interface HELinkageTableView : UIView<UITableViewDelegate,UITableViewDataSource>

@property(nonatomic,copy) HELinkTableViewSelectBlock selectBlock;

-(instancetype) initWithWithArray:(HELinkTableViewClcikType) clickType array:(NSArray *) array;

-(void) show;

@end
