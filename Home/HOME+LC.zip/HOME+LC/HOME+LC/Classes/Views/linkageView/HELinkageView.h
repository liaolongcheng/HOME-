//
//  HELinkageView.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-18.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^HELinkageViewSelectBlock)(NSString *str);

@interface HELinkageView : UIView<UITableViewDataSource,UITableViewDelegate>

-(instancetype) initWithFrame:(CGRect)frame fileName:(NSString *)fileName;

@property(nonatomic,copy) HELinkageViewSelectBlock selectBlock;

@end
