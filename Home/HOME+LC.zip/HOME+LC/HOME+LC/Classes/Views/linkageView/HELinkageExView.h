//
//  HELinkageExView.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-6-14.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

typedef void(^HELinkageViewSelectBlock)(NSString *str);
#import <UIKit/UIKit.h>
#import "HELinkageTableView.h"

@interface HELinkageExView : UIView

@property(nonatomic,copy) HELinkageViewSelectBlock selectBlock;

@property (nonatomic,strong) UILabel *leftLable;
@property (nonatomic,strong) UILabel *rightLable;
@property (nonatomic,assign) NSInteger selectIndex;

-(instancetype) initWithFrame:(CGRect)frame fileName:(NSString *)fileName;

@end
