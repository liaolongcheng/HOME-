//
//  ComBoxView.h
//  myCombox
//
//  Created by liaolongcheng on 14-3-1.
//  Copyright (c) 2014年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ComBoxViewTextView.h"

@interface ComBoxView : UIView<UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate>


@property (nonatomic,strong) NSMutableArray *dataSource;
@property (nonatomic,strong) ComBoxViewTextView *textView;
@property (nonatomic,strong) UITableView *table;
@property (nonatomic,assign) BOOL textViewIsUsed;

@end
