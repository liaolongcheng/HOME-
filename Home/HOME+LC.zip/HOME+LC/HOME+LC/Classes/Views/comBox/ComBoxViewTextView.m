//
//  ComBoxView.m
//  myCombox
//
//  Created by liaolongcheng on 14-3-1.
//  Copyright (c) 2014年 apple. All rights reserved.
//

#import "ComBoxViewTextView.h"


@implementation ComBoxViewTextView
{

    
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        

        
                
        
          }
    return self;
}

-(BOOL)canBecomeFirstResponder
{
    return NO;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
