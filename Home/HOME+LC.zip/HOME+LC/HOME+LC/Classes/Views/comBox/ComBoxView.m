//
//  ComBoxView.m
//  myCombox
//
//  Created by liaolongcheng on 14-3-1.
//  Copyright (c) 2014年 apple. All rights reserved.
//

#import "ComBoxView.h"



@implementation ComBoxView
{
    BOOL isOpen;
    CGRect tempRect;
}


- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        
        _dataSource=[NSMutableArray array];
        tempRect=frame;
        _textViewIsUsed=NO;
        isOpen = NO;
        
        UIView *tempView=[[UIView alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.height)];
        [self addSubview:tempView];
//        tempView.layer.borderWidth=1.0f;
//        tempView.layer.borderColor=[UIColor grayColor].CGColor;
//        tempView.layer.masksToBounds=YES;
//        tempView.layer.cornerRadius=5.0f;
       
        
        _textView=[[ComBoxViewTextView alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.height)];
        _textView.enabled=YES;
        _textView.delegate=self;
        _textView.backgroundColor=[UIColor clearColor];
        _textView.borderStyle=UITextBorderStyleRoundedRect;
        [self addSubview:_textView];
        
//        __block ComBoxView *aa=self;
        
//        button=[[BHButton alloc] initWithFrame:CGRectMake(frame.size.width-frame.size.height,0, frame.size.height, frame.size.height)];
//        [button setButtonOnClickListener:^(UIButton *btn) {
//            
//            [aa annimationComBox];
//            
//        }];
    
//        [button setImage:[UIImage imageNamed:@"dropup.png"] forState:UIControlStateNormal];
//        [button setImage:[UIImage imageNamed:@"dropdown.png"] forState:UIControlStateSelected];
//        [self addSubview:button];
        
        _table=[[UITableView alloc] initWithFrame:CGRectMake(5, frame.size.height, frame.size.width-10, [_dataSource count]*30) style:UITableViewStylePlain];
        _table.backgroundColor=[UIColor whiteColor];
        _table.layer.borderColor=[UIColor grayColor].CGColor;
        _table.layer.borderWidth=2.0;
        _table.delegate=self;
        _table.dataSource=self;
        _table.rowHeight=30;
        [self addSubview:_table];
        
    }
    return self;
}

-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    [self annimationComBox];
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    [textField resignFirstResponder];
}
-(void) annimationComBox
{
    
    if (isOpen == NO)
    {
//        button.selected=YES;
        isOpen = YES;
        if ([_dataSource count]*_table.rowHeight<=120) {
            
            [UIView animateWithDuration:0.3 animations:^{
                self.frame=CGRectMake(tempRect.origin.x, tempRect.origin.y, tempRect.size.width,[_dataSource count]*_table.rowHeight+30);
                _table.frame=CGRectMake(5, tempRect.size.height, tempRect.size.width-10, [_dataSource count]*_table.rowHeight);
            }];
        }
        else
        {
            [UIView animateWithDuration:0.4 animations:^{
                self.frame=CGRectMake(tempRect.origin.x, tempRect.origin.y, tempRect.size.width,150);
                _table.frame=CGRectMake(5, tempRect.size.height, tempRect.size.width-10, 120);
            }];
            
        }
    }
    else
    {
//        button.selected=NO;
        isOpen = NO;
        [UIView animateWithDuration:0.4 animations:^{
            self.frame=CGRectMake(tempRect.origin.x, tempRect.origin.y, tempRect.size.width,30);
            _table.frame=CGRectMake(5, tempRect.size.height, tempRect.size.width-10, 0);
        }];
        
        
    }

}
-(void)setDataSource:(NSMutableArray *)dataSource
{
    [_dataSource removeAllObjects];
    [_dataSource addObjectsFromArray:dataSource];
    [_table reloadData];
}
-(void)setTextViewIsUsed:(BOOL)textViewIsUsed
{
    _textView.enabled=textViewIsUsed;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [_dataSource count];
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *str=@"Cell";
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:str];
    if (cell==nil) {
        cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:str];
    }
    cell.textLabel.text=_dataSource[indexPath.row];
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    _textView.text=_dataSource[indexPath.row];
    [self annimationComBox];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
