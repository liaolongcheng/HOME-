//
//  HERegisterPhotoCell.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-26.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HERegisterViewController.h"

@interface HERegisterPhotoCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UIImageView *registerPhotoImageView;
@property (assign, nonatomic) BOOL isUpdate;

@end
