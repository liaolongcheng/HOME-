//
//  HERegisterPhotoCell.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-26.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HERegisterPhotoCell.h"
#import "AlertCustom.h"
#import "HECheckPhotoView.h"
#import "HEUserRegister.h"
#import "HEUserLogin.h"

@implementation HERegisterPhotoCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}
-(void)willMoveToSuperview:(UIView *)newSuperview
{
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    
    if (self.isUpdate && self.registerPhotoImageView.image == nil)
    {
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:IMAGEURLCREATE([HEUserLogin sharedLogin].profile_image)];
        [request addValue:@"image/*" forHTTPHeaderField:@"Accept"];
        
        
        [self.registerPhotoImageView setImageWithURLRequest:request placeholderImage:nil success:^(NSURLRequest *request, NSHTTPURLResponse *response, UIImage *image) {
          
        } failure:nil];

    }
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(addPhoto:)];
    [self.registerPhotoImageView addGestureRecognizer:tap];
}
-(void) addPhoto:(UIGestureRecognizer *)ges
{
    HECheckPhotoView *checkPhoto=[[HECheckPhotoView alloc] initWith:^(UIImage *ckeckedImage) {
        self.registerPhotoImageView.image = ckeckedImage;
        HEUserRegister *registe=[HEUserRegister sharedRegister];
        registe.profile_image=UIImageJPEGRepresentation(ckeckedImage,1.0);
    }];
    [AlertCustom showWithView:checkPhoto];
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
