//
//  HERegisterContentCell.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-26.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HERegisterContentCell.h"
#import "HEUserRegister.h"
#import <QuartzCore/QuartzCore.h>
#import "NSString+Category.h"

@implementation HERegisterContentCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}
-(void)willMoveToSuperview:(UIView *)newSuperview
{
    self.registerContentBackGroundImageView.image = IMAGE_STRRTCHABLE(self.registerContentBackGroundImageView.image, 20, 20);
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    self.layer.borderWidth=0;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
}

- (IBAction)privateClick:(id)sender
{
    _registerViewController.defaultHeight = 430;
    [_registerViewController.registerMainTableView reloadSections:[NSIndexSet indexSetWithIndex:1] withRowAnimation:UITableViewRowAnimationFade];
}

- (IBAction)agencyClick:(id)sender
{
    _registerViewController.defaultHeight = 500;
    [_registerViewController.registerMainTableView reloadSections:[NSIndexSet indexSetWithIndex:1] withRowAnimation:UITableViewRowAnimationFade];
}

- (IBAction)cancelClick:(id)sender
{
    [_registerViewController.navigationController popViewControllerAnimated:YES];
}

- (IBAction)sureClick:(id)sender
{
    
    HEUserRegister *registe = [HEUserRegister sharedRegister];
      
    if (IS_KONG_STRING(self.nameText.text))
    {
        BH_ALERT(@"Please fill in the name");
        return;
    }
    if(IS_KONG_STRING(self.telephoneText.text))
    {
        BH_ALERT(@"Please fill in the phone");
        return;
    }
    if(IS_KONG_STRING(self.passwordText.text))
    {
        BH_ALERT(@"Please fill in the password");
        return;
    }
    if(IS_KONG_STRING(self.emailText.text))
    {
        BH_ALERT(@"Please fill in the email");
        return;
    }
    if (![self.passwordText.text isEqualToString:self.confirmText.text])
    {
        BH_ALERT(@"Two passwords do not match");
        return;
    }
    if ([NSString validateEmail:self.emailText.text] != isRight)
    {
        BH_ALERT(@"E-mail is incorrect");
        return;
    }
    if([NSString validateTel:self.telephoneText.text] != isRight)
    {
        BH_ALERT(@"Phone is not correct");
        return;
    }
   
    registe.type = @"consumer";
    
    if (self.AgencyButton.selected == YES)
    {
        if (IS_KONG_STRING(self.companyText.text))
        {
            BH_ALERT(@"Please fill in the company");
            return;
        }
        else
        {
            registe.company = self.companyText.text;
        }
       
        if(IS_KONG_STRING(self.addressText.text))
        {
            BH_ALERT(@"Please fill in the address");
            return;
        }
        else
        {
            registe.address = self.addressText.text;
        }
        
        registe.type=@"seller";
    }
    
    registe.phone = self.telephoneText.text;
    registe.pass = self.passwordText.text;
    registe.name = self.nameText.text;
    registe.email = self.emailText.text;

    [registe resiterUserWithSuccess:^(id successObject) {
        
        [SVProgressHUD showSuccessWithStatus:@"注册成功,请登陆" duration:1.0];
        
    } registerError:^{
        
        [SVProgressHUD showErrorWithStatus:@"注册失败..." duration:1.0];
        
    }];
    
}
@end
