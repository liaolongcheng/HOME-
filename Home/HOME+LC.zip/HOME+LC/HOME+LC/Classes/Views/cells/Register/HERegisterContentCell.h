//
//  HERegisterContentCell.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-26.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HERegisterViewController.h"

@interface HERegisterContentCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UIImageView *registerContentBackGroundImageView;
@property (strong, nonatomic) IBOutlet UIButton *leftButton;
@property (weak, nonatomic) HERegisterViewController *registerViewController;
@property (strong, nonatomic) IBOutlet UIView *agencyView;
@property (strong, nonatomic) IBOutlet UIButton *AgencyButton;
@property (strong, nonatomic) IBOutlet UIButton *privateButton;
@property (strong, nonatomic) IBOutlet UITextField *nameText;
@property (strong, nonatomic) IBOutlet UITextField *companyText;
@property (strong, nonatomic) IBOutlet UITextField *addressText;
@property (strong, nonatomic) IBOutlet UITextField *emailText;
@property (strong, nonatomic) IBOutlet UITextField *telephoneText;
@property (strong, nonatomic) IBOutlet UITextField *passwordText;
@property (strong, nonatomic) IBOutlet UITextField *confirmText;
- (IBAction)privateClick:(id)sender;
- (IBAction)agencyClick:(id)sender;
- (IBAction)cancelClick:(id)sender;
- (IBAction)sureClick:(id)sender;

@end
