//
//  HEReceiveMessageCell.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-6-8.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEReceiveMessageCell.h"

@implementation HEReceiveMessageCell
{
    closeButtonClick _closeButtonClick;
    deleteButtonClick _deleteButtonClick;
    replyButtonClcik _replyButtonClick;
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}



- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(instancetype)initWtihOpenClick:(closeButtonClick)closeButtonClcik delteButtonClick:(deleteButtonClick)delteButtonClick replyButtonClick:(replyButtonClcik)replyButtonClick
{
    self=LOAD_TABLEVIEWCELL(@"HEReceiveMessageCell");
    if (self) {
        self.backgroundColor=[UIColor clearColor];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        _closeButtonClick=closeButtonClcik;
        _deleteButtonClick=delteButtonClick;
        _replyButtonClick = replyButtonClick;
    }
    return self;
}
-(NSIndexPath *) getIndexPath
{
    UITableView *tableView=(UITableView*)[[self superview] superview];
    NSIndexPath *indexPath=[tableView indexPathForCell:self];
    return indexPath;
}

- (IBAction)closeButtonClick:(id)sender
{
    UIButton *button = (UIButton *)sender;
    button.selected = !button.selected;
    _closeButtonClick([self getIndexPath],button,button.selected);
}

- (IBAction)deleteButtonClick:(id)sender
{
    UIButton *button = (UIButton *)sender;
    _deleteButtonClick([self getIndexPath],button);
}

- (IBAction)replyButtonClick:(id)sender
{
    UIButton *button = (UIButton *)sender;
    _replyButtonClick([self getIndexPath],button);
}
@end
