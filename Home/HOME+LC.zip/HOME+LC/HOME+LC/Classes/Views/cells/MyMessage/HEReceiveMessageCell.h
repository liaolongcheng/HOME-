//
//  HEReceiveMessageCell.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-6-8.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void(^closeButtonClick)(NSIndexPath *buttonIndexPath,UIButton *button,BOOL isOpen);
typedef void(^deleteButtonClick)(NSIndexPath *buttonIndexPath,UIButton *button);
typedef void(^replyButtonClcik)(NSIndexPath *ButtonIndexPath,UIButton *button);


@interface HEReceiveMessageCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *targetLable;
@property (strong, nonatomic) IBOutlet UILabel *fromLable;
@property (strong, nonatomic) IBOutlet UILabel *timeLable;
@property (strong, nonatomic) IBOutlet UITextView *messageText;
@property (strong, nonatomic) IBOutlet UIButton *closeButton;
@property (weak, nonatomic) IBOutlet UIButton *deleteButton;
@property (weak, nonatomic) IBOutlet UIButton *replyButton;


-(instancetype) initWtihOpenClick:(closeButtonClick)closeButtonClcik delteButtonClick:(deleteButtonClick) delteButtonClick replyButtonClick:(replyButtonClcik) replyButtonClick;


- (IBAction)closeButtonClick:(id)sender;
- (IBAction)deleteButtonClick:(id)sender;
- (IBAction)replyButtonClick:(id)sender;

@end
