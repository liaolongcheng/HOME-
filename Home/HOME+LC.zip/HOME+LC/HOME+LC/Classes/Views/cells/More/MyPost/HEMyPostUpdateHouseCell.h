//
//  HEMyPostUpdateHouseCell.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-6-11.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HEMyPostUpdateHouseCell : UITableViewCell<UIScrollViewDelegate,UITextFieldDelegate>

@property (strong, nonatomic) IBOutlet UIScrollView *photoScrollView;
@property (strong, nonatomic) IBOutlet UIPageControl *photoPageControlView;
@property (strong, nonatomic) IBOutlet UITextField *titleText;
@property (strong, nonatomic) IBOutlet UITextField *priceText;
@property (strong, nonatomic) IBOutlet UITextField *bathroomsText;
@property (strong, nonatomic) IBOutlet UITextField *livingroomsText;
@property (strong, nonatomic) IBOutlet UIButton *outSpaceButton;

@property (strong, nonatomic) IBOutlet UITextField *bedroomsText;
@property (strong, nonatomic) IBOutlet UIButton *sharedButton;
@property (strong, nonatomic) IBOutlet UITextField *sizeText;
@property (strong, nonatomic) IBOutlet UITextField *totalFloorText;
@property (strong, nonatomic) IBOutlet UITextField *floorText;
@property (strong, nonatomic) IBOutlet UIView *areaView;
@property (strong, nonatomic) IBOutlet UIView *metroView;
@property (strong, nonatomic) IBOutlet UITextField *addressText;
@property (strong, nonatomic) IBOutlet UITextView *descriptionTextView;
@property (weak, nonatomic) IBOutlet UITextField *houseTypeText;

@property (nonatomic,assign) UIViewController *viewController;

-(instancetype) initWithNibAndHouseId:(NSString *)houseId;
- (IBAction)updateButtonClick:(id)sender;
- (IBAction)cancelButtonClick:(id)sender;
- (IBAction)outSpaceButtonClcik:(id)sender;
- (IBAction)sharedButtonClick:(id)sender;
- (IBAction)gpsButtonClick:(id)sender;

@end
