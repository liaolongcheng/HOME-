//
//  HEMyPostCell.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-6-10.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

typedef void(^closeButtonClick)(NSIndexPath *buttonIndexPath,UIButton *button,BOOL isOpen);
typedef void(^deleteButtonClick)(NSIndexPath *buttonIndexPath,UIButton *button);
typedef void(^replyButtonClcik)(NSIndexPath *ButtonIndexPath,UIButton *button);

#import "HEBaseCell.h"

@interface HEMyPostCell : HEBaseCell

@property (strong, nonatomic) IBOutlet UIImageView *photoImageView;
@property (strong, nonatomic) IBOutlet UILabel *nameLable;
@property (strong, nonatomic) IBOutlet UILabel *priceLable;
@property (strong, nonatomic) IBOutlet UITextView *descriptionText;
@property (strong, nonatomic) IBOutlet UIButton *closeButton;
@property (weak, nonatomic) IBOutlet UIButton *deleteButton;
@property (weak, nonatomic) IBOutlet UIButton *updateButton;

-(instancetype)initWtihOpenClick:(closeButtonClick)closeButtonClcik delteButtonClick:(deleteButtonClick)delteButtonClick replyButtonClick:(replyButtonClcik)replyButtonClick;
- (IBAction)closeButtonClick:(id)sender;
- (IBAction)deleteButtonClick:(id)sender;
- (IBAction)updateButtonClick:(id)sender;

@end
