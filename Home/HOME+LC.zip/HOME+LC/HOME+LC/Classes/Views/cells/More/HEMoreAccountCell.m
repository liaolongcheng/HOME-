//
//  HEMoreAccountCell.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-16.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEMoreAccountCell.h"
#import "HELoginViewController.h"
#import "HEMoreMyAccountViewController.h"
#import "HEMoreMyMessageViewController.h"
#import "HEMoreMyPasswordViewController.h"

@implementation HEMoreAccountCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (IBAction)myAccountClick:(id)sender
{
    [self.viewController hiddenTabBar];
    if (!USER_ISLOGIN)
    {
        HELoginViewController *login=[[HELoginViewController alloc] init];
        [self.viewController.navigationController pushViewController:login animated:YES];
    }
    else
    {
        HEMoreMyAccountViewController *myAccount=[[HEMoreMyAccountViewController alloc] initWithNibName:@"HEMoreMyAccountViewController" bundle:nil];
        [self.viewController.navigationController pushViewController:myAccount animated:YES];
    }
}

- (IBAction)myMessageClick:(id)sender
{
    
    if (USER_ISLOGIN)
    {
        [self.viewController hiddenTabBar];
        HEMoreMyMessageViewController *myMessage=[[HEMoreMyMessageViewController alloc] init];
        [self.viewController.navigationController pushViewController:myMessage animated:YES];
    }
    else
    {
        HELoginViewController *login=[[HELoginViewController alloc] init];
        [self.viewController.navigationController pushViewController:login animated:YES];
    }
}

- (IBAction)myPasswordClick:(id)sender
{
    if (USER_ISLOGIN)
    {
        [self.viewController hiddenTabBar];
        HEMoreMyPasswordViewController *password = [[HEMoreMyPasswordViewController alloc] initWithNibName:@"HEMoreMyPasswordViewController" bundle:nil];
        [self.viewController.navigationController pushViewController:password animated:YES];
    }
    else
    {
        HELoginViewController *login=[[HELoginViewController alloc] init];
        [self.viewController.navigationController pushViewController:login animated:YES];
    }

}
@end
