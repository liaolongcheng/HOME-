//
//  HEMorePostCell.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-16.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HEBaseCell.h"

@interface HEMorePostCell : HEBaseCell

- (IBAction)myPostClick:(id)sender;
- (IBAction)myCommentsClick:(id)sender;
@end
