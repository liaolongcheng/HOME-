//
//  HEMoreSettingsCell.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-16.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEMoreSettingsCell.h"

@implementation HEMoreSettingsCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


- (IBAction)closeButtonClick:(id)sender
{
 
    UIButton *btn=(UIButton *)sender;
    
    btn.selected = ! btn.selected;
    self.mainViewController.isClose = !self.mainViewController.isClose;
    
    UITableView *tableView=(UITableView *)[[self superview] superview];

    [tableView reloadSections:[NSIndexSet indexSetWithIndex:[tableView indexPathForCell:self].section] withRowAnimation:UITableViewRowAnimationFade];
    
}
@end
