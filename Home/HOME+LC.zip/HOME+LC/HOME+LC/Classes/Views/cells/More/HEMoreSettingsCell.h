//
//  HEMoreSettingsCell.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-16.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HEMoreViewController.h"
#import "HEBaseCell.h"

@interface HEMoreSettingsCell : HEBaseCell

@property(nonatomic,assign) HEMoreViewController *mainViewController;
@property (strong, nonatomic) IBOutlet UIButton *closeButton;
@property (weak, nonatomic) IBOutlet UILabel *pushLable;
@property (weak, nonatomic) IBOutlet UILabel *updateLable;
@property (weak, nonatomic) IBOutlet UISwitch *switc1;
@property (weak, nonatomic) IBOutlet UISwitch *switc2;
@property (weak, nonatomic) IBOutlet UIImageView *line1View;


- (IBAction)closeButtonClick:(id)sender;

@end
