//
//  HEMorePostCell.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-16.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEMorePostCell.h"
#import "HEMoreMyPostHouseViewController.h"
#import "HELoginViewController.h"
#import "HEMoreMyCommentsViewController.h"

@implementation HEMorePostCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (IBAction)myPostClick:(id)sender
{
    if (USER_ISLOGIN)
    {
        HEMoreMyPostHouseViewController *myPostHouse=[[HEMoreMyPostHouseViewController alloc] init];
        [self.viewController hiddenTabBar];
        [self.viewController.navigationController pushViewController:myPostHouse animated:YES];
    }
    else
    {
        HELoginViewController *login=[[HELoginViewController alloc] init];
        [self.viewController.navigationController pushViewController:login animated:YES];
    }
}

- (IBAction)myCommentsClick:(id)sender
{
    if (USER_ISLOGIN)
    {
        HEMoreMyCommentsViewController *myComment=[[HEMoreMyCommentsViewController alloc] init];
        [self.viewController hiddenTabBar];
        [self.viewController.navigationController pushViewController:myComment animated:YES];
    }
    else
    {
        HELoginViewController *login=[[HELoginViewController alloc] init];
        [self.viewController.navigationController pushViewController:login animated:YES];
    }

}
@end
