//
//  HEMoreStatementCell.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-16.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEMoreStatementCell.h"

@implementation HEMoreStatementCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (IBAction)closeButtonClick:(id)sender
{
    UIButton *btn=(UIButton *)sender;
    
    btn.selected = ! btn.selected;
}
@end
