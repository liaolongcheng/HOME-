//
//  HEMoreContactCell.m
//  HOME+LC
//
//  Created by user on 14/10/29.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEMoreContactCell.h"

@implementation HEMoreContactCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (IBAction)telephoneClick:(id)sender {
}

- (IBAction)mailClick:(id)sender {
}
@end
