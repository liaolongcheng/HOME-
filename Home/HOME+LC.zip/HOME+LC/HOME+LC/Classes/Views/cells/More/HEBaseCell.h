//
//  HEBaseCell.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-31.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HEBaseViewController.h"

@interface HEBaseCell : UITableViewCell

@property (nonatomic,assign) HEBaseViewController *viewController;

@end
