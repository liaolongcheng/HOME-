//
//  HEMyPostUpdateHouseCell.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-6-11.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#define FORSTRING(str) [NSString stringWithFormat:@"%@",str]


#import "HEMyPostUpdateHouseCell.h"
#import <QuartzCore/QuartzCore.h>
#import "HELinkageView.h"
#import "HELinkageExView.h"
#import "HEHouseInfo.h"
#import "AreaAndLinesUtily.h"
#import "HECheckPhotoView.h"
#import "AlertCustom.h"
#import "HECheckRoomsView.h"
#import "HECheckHouseTypeView.h"
#import "AreaAndLinesUtily.h"
#import "HEHomeMapViewController.h"

@implementation HEMyPostUpdateHouseCell
{
    NSString *_area;
    NSString *_metro;
    
    NSMutableArray *_photosArray;
    
    NSString *_houseId;
    NSString *_houseType;
    NSString *_longitude;
    NSString *_latitude;
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

-(void)didMoveToSuperview
{
    CGRect controlRect = [self.photoScrollView convertRect:self.photoPageControlView.frame toView:self];
    [self.photoPageControlView removeFromSuperview];
    self.photoPageControlView = [[UIPageControl alloc] initWithFrame:controlRect];
    [self addSubview:self.photoPageControlView];
    
    self.photoPageControlView.pageIndicatorTintColor = [UIColor grayColor];
    self.photoPageControlView.currentPageIndicatorTintColor = [UIColor orangeColor];
    self.photoPageControlView.userInteractionEnabled = NO;
    self.photoScrollView.pagingEnabled = YES;
    self.photoScrollView.delegate = self;
}

-(instancetype)initWithNibAndHouseId:(NSString *)houseId
{
    self = LOAD_TABLEVIEWCELL(@"HEMyPostUpdateHouseCell");
    if (self)
    {
        _houseId = houseId;
        self.backgroundColor = [UIColor clearColor];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        self.layer.borderColor = [UIColor clearColor].CGColor;
        self.layer.borderWidth = 0.0f;
        self.bedroomsText.delegate = self;
        self.bathroomsText.delegate = self;
        self.livingroomsText.delegate = self;
        self.sizeText.delegate = self;
        self.totalFloorText.delegate = self;
        self.floorText.delegate = self;
        self.houseTypeText.delegate = self;
        
    
        self.hidden = YES;
        
        HEHouseInfo *houseInfo = [[HEHouseInfo alloc] init];
        houseInfo.houseId = houseId;
        [houseInfo requestHouseInfoWithSuccess:^(id houseInfo) {
            
            self.hidden = NO;
            _photosArray = [[NSMutableArray alloc] initWithCapacity:[houseInfo[@"pictures"] count]];
           
            
            for(int i=0;i<[houseInfo[@"pictures"] count];i++)
            {
                
                UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(i*CGRectGetWidth(self.photoScrollView.frame), 0, CGRectGetWidth(self.photoScrollView.frame), CGRectGetHeight(self.photoScrollView.frame))];
                imageView.tag = i + 100;
                
                UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(photoClick:)];
                [imageView addGestureRecognizer:tap];
                
                __weak __typeof(UIImageView *)weakImageView = imageView;
                
                NSMutableURLRequest *request = [[NSMutableURLRequest alloc] initWithURL:IMAGEURLCREATE(houseInfo[@"pictures"][i])];
                [imageView setImageWithURLRequest:request placeholderImage:DEFAULTIMAGE success:^(NSURLRequest *request, NSHTTPURLResponse *response, UIImage *image) {
                    weakImageView.userInteractionEnabled = YES;
                    [_photosArray addObject:image];
                } failure:nil];
                
                [self.photoScrollView insertSubview:imageView belowSubview:self.photoPageControlView];
            }
            self.photoPageControlView.numberOfPages = [houseInfo[@"pictures"] count];
            self.photoScrollView.contentSize = CGSizeMake(CGRectGetWidth(self.photoScrollView.frame) * [houseInfo[@"pictures"] count], CGRectGetHeight(self.photoScrollView.frame));
            
           
            self.titleText.text = houseInfo[@"name_en"];
            self.priceText.text = FORSTRING(houseInfo[@"price"]);
            
            if ([[houseInfo allKeys] containsObject:@"houseType"])
            {
                _houseType = houseInfo[@"houseType"];
                self.houseTypeText.text = [[AreaAndLinesUtily sharedAreaLines] enNameWithHouseTypeId:_houseType];
            }
            _longitude = houseInfo[@"longitude"];
            _latitude = houseInfo[@"latitude"];
            
            self.bedroomsText.text = FORSTRING(houseInfo[@"bedrooms"]);
            self.bathroomsText.text = FORSTRING(houseInfo[@"bathrooms"]);
            self.livingroomsText.text = FORSTRING(houseInfo[@"livingrooms"]);
            self.outSpaceButton.selected = [houseInfo[@"outspace"] boolValue];
            self.sharedButton.selected = [houseInfo[@"share"] boolValue];
            self.sizeText.text = FORSTRING(houseInfo[@"size"]);
            self.totalFloorText.text = FORSTRING(houseInfo[@"totalFloor"]);
            self.floorText.text = FORSTRING(houseInfo[@"floor"]);
            self.addressText.text = houseInfo[@"address"];
            self.descriptionTextView.text = houseInfo[@"description_en"];
           
            if ([houseInfo[@"area"] count] != 0)
            {
                _area = houseInfo[@"area"][0];
            }
            if ([houseInfo[@"metro"] count] != 0)
            {
                _metro = houseInfo[@"metro"][0];
            }
            
            if (!_area)
            {
                _area = @"51e370f7cf71bf5d2e000009";
            }
            if (!_metro)
            {
                _metro = @"51e370f7cf71bf5d2e000017";
            }
            
            AreaAndLinesUtily *arAndLi = [AreaAndLinesUtily sharedAreaLines];
            
            HELinkageExView *areaTempView=[[HELinkageExView alloc] initWithFrame:self.areaView.frame fileName:@"areasInfo"];
            [self addSubview:areaTempView];
            areaTempView.selectBlock = ^(NSString *str)
            {
                _area=str;
            };
            
            NSRange rang = [[arAndLi enNameWithAreaId:_area] rangeOfString:@" "];
            areaTempView.leftLable.text = [[arAndLi enNameWithAreaId:_area] substringToIndex:rang.location];
            areaTempView.rightLable.text = [[arAndLi enNameWithAreaId:_area] substringFromIndex:rang.location + 1];
            areaTempView.selectIndex = [arAndLi parIndexWithAreaId:_area];
            
            
            HELinkageExView *metroTempView=[[HELinkageExView alloc] initWithFrame:self.metroView.frame fileName:@"linesInfo"];
            [self insertSubview:metroTempView belowSubview:areaTempView];
            metroTempView.selectBlock = ^(NSString *str)
            {
                _metro=str;
            };
            
            NSRange rang1 = [[arAndLi enNameWithMetroId:_metro] rangeOfString:@" "];
            
            metroTempView.leftLable.text = [[arAndLi enNameWithMetroId:_metro] substringToIndex:rang1.location + 2];
            metroTempView.rightLable.text = [[arAndLi enNameWithMetroId:_metro] substringFromIndex:rang1.location + 2];
            metroTempView.selectIndex = [arAndLi parIndexWithMetroId:_metro];
            
        } requestError:nil];
        
    }
    return self;
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    self.photoPageControlView.currentPage = scrollView.contentOffset.x / CGRectGetWidth(scrollView.frame);
}

- (IBAction)updateButtonClick:(id)sender
{
   
    HEHouseInfo *houseInfo = [[HEHouseInfo alloc] init];
    houseInfo.houseId = _houseId;
    houseInfo.housePhotos = _photosArray;
    houseInfo.nameEN = self.titleText.text;
    houseInfo.floor = [self.floorText.text intValue];
    houseInfo.totalFloor = [self.totalFloorText.text intValue];
    houseInfo.longitude = @"121.48";
    houseInfo.latitude = @"31.22";
    houseInfo.area = _area;
    houseInfo.metro = _metro;
    houseInfo.descriptionEN = self.descriptionTextView.text;
    houseInfo.address = self.addressText.text;
    houseInfo.price = self.priceText.text;
    houseInfo.outspace = self.outSpaceButton.selected;
    houseInfo.size = self.sizeText.text;
    houseInfo.share =  self.sharedButton.selected;
    houseInfo.bedrooms = self.bedroomsText.text;
    houseInfo.bathrooms = self.bathroomsText.text;
    houseInfo.livingrooms = self.livingroomsText.text;
    houseInfo.houseType = _houseType;

    
    [houseInfo updateHouseForCurrentUser:^(id houseInfo) {
     
        [self.viewController.navigationController popViewControllerAnimated:YES];
       
        [SVProgressHUD showSuccessWithStatus:@"update house success" duration:1.0];
    } requestError:nil svType:SVProgressHUDMaskTypeClear];
    
}

- (IBAction)cancelButtonClick:(id)sender
{
    [self.viewController.navigationController popViewControllerAnimated:YES];
}

- (IBAction)outSpaceButtonClcik:(id)sender
{
    UIButton *button = (UIButton *) sender;
    button.selected = !button.selected;
}

- (IBAction)sharedButtonClick:(id)sender
{
    UIButton *button = (UIButton *) sender;
    button.selected = !button.selected;
}

- (IBAction)gpsButtonClick:(id)sender
{
    HEHomeMapViewController *mapViewController = [[HEHomeMapViewController alloc] initWithLongTapMapBlock:^(NSString *Longitude, NSString *Latitude, NSString *addressInfo) {
        _longitude = Longitude;
        _latitude = Latitude;
        _addressText.text = addressInfo;
    }];
    [self.viewController.navigationController pushViewController:mapViewController animated:YES];
}

-(void) photoClick:(UIGestureRecognizer *) ges
{
    UIImageView *tapImageView = (UIImageView *) ges.view;
    
    HECheckPhotoView *check = [[HECheckPhotoView alloc] initWithAddAndReplce:^(BOOL isleft) {
        
        HECheckPhotoView *check1 = [[HECheckPhotoView alloc] initWith:^(UIImage *ckeckedImage) {
            if (isleft)
            {
                [_photosArray addObject:ckeckedImage];
                
                UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(self.photoScrollView.contentSize.width, 0, CGRectGetWidth(self.photoScrollView.frame), CGRectGetHeight(self.photoScrollView.frame))];
                imageView.userInteractionEnabled = YES;
                imageView.image = ckeckedImage;
                imageView.tag = [_photosArray count] + 99;
                [self.photoScrollView addSubview:imageView];
                
                UITapGestureRecognizer *tapGes = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(photoClick:)];
                [imageView addGestureRecognizer:tapGes];
                
                
                self.photoPageControlView.numberOfPages = [_photosArray count];
                self.photoScrollView.contentSize = CGSizeMake(CGRectGetWidth(self.photoScrollView.frame) * [_photosArray count], CGRectGetHeight(self.photoScrollView.frame));
            }
            else
            {
                [_photosArray replaceObjectAtIndex:tapImageView.tag-100 withObject:ckeckedImage];
                tapImageView.image = ckeckedImage;
            }
        }];
        [AlertCustom showWithView:check1];
    }];
    [AlertCustom showWithView:check];
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (textField.tag == 100 || textField.tag == 101 || textField.tag == 102 || textField.tag == 200)
    {
        return NO;
    }
    if (textField.tag == 103)
    {
        if (textField.text.length < 4 || [textField.text isEqualToString:@""] || [string isEqualToString:@""])
        {
            return YES;
        }
        else
        {
            return NO;
        }
    }
    if (textField.tag == 104 || textField.tag == 105)
    {
        if (textField.text.length < 2 || [textField.text isEqualToString:@""] || [string isEqualToString:@""])
        {
            return YES;
        }
        else
        {
            return NO;
        }
    }
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    
    if (textField.tag == 100 || textField.tag == 101 || textField.tag == 102)
    {
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.001 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            RESIGNFIRSTRESPONDER;
            HECheckRoomsView *roos = [[HECheckRoomsView alloc] initWithUITextField:textField];
            [AlertCustom showWithView:roos];
        });
       
    }
    else if(textField.tag == 200)
    {
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.001 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            RESIGNFIRSTRESPONDER;
            HECheckHouseTypeView *checkView = [[HECheckHouseTypeView alloc] initWithSelectHouseInfoBlock:^(NSDictionary *houseTypeInfo) {
                textField.text = houseTypeInfo[@"enName"];
                _houseType = houseTypeInfo[@"id"];
                NSLog(@"%@  houseType:%@",houseTypeInfo,_houseType);
                
            }];
            [AlertCustom showWithView:checkView];
        });
    }
}
@end
