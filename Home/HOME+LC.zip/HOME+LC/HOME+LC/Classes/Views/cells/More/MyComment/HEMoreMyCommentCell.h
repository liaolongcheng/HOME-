//
//  HEMoreMyCommentCell.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-6-17.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HERateStartView.h"

@interface HEMoreMyCommentCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *targetLable;
@property (strong, nonatomic) IBOutlet UILabel *nameLable;
@property (strong, nonatomic) IBOutlet UILabel *timeLable;
@property (strong, nonatomic) IBOutlet UITextView *contentText;
@property (strong, nonatomic) IBOutlet HERateStartView *starView;

@end
