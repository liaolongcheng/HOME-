//
//  HEMoreAccountCell.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-16.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HEBaseCell.h"

@interface HEMoreAccountCell : HEBaseCell
- (IBAction)myAccountClick:(id)sender;
- (IBAction)myMessageClick:(id)sender;
- (IBAction)myPasswordClick:(id)sender;

@end
