//
//  HEMyPostCell.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-6-10.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEMyPostCell.h"

@implementation HEMyPostCell
{
    closeButtonClick _closeButtonClick;
    deleteButtonClick _deleteButtonClick;
    replyButtonClcik _replyButtonClick;
}
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}



-(instancetype)initWtihOpenClick:(closeButtonClick)closeButtonClcik delteButtonClick:(deleteButtonClick)delteButtonClick replyButtonClick:(replyButtonClcik)replyButtonClick
{
    self=LOAD_TABLEVIEWCELL(@"HEMyPostCell");
    if (self) {
        self.backgroundColor=[UIColor clearColor];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        self.photoImageView.layer.masksToBounds = YES;
        self.photoImageView.layer.cornerRadius = 5;
        _closeButtonClick=[closeButtonClcik copy];
        _deleteButtonClick=[delteButtonClick copy];
        _replyButtonClick=[replyButtonClick copy];
    }
    return self;
}
-(NSIndexPath *) getIndexPath
{
    UITableView *tableView=(UITableView*)[[self superview] superview];
    NSIndexPath *indexPath=[tableView indexPathForCell:self];
    return indexPath;
}

- (IBAction)closeButtonClick:(id)sender
{
    UIButton *button = (UIButton *)sender;
    button.selected = !button.selected;
    _closeButtonClick([self getIndexPath],button,button.selected);
}

- (IBAction)deleteButtonClick:(id)sender
{
    UIButton *button = (UIButton *)sender;
    _deleteButtonClick([self getIndexPath],button);
}

- (IBAction)updateButtonClick:(id)sender
{
    UIButton *button = (UIButton *)sender;
    _replyButtonClick([self getIndexPath],button);
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
