//
//  HEMoreContactCell.h
//  HOME+LC
//
//  Created by user on 14/10/29.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEBaseCell.h"

@interface HEMoreContactCell : HEBaseCell

- (IBAction)telephoneClick:(id)sender;
- (IBAction)mailClick:(id)sender;
@end
