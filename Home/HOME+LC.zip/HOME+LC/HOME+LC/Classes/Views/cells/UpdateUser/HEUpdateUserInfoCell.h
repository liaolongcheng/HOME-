
//
//  HEUpdateUserInfoCell.h
//  HOME+LC
//
//  Created by user on 14/10/29.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEBaseCell.h"

@interface HEUpdateUserInfoCell : HEBaseCell

@property (weak, nonatomic) IBOutlet UIImageView *updateUserContentImageView;
@property (strong, nonatomic) IBOutlet UIButton *leftButton;
@property (strong, nonatomic) IBOutlet UIView *agencyView;
@property (strong, nonatomic) IBOutlet UIButton *AgencyButton;
@property (strong, nonatomic) IBOutlet UIButton *privateButton;
@property (strong, nonatomic) IBOutlet UITextField *nameText;
@property (strong, nonatomic) IBOutlet UITextField *companyText;
@property (strong, nonatomic) IBOutlet UITextField *addressText;
@property (strong, nonatomic) IBOutlet UITextField *emailText;
@property (strong, nonatomic) IBOutlet UITextField *telephoneText;
@property (weak, nonatomic) IBOutlet UIButton *cacleButton;

@property (weak, nonatomic) IBOutlet UIButton *loginOutButton;
- (IBAction)loginOutButtonClick:(id)sender;
- (IBAction)sureButtonClick:(id)sender;
- (IBAction)cancelButtonClick:(id)sender;

@end
