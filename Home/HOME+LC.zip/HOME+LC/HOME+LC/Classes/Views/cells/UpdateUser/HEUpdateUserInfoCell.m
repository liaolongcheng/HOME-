//
//  HEUpdateUserInfoCell.m
//  HOME+LC
//
//  Created by user on 14/10/29.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEUpdateUserInfoCell.h"
#import "HEUserRegister.h"

@implementation HEUpdateUserInfoCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}
-(void)willMoveToSuperview:(UIView *)newSuperview
{
    [super willMoveToSuperview:newSuperview];
    self.backgroundColor = [UIColor clearColor];
    self.updateUserContentImageView.image = IMAGE_STRRTCHABLE(self.updateUserContentImageView.image, 20, 20);
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    self.layer.borderWidth=0;
    
    HEUserLogin *login = [HEUserLogin sharedLogin];
    self.nameText.text = login.name;
    if ([login.type isEqualToString:@"seller"])
    {
        self.companyText.text = login.company;
        self.addressText.text = login.address;
        self.agencyView.hidden = NO;
        
        [self.privateButton setUserInteractionEnabled:YES];
        [self.privateButton setSelected:NO];
        [self.AgencyButton setUserInteractionEnabled:NO];
        [self.AgencyButton setSelected:YES];
    }
    else
    {
        self.agencyView.hidden = YES;
        [self.privateButton setUserInteractionEnabled:NO];
        [self.privateButton setSelected:YES];
        [self.AgencyButton setUserInteractionEnabled:YES];
        [self.AgencyButton setSelected:NO];
    }
    self.emailText.text = login.email;
    
    self.telephoneText.text = [NSString stringWithFormat:@"%@",login.phone];
    self.emailText.userInteractionEnabled = NO;
    self.telephoneText.userInteractionEnabled = NO;
}


- (IBAction)loginOutButtonClick:(id)sender
{
    HEUserLogin *login = [HEUserLogin sharedLogin];
    login.access_token = nil;
    [self.viewController.navigationController popViewControllerAnimated:YES];
}

- (IBAction)sureButtonClick:(id)sender
{
    HEUserRegister *registe = [HEUserRegister sharedRegister];
    
    if (IS_KONG_STRING(self.nameText.text))
    {
        BH_ALERT(@"Please fill in the name");
        return;
    }
 
    
    if (self.AgencyButton.selected == YES)
    {
        if (IS_KONG_STRING(self.companyText.text))
        {
            BH_ALERT(@"Please fill in the company");
            return;
        }
        else
        {
            registe.company = self.companyText.text;
        }
        
        if(IS_KONG_STRING(self.addressText.text))
        {
            BH_ALERT(@"Please fill in the address");
            return;
        }
        else
        {
            registe.address = self.addressText.text;
        }
    }
    
    registe.name = self.nameText.text;
    [registe updateUserInfoWithSuccess:^(id successObject) {
        
        [SVProgressHUD showSuccessWithStatus:@"修改成功..." duration:1.0];
        
        [self.viewController.navigationController popViewControllerAnimated:YES];
        
        HEUserLogin *login=[HEUserLogin sharedLogin];
        login.v=successObject[@"__v"];
        login.userId=successObject[@"_id"];
        login.address=successObject[@"address"];
        login.company=successObject[@"company"];
        login.level=successObject[@"level"];
        login.name=successObject[@"name"];
        login.points=successObject[@"points"];
        login.profile_image=successObject[@"profile_image"];
        login.registerDate=successObject[@"registerDate"];
        login.type=successObject[@"type"];
        
    } registerError:^{
        
        [SVProgressHUD showErrorWithStatus:@"修改失败..." duration:1.0];
    }];
}
- (IBAction)cancelButtonClick:(id)sender
{
    [self.viewController.navigationController popViewControllerAnimated:YES];
}
@end
