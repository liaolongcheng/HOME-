//
//  HEHouseDetailCell.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-28.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//
#define NSTRF(str) [NSString stringWithFormat:@"%@",str]

#import "HEHouseDetailCell.h"
#import "AreaAndLinesUtily.h"
#import "UIImageView+AFNetworking.h"
#import "HEHomeHouseAgentViewController.h"

@implementation HEHouseDetailCell

{
    UIPageControl *pageControl;
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

-(void)willMoveToSuperview:(UIView *)newSuperview
{
    
    self.selectionStyle=UITableViewCellSelectionStyleNone;
    self.contentImageView.image = IMAGE_STRRTCHABLE(self.contentImageView.image, 20, 20);
    self.contentImageView.userInteractionEnabled=YES;
    
    
    NSArray *picsArray = _houseInfoDic[@"pictures"];
    
    for (int i=0; i<[picsArray count]; i++)
    {
        UIImageView *imageView=[[UIImageView alloc] initWithFrame:CGRectMake(CGRectGetWidth(self.picScrollView.frame) * i, 0, CGRectGetWidth(self.picScrollView.frame), CGRectGetHeight(self.picScrollView.frame))];
        [imageView setImageWithURL:IMAGEURLCREATE(_houseInfoDic[@"pictures"][i]) placeholderImage:DEFAULTIMAGE];
        imageView.userInteractionEnabled=YES;
        [self.picScrollView addSubview:imageView];
    }
    
    self.picScrollView.contentSize = CGSizeMake(CGRectGetWidth(self.picScrollView.frame) * [picsArray count], CGRectGetHeight(self.picScrollView.frame));
    self.picScrollView.pagingEnabled=YES;
    self.picScrollView.delegate=self;
    
    pageControl=[[UIPageControl alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth(self.picScrollView.frame), 10)];
    pageControl.center=CGPointMake(CGRectGetWidth(self.frame)/2, CGRectGetHeight(self.picScrollView.frame));
    pageControl.pageIndicatorTintColor = [UIColor darkGrayColor];
    pageControl.currentPageIndicatorTintColor = [UIColor orangeColor];
    pageControl.numberOfPages = [picsArray count];
    [self addSubview:pageControl];
    
    
    self.titleText.text = _houseInfoDic[@"name_en"];
    self.priceLabel.text = [NSString stringWithFormat:@"%@ RMB/month",_houseInfoDic[@"price"]];
    self.bedroomLabel.text= [NSString stringWithFormat:@"%@ Bedroom",_houseInfoDic[@"bedrooms"]];
    self.bathroomsLabel.text = [NSString stringWithFormat:@"%@ Bathroom",_houseInfoDic[@"bathrooms"]];
    self.livingroomsLabel.text = [NSString stringWithFormat:@"%@ Livingroom",_houseInfoDic[@"livingrooms"]];
    
    self.sharedBtn.selected  = [_houseInfoDic[@"share"] boolValue];
    self.outspaceBtn.selected = [_houseInfoDic[@"outspace"] boolValue];
    self.sizeLabel.text = [NSString stringWithFormat:@"%@ m",_houseInfoDic[@"size"]];;
    self.floorLabel.text = [NSString stringWithFormat:@"%@F/%@",_houseInfoDic[@"floor"],_houseInfoDic[@"totalFloor"]];
    self.areaLabel.text = [[AreaAndLinesUtily sharedAreaLines] enNameWithAreaId:_houseInfoDic[@"area"][0]];
    NSString *lineInfoStr= [[AreaAndLinesUtily sharedAreaLines] enNameWithMetroId:_houseInfoDic[@"metro"][0]];
    self.metroLabel.text = [lineInfoStr substringToIndex:[lineInfoStr rangeOfString:@" "].location + 2];
    self.stationLabel.text = [lineInfoStr substringFromIndex:[lineInfoStr rangeOfString:@" "].location + 2];
    self.addressText.text = _houseInfoDic[@"address"];
    
    CGFloat desHeight = [_houseInfoDic[@"description_en"] getHeightByWidth:self.descrpitionText.frame.size.width font:self.descrpitionText.font];
    self.descrpitionText.text = _houseInfoDic[@"description_en"];
    
    if (desHeight > 54 && self.openDescButton.selected)
    {
        self.descrpitionText.frame = CGRectMake(self.descrpitionText.frame.origin.x, self.descrpitionText.frame.origin.y, CGRectGetWidth(self.descrpitionText.frame), desHeight + 26);
    }
    
    
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    pageControl.currentPage = scrollView.contentOffset.x/CGRectGetWidth(scrollView.frame);
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (IBAction)contactClick:(id)sender
{
    HEHomeHouseAgentViewController *houseAgent=[[HEHomeHouseAgentViewController alloc] initWithPublishId:_houseInfoDic[@"publisher"] houseId:_houseInfoDic[@"_id"] houseArray:nil];
    [self.viewController.navigationController pushViewController:houseAgent animated:YES];
}

- (IBAction)openDescButtonClick:(UIButton *)sender
{
    sender.selected = !sender.selected;
    [self.tableViewOfcurrentCell reloadData];
}
@end
