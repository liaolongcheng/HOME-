//
//  HEHouseDetailCell.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-28.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HEHouseDetailCell : UITableViewCell<UIScrollViewDelegate>
@property (strong, nonatomic) IBOutlet UIImageView *contentImageView;

@property (nonatomic,strong) NSDictionary *houseInfoDic;
@property (nonatomic,assign) UIViewController *viewController;

@property (strong, nonatomic) IBOutlet UITextView *titleText;
@property (strong, nonatomic) IBOutlet UILabel *priceLabel;
@property (strong, nonatomic) IBOutlet UILabel *bedroomLabel;
@property (strong, nonatomic) IBOutlet UILabel *bathroomsLabel;
@property (strong, nonatomic) IBOutlet UILabel *livingroomsLabel;
@property (strong, nonatomic) IBOutlet UILabel *sizeLabel;
@property (strong, nonatomic) IBOutlet UILabel *floorLabel;
@property (strong, nonatomic) IBOutlet UILabel *areaLabel;
@property (strong, nonatomic) IBOutlet UILabel *metroLabel;
@property (strong, nonatomic) IBOutlet UILabel *stationLabel;
@property (strong, nonatomic) IBOutlet UITextView *addressText;
@property (strong, nonatomic) IBOutlet UIButton *sharedBtn;
@property (strong, nonatomic) IBOutlet UIButton *outspaceBtn;
@property (strong, nonatomic) IBOutlet UITextView *descrpitionText;
@property (strong, nonatomic) IBOutlet UIPageControl *pageControll;
@property (strong, nonatomic) IBOutlet UIScrollView *picScrollView;
@property (weak, nonatomic) IBOutlet UIButton *openDescButton;
- (IBAction)contactClick:(id)sender;
- (IBAction)openDescButtonClick:(id)sender;

@end
