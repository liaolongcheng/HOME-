//
//  HEAgentCell.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-30.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HEBaseViewController.h"

@interface HEAgentCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UIImageView *PhotoImageView;
@property (strong, nonatomic) IBOutlet UILabel *nameLable;
@property (strong, nonatomic) IBOutlet UILabel *nameContentLable;
@property (strong, nonatomic) NSString *publisherPhone;
@property (strong, nonatomic) NSString *publisherName;
@property (assign, nonatomic) HEBaseViewController *viewController;


- (IBAction)phoneClick:(id)sender;
- (IBAction)messageClick:(id)sender;
- (IBAction)zanMessageClick:(id)sender;

@end
