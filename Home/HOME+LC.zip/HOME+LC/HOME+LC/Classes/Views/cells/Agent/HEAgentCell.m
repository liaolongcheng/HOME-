//
//  HEAgentCell.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-30.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEAgentCell.h"
#import <QuartzCore/QuartzCore.h>
#import "HEFavouriteAgentSendMessageViewController.h"

@implementation HEAgentCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

-(void)willMoveToSuperview:(UIView *)newSuperview
{
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    self.backgroundColor = [UIColor clearColor];
    
    self.PhotoImageView.layer.masksToBounds = YES;
    self.PhotoImageView.layer.cornerRadius = 5;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
//打电话
- (IBAction)phoneClick:(id)sender
{
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"tel://%@",self.publisherPhone]]];
}
//发送短消息
- (IBAction)messageClick:(id)sender
{
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"sms://%@",self.publisherPhone]]];
}
//发送站内消息
- (IBAction)zanMessageClick:(id)sender
{
    [self.viewController hiddenTabBar];
    HEFavouriteAgentSendMessageViewController *sendMessage =[[HEFavouriteAgentSendMessageViewController alloc] initWithName:self.publisherName phone:self.publisherPhone];
    [self.viewController.navigationController pushViewController:sendMessage animated:YES];
}
@end
