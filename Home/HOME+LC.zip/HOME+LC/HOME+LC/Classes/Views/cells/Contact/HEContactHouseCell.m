//
//  HEContactHouseCell.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-16.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEContactHouseCell.h"
#import "HEContactHouseViewController.h"

@implementation HEContactHouseCell
{
    sendBlock _sendBlock;
    lableClick _lableBlock;
    
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}
-(instancetype) initWtihSendClick :(sendBlock) sendClick lableBlock:(lableClick) lableBlock
{
    self=LOAD_TABLEVIEWCELL(@"HEContactHouseCell");
    if (self) {
        _sendBlock = [sendClick copy];
        _lableBlock = [lableBlock copy];
    }
    return self;
}

-(void)willMoveToSuperview:(UIView *)newSuperview
{
    _titleLable.shouldUnderline=YES;
    _titleLable.textColor=[UIColor blueColor];
    _titleLable.highlightedColor = [UIColor clearColor];
    [_titleLable addTarget:self action:@selector(clickTite:)];

    _contentTextView.placeholderColor=[UIColor grayColor];
    _contentTextView.textColor=[UIColor grayColor];
    _contentTextView.backgroundColor=[UIColor clearColor];
    _contentTextView.placeholder=@"less than 200 words";
    _contentTextView.delegate=self;
    
    _starView.backgroundColor=[UIColor clearColor];
    _starView.padding = 10;
    _starView.alignment = RateViewAlignmentRight;
    _starView.editable = YES;
    _starView.delegate = self;
    _starView.numOfStars = 5;
    _starView.rate=0;
    
    
    self.backgroundColor=[UIColor clearColor];
    self.selectionStyle=UITableViewCellSelectionStyleNone;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    RESIGNFIRSTRESPONDER;
}

- (IBAction)sendBtnClick:(UIButton *)sender
{
    if (_sendBlock) {
        
        UITableView *tableView=(UITableView *)[[self superview] superview];
        NSIndexPath *indexPath = [tableView indexPathForCell:self];
        _sendBlock(indexPath,self,tableView,self.starView.rate,self.contentTextView.text);
    }
}

-(void) clickTite:(UILabel *) lab
{
    UITableView *tableView=(UITableView *)[[self superview] superview];
    NSIndexPath *indexPath = [tableView indexPathForCell:self];
    if (_lableBlock) {
        _lableBlock(indexPath,self,tableView);
    }
}
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if ([textView.text length] <= 200)
    {
        return YES;
    }
    return NO;
}
- (void)rateView:(HERateStartView *)rateView changedToNewRate:(NSNumber *)rate
{
    NSDictionary *dic = @{@"num":rate,@"indexPath":self.indexPath};
    [[NSNotificationCenter defaultCenter] postNotificationName:CHANGE_RATA object:dic];
}
@end
