//
//  HEContactHouseCell.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-16.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

@class HEContactHouseViewController;

#import <UIKit/UIKit.h>
#import "HEPlaceHolderTextView.h"
#import "HEUnderLineLable.h"
#import "HERateStartView.h"

typedef void (^sendBlock)(NSIndexPath *indexPath, UITableViewCell *cell, UITableView *listTableView, NSInteger rate, NSString *content);
typedef void (^lableClick)(NSIndexPath *indexPath, UITableViewCell *cell, UITableView *listTableView);

@interface HEContactHouseCell : UITableViewCell<UITextViewDelegate,DYRateViewDelegate>

@property (strong, nonatomic) IBOutlet HEPlaceHolderTextView *contentTextView;

@property (strong, nonatomic) IBOutlet HEUnderLineLable *titleLable;
@property (nonatomic,strong) NSIndexPath *indexPath;

@property (assign,nonatomic) UIView *gradeView;
@property (strong, nonatomic) IBOutlet UIButton *sendButton;
@property (strong, nonatomic) IBOutlet HERateStartView *starView;
@property (weak, nonatomic) IBOutlet UIImageView *expiredImageView;
@property (weak, nonatomic) IBOutlet UIImageView *contentTextViewBackImageView;


-(instancetype) initWtihSendClick :(sendBlock) sendClick lableBlock:(lableClick) lableBlock;
- (IBAction)sendBtnClick:(UIButton *)sender;
@end
