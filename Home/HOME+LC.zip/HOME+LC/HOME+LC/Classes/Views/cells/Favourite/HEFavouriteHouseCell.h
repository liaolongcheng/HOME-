//
//  HEFavouriteHouseCell.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-16.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//


#import <UIKit/UIKit.h>

@interface HEFavouriteHouseCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *titleLable;
@property (weak, nonatomic) IBOutlet UILabel *timeLable;
@property (weak, nonatomic) IBOutlet UILabel *priceLable;
@property (strong, nonatomic) IBOutlet UIImageView *houseImageView;
@property (strong, nonatomic) IBOutlet UITextView *contentTextView;
@property (weak, nonatomic) IBOutlet UILabel *roomLable;
@property (weak, nonatomic) IBOutlet UILabel *lineLable;
@property (weak, nonatomic) IBOutlet UILabel *addressLable;
@property (weak, nonatomic) IBOutlet UIImageView *expiredImageView;

@end
