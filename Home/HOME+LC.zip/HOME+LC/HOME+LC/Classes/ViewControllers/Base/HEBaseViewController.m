//
//  HEBaseViewController.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-17.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEBaseViewController.h"
#import "HETabBarController.h"

@interface HEBaseViewController ()
{
}

@end
static BMKLocationService *_locationServer = nil;
@implementation HEBaseViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    UIView *stateView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, STATUSBAR_HEIGHT)];
    stateView.backgroundColor = [UIColor blackColor];
    [self.view addSubview:stateView];
    
    _navigationImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, STATUSBAR_HEIGHT, 320, NAVIGATIONBAR_HEIGHT)];
    _navigationImageView.image = LOAD_IMAGE(@"background_navigation.png");
    _navigationImageView.userInteractionEnabled=YES;
    [self.view insertSubview:_navigationImageView atIndex:0];
    
    if ([self navBarTitle])
    {
        UILabel *titleLable=[[UILabel alloc] initWithFrame:CGRectMake(0, 0, 200, 30)];
        titleLable.textAlignment=NSTextAlignmentCenter;
        titleLable.text=[self navBarTitle];
        titleLable.font=[UIFont boldSystemFontOfSize:18];
        titleLable.textColor=[UIColor darkGrayColor];
        titleLable.center=CGPointMake(CGRectGetWidth(_navigationImageView.frame)/2, CGRectGetHeight(_navigationImageView.frame)/2);
        [_navigationImageView addSubview:titleLable];

    }
    
    
    UIImageView *contentView=[[UIImageView alloc] initWithFrame:CGRectMake(0, STATUSBAR_HEIGHT+NAVIGATIONBAR_HEIGHT, 320, self.view.frame.size.height-STATUSBAR_HEIGHT+NAVIGATIONBAR_HEIGHT)];
    contentView.image = LOAD_IMAGE(@"background1.png");
    contentView.userInteractionEnabled=YES;
    [self.view insertSubview:contentView atIndex:0];
    
    if([self useline])
    {
        UIImageView *lineImageView=[[UIImageView alloc] initWithFrame:CGRectMake(0, STATUSBAR_HEIGHT + NAVIGATIONBAR_HEIGHT +1, 320, 1)];
        lineImageView.image=LOAD_IMAGE(@"line1.png");
        [self.view addSubview:lineImageView];
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(willEditTextFidld:) name:UITextFieldTextDidBeginEditingNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(willEditTextView:) name:UITextViewTextDidBeginEditingNotification object:nil];
    
}


-(BOOL)useline
{
    return YES;
}

-(void)showTabBar
{
    HETabBarController *tab = (HETabBarController *)self.tabBarController;
    [tab setShowTabBar];
}
-(void)hiddenTabBar
{
    HETabBarController *tab = (HETabBarController *)self.tabBarController;
    [tab setHiddenTabBar];
}
-(NSString *)navBarTitle
{
    return nil;
}

-(void) willEditTextFidld:(NSNotification *) not
{
    UITextField *textFidld = [not object];
    if (![textFidld delegate])
    {
        textFidld.delegate = self;
    }
}
-(void) willEditTextView:(NSNotification *) not
{
    UITextView *textView = [not object];
    if (![textView delegate])
    {
        textView.delegate = self;
    }
}
-(BOOL) shouldEditWithStr:(NSString *) str
{
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",@"^[\x07-\\xff]*$"];

    if ([predicate evaluateWithObject:str])
    {
        return YES;
    }
    else
    {
        return NO;
    }
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range     replacementString:(NSString *)string
{
    return [self shouldEditWithStr:string];
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
  return [self shouldEditWithStr:text];
}




@end
