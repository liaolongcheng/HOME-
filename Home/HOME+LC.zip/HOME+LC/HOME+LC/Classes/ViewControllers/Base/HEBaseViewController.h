//
//  HEBaseViewController.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-17.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HEBaseViewController : UIViewController<UITextViewDelegate,UITextFieldDelegate,BMKLocationServiceDelegate>

@property (nonatomic,strong) UIImageView *navigationImageView;


-(BOOL)useline;

-(void) showTabBar;
-(void) hiddenTabBar;

-(NSString *) navBarTitle;

@end
