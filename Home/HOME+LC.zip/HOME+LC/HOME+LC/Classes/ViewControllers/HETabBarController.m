//
//  HETabBarController.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-14.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
#import "HETabBarController.h"

#import "HESegmentControl.h"
#import "HEHomeViewController.h"
#import "HEFavoriteViewController.h"
#import "HEContactViewController.h"
#import "HEMoreViewController.h"
#import "HomeViewController.h"


#define SEG_BAR_HETGHT [UIScreen mainScreen].bounds.size.height - 70


@implementation HENavgaionViewController

-(void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    [SVProgressHUD dismiss];
    [HttpHelper cancelCurrentOperatin];
    [super pushViewController:viewController animated:YES];
}
-(UIViewController *)popViewControllerAnimated:(BOOL)animated
{
    [SVProgressHUD dismiss];
    [HttpHelper cancelCurrentOperatin];
    return [super popViewControllerAnimated:YES];
}
-(NSArray *)popToViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    [SVProgressHUD dismiss];
    [HttpHelper cancelCurrentOperatin];
    return [super popToViewController:viewController animated:YES];
}
-(NSArray *)popToRootViewControllerAnimated:(BOOL)animated
{
    [SVProgressHUD dismiss];
    return [super popToRootViewControllerAnimated:YES];
}
@end

@interface HETabBarController ()
{
    UIImageView *animateView;
    HESegmentControl *seg;
}

@end

@implementation HETabBarController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
    
	// Do any additional setup after loading the view.
    self.tabBar.hidden=YES;

    
    seg=[[HESegmentControl alloc] initWithFrame:CGRectMake(0, SEG_BAR_HETGHT, 320, 70)];
   
    UIImageView *backView=[[UIImageView alloc] initWithFrame:seg.bounds];
    backView.userInteractionEnabled=YES;
    backView.image=[UIImage imageNamed:@"tabbar_bg.png"];
    seg.backGroundView=backView;
    
    seg.titleColor=[UIColor blueColor];

    seg.NormalIcons=@[[UIImage imageNamed:@"icon_home.png"],[UIImage imageNamed:@"icon_favorite.png"],[UIImage imageNamed:@"icon_booking.png"],[UIImage imageNamed:@"icon_more.png.png"]];
    seg.SelectIcons=@[[UIImage imageNamed:@"icon_home_selected.png"],[UIImage imageNamed:@"icon_favorite_selected.png"],[UIImage imageNamed:@"icon_booking_selected.png"],[UIImage imageNamed:@"icon_more_selected.png"]];

    seg.isUseSetBackGround=NO;
    seg.viewBackGroundColor=[UIColor clearColor];
    seg.isDoubleClcik=YES;
    
    [seg createSegmentControlWithSegType:SegmentControlNormalIconAndSelectIcon selectedBlock:^(NSInteger selectIndex, UIView *selectView) {
       
        self.selectedIndex=selectIndex;
        
        [UIView animateWithDuration:0.3 animations:^{
            animateView.center=CGPointMake(selectView.center.x, animateView.center.y);
        }];
    }];
    [self.view addSubview:seg];
    [seg selectAtIndex:0];
    
    UIViewController *home=[[HEHomeViewController alloc] init];
    UINavigationController *homeNav=[[HENavgaionViewController alloc] initWithRootViewController:home];
    homeNav.navigationBar.hidden=YES;
    
   
    UIViewController *favourite=[[HEFavoriteViewController alloc] init];
    UINavigationController *favouritteNav=[[HENavgaionViewController alloc] initWithRootViewController:favourite];
    favouritteNav.navigationBar.hidden=YES;
   
    UIViewController *contact=[[HEContactViewController alloc] init];
    UINavigationController *contactNav=[[HENavgaionViewController alloc] initWithRootViewController:contact];
    contactNav.navigationBar.hidden=YES;
   
    UIViewController *more=[[HEMoreViewController alloc] init];
    UINavigationController *moreNav=[[HENavgaionViewController alloc] initWithRootViewController:more];
    moreNav.navigationBar.hidden=YES;
    
    self.viewControllers=@[homeNav,favouritteNav,contactNav,moreNav];
    
    
    animateView=[[UIImageView alloc] initWithFrame:CGRectMake(0, seg.frame.origin.y+13, 30, 10)];
    animateView.image = [UIImage imageNamed:@"tabbar_hint.png"];
    animateView.center=CGPointMake(seg.currentSelectView.center.x, animateView.frame.origin.y);
    [self.view addSubview:animateView];
}
-(void) setHiddenTabBar
{
    [UIView animateWithDuration:0.4 animations:^{
        seg.frame=CGRectMake(0, SCREEN_HEIGHT, 320, SEG_BAR_HETGHT);
        animateView.hidden=YES;
    }];
}
-(void) setShowTabBar
{
    [UIView animateWithDuration:0.4 animations:^{
        
        seg.frame=CGRectMake(0, SEG_BAR_HETGHT, 320, SEG_BAR_HETGHT);
        animateView.hidden=NO;
    }];

}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
