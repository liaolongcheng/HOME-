//
//  HomeViewController.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-14.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HomeViewController.h"
#import "HESegmentControllExpand.h"
#import "HELinkageView.h"
#import "HEHTTPSearchHouse.h"
#import "HEHomePostStepThreeViewController.h"
#import "HEMoreMyPostUpdateViewController.h"
#import "HELinkageExView.h"

@interface HomeViewController ()
{
    UIView *_contentView;
    CGRect _frame;
}

@end

@implementation HomeViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    
    }
    return self;
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.view.frame=CGRectMake(0, 0, 320, 100);
    
    
    
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.view.backgroundColor=[UIColor grayColor];
	// Do any additional setup after loading the view.
    
    HELinkageExView *linkageView=[[HELinkageExView alloc] initWithFrame:CGRectMake(20, 100, 280,40) fileName:@"areasInfo"];
    linkageView.backgroundColor = [UIColor redColor];
    linkageView.selectBlock = ^(NSString *str)
    {
        NSLog(@"%@",str);
    };
    [self.view addSubview:linkageView];

    
//
    
//    [HttpHelper GET:@"http://121.199.31.154:3000/app/init-data.json" parameters:nil svText:@"加载中...." svMarkType:SVProgressHUDMaskTypeBlack success:^(AFHTTPRequestOperation *operation, id responseObject) {
//       
//
//
//        NSMutableArray *areaArray=[[NSMutableArray alloc] init];
//        for (int i=0; i<[responseObject[0][@"data"][1][@"districts"] count]; i++)
//        {
//            NSDictionary *dic=responseObject[0][@"data"][1][@"districts"][i];
//            NSArray *array=dic[@"code"];
//            
//            
//            NSMutableDictionary *dic1=[[NSMutableDictionary alloc] init];
//            
//            NSMutableArray *subArray=[[NSMutableArray alloc] init];
//            for (int j=0; j<[array count]; j++)
//            {
//               
//                if (j==0)
//                {
//                    NSDictionary *enemyDic=array[j][@"_attr"];
//                    [dic1 setValue:enemyDic[@"id"] forKey:@"id"];
//                    [dic1 setValue:enemyDic[@"enName"] forKey:@"enName"];
//                    [dic1 setValue:enemyDic[@"key"] forKey:@"key"];
//                    [dic1 setValue:enemyDic[@"parentId"] forKey:@"parentId"];
//                    [dic1 setValue:enemyDic[@"sortNumber"] forKey:@"sortNumber"];
//                    [dic1 setValue:enemyDic[@"zhName"] forKey:@"zhName"];
//                }
//                else
//                {
//                    NSDictionary *enemyDic=array[j][@"code"][@"_attr"];
//                    [subArray addObject:enemyDic];
//                }
//            }
//            
//            [dic1 setValue:subArray forKey:@"subways"];
//            [areaArray addObject:dic1];
//        }
//        
//        
//        NSLog(@"%@",areaArray);
//        
//        NSString *path=[APP_DOCUMENTS_PATH stringByAppendingPathComponent:@"/areasInfo.plist"];
//        [areaArray writeToFile:path atomically:YES];
//        
//    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
//        
//    }];
    
//    NSDictionary *dic=@{@"Unlimited":@"1+",@"1000-5000":@"1-5",@"5000-7000":@"5-7",@"7000-10000":@"7-10",@"10000-130.":@"1-13",@"1300-150.":@"13-15",@"1500-200.":@"15-20",@">20000":@"20+"};
    
//    
//    NSDictionary *dic=@{@"Unlimited":@"1+",@"1 bedrooms":@"1",@"2 bedrooms":@"2",@"3 bedrooms":@"3",@">3 bedrooms":@"3+"};
//     NSString *path=[APP_DOCUMENTS_PATH stringByAppendingPathComponent:@"/roomsInfo.plist"];
//    [dic writeToFile:path atomically:YES];
    
    
//    HESegmentControl *seg=[[HESegmentControl alloc] initWithFrame:CGRectMake(0, 0, 320, 50)];
//    UIView *backView=[[UIView alloc] initWithFrame:seg.bounds];
//    backView.backgroundColor=[UIColor redColor];
//    seg.backGroundView=backView;
//    
//    seg.titleColor=[UIColor blueColor];
//    seg.titles=@[@"你好",@"我好",@"大家好"];
//    seg.NormalIcons=@[[UIImage imageNamed:@"icon_booking.png"],[UIImage imageNamed:@"icon_booking.png"],[UIImage imageNamed:@"icon_booking.png"]];
//    seg.SelectIcons=@[[UIImage imageNamed:@"btn_radio_mid.png"],[UIImage imageNamed:@"btn_radio_mid.png"],[UIImage imageNamed:@"btn_radio_mid.png"]];
//    seg.marginWidth=20;
//    seg.marginHeight=10;
//    seg.isUseSetBackGround=YES;
//   
//    [seg createSegmentControlWithSegType:SegmentControlTitleAndNormalIconSelectIcon selectedBlock:^(NSInteger selectIndex, UIView *selectView) {
//        
//
//        
//    }];
//  
//    [self.view addSubview:seg];
//    
//    
//    HESegmentControllExpand *segExpand=[[HESegmentControllExpand alloc] initWithFrame:CGRectMake(0, 100, 320, 30)];
//    [segExpand createSegmentExpand:^(HESegmentControllExpand *segExpand, NSInteger index, UIView *currentView) {
//        
//        if (index == 0)
//        {
//            NSLog(@"------->selctTime:%d",segExpand.selctTime);
//        }
//        if (index == 1)
//        {
//             NSLog(@"------->selectPrice:%@",segExpand.selectPrice);
//        }
//        if (index == 2)
//        {
//            NSLog(@"------->selectRoom:%@",segExpand.selectRoom);
//        }
//        if (index == 3)
//        {
//            NSLog(@"------->selectStar:%d",segExpand.selectStar);
//        }
//        
//        
//    }];
//    [self.view addSubview:segExpand];
    
    

 
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)postThree:(id)sender
{
    HEHomePostStepThreeViewController *three=[[HEHomePostStepThreeViewController alloc] init];
    [self presentViewController:three animated:YES completion:nil];
}

- (IBAction)postUpdate:(id)sender
{
    HEMoreMyPostUpdateViewController *myPost=[[HEMoreMyPostUpdateViewController alloc] init];
    [self presentViewController:myPost animated:YES completion:nil];
}
@end
