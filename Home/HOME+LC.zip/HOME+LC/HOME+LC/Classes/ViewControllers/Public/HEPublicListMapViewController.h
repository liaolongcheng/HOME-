//
//  HEHomeNearbyViewController.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-17.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEPublicBaseViewController.h"
#import "HESegmentControl.h"

@interface HEPublicListMapViewController  : HEPublicBaseViewController

@property (nonatomic,strong) HESegmentControl *segControll;

-(BOOL) isCreateListAndMap;

@end
