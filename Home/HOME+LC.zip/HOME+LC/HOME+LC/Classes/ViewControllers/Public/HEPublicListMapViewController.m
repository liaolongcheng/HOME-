//
//  HEHomeNearbyViewController.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-17.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEPublicListMapViewController.h"
#import "HESegmentControl.h"

@interface HEPublicListMapViewController ()
{
    
}

@end

@implementation HEPublicListMapViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    
    if ([self isCreateListAndMap])
    {
        _segControll=[[HESegmentControl alloc] initWithFrame:CGRectMake(0, 0, 150, 30)];
        
        _segControll.center=self.navigationImageView.center;
        _segControll.NormalIcons=
        @[
          LOAD_IMAGE(@"btn_radio_left.png"),
          LOAD_IMAGE(@"btn_radio_right.png")
          ];
        _segControll.SelectIcons=
        @[
          LOAD_IMAGE(@"btn_radio_left_selected.png"),
          LOAD_IMAGE(@"btn_radio_right_selected.png")
          ];
        _segControll.titleNormalIcons=
        @[
          LOAD_IMAGE(@"title_house.png"),
          LOAD_IMAGE(@"title_restaurant.png")
          ];
        _segControll.titleSelectedIcons=
        @[
          LOAD_IMAGE(@"title_house_selected.png"),
          LOAD_IMAGE(@"title_restaurant_selected.png")
          ];
        
        _segControll.isDoubleClcik=YES;
        _segControll.tag=10;
        _segControll.backgroundColor=[UIColor clearColor];
        [self.view addSubview:_segControll];

    }
    
}

-(BOOL)isCreateListAndMap
{
    return YES;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
