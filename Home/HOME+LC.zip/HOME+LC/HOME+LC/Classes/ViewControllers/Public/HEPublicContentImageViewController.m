//
//  HEPublicContentImageViewController.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-18.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEPublicContentImageViewController.h"

@interface HEPublicContentImageViewController ()

@end

@implementation HEPublicContentImageViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    _contentImageView=[[UIImageView alloc] initWithFrame:CGRectMake(10, NAVIGATIONBAR_HEIGHT+STATUSBAR_HEIGHT+10, 300, SCREEN_HEIGHT - NAVIGATIONBAR_HEIGHT - STATUSBAR_HEIGHT -20)];
    _contentImageView.userInteractionEnabled=YES;
    
    UIImage *contentImage=LOAD_IMAGE(@"background2.png");
    UIImage *tempImage= IMAGE_STRRTCHABLE(contentImage, STATUSBAR_HEIGHT, STATUSBAR_HEIGHT);
    _contentImageView.image=tempImage;
    [self.view insertSubview:_contentImageView atIndex:1];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
