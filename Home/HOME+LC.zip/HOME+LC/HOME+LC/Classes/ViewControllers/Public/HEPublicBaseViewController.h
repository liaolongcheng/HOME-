//
//  HEPublicBaseViewController.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-17.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEBaseViewController.h"
#import "HESegmentControllExpand.h"
#import "HEPublicContentImageViewController.h"


@interface HEPublicBaseViewController : HEPublicContentImageViewController


@property (nonatomic,strong) HESegmentControllExpand *segExpand;

-(void)backButtonClick:(UIButton *) btn;


-(BOOL) isCreateSegmenetControllExpand;

@end
