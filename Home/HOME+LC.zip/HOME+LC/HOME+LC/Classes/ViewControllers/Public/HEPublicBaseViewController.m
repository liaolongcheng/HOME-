//
//  HEPublicBaseViewController.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-17.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEPublicBaseViewController.h"
#import "HESegmentControllExpand.h"

@interface HEPublicBaseViewController ()

@end

@implementation HEPublicBaseViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.

    //返回按钮
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame=CGRectMake(10, 6, 40, 30);
    [button setImage:LOAD_IMAGE(@"button_back.png") forState:UIControlStateNormal];
    [button addTarget:self action:@selector(backButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.navigationImageView addSubview:button];

    //类容视图
    if ([self isCreateSegmenetControllExpand])
    {
        _segExpand=[[HESegmentControllExpand alloc] initWithFrame:CGRectMake(8, 8, 284, 30)];
        [self.contentImageView addSubview:_segExpand];
    }
}
-(void)backButtonClick:(UIButton *) btn
{
    [self.navigationController popViewControllerAnimated:YES];
}
-(BOOL)isCreateSegmenetControllExpand
{
    return YES;
}


@end
