//
//  HEPublicLinkageTableViewController.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-18.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEPublicLinkageTableViewController.h"

@interface HEPublicLinkageTableViewController ()
{
    NSArray *sourceArray;
    NSInteger selectedIndex;
}

@end

@implementation HEPublicLinkageTableViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    selectedIndex=0;
    // Do any additional setup after loading the view from its nib.
    self.firstTableView.backgroundColor=[UIColor clearColor];
    self.firstTableView.tag=100;
    self.firstTableView.dataSource=self;
    self.firstTableView.delegate=self;
    self.secandTableView.backgroundColor=[UIColor clearColor];
    self.secandTableView.tag=200;
    self.secandTableView.dataSource=self;
    self.secandTableView.delegate=self;
    
    sourceArray = [self readArrayInfoOfContentFile:[self loadFileName] extension:@"plist"];
    
     [self.firstTableView selectRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] animated:YES scrollPosition:UITableViewScrollPositionNone];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSArray *) readArrayInfoOfContentFile:(NSString *) fileName extension :(NSString *)extension
{
    
    NSArray *array=[NSArray arrayWithContentsOfFile:LOAD_BANDLE_FILE(fileName, extension)];
    return array;
}


-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView.tag==100)
    {
        return [sourceArray count];
    }
    else
    {
        return [sourceArray[selectedIndex][@"subways"] count];
    }
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *str=@"Cell";
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:str];
    if (!cell) {
        cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:str];
        cell.textLabel.font=FONT(11);
        cell.backgroundColor=[UIColor clearColor];
    }
    if (tableView.tag == 100)
    {
        cell.textLabel.text=sourceArray[indexPath.row][@"enName"];
    }
    else
    {
        cell.textLabel.text=sourceArray[selectedIndex][@"subways"][indexPath.row][@"enName"];
    }
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView.tag == 100)
    {
        selectedIndex=indexPath.row;
        [_secandTableView reloadData];
    }
    else
    {
        [self secandTableDidSelected:tableView indexPath:indexPath firstTableViewSelectIndex:selectedIndex secandTableViewSelectContent:sourceArray[selectedIndex][@"subways"][indexPath.row][@"id"]];
    }
}
-(void)secandTableDidSelected:(UITableView *)secandTableView indexPath:(NSIndexPath *)indexPath firstTableViewSelectIndex:(NSInteger)firstTableViewSelectIndex secandTableViewSelectContent:(NSString *)secandTableViewSelectContent
{
    
}

-(BOOL)isCreateSegmenetControllExpand
{
    return NO;
}
-(NSString *)loadFileName
{
    return @"areasInfo";
}
@end
