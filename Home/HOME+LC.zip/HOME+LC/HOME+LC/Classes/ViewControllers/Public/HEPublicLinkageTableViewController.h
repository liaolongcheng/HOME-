//
//  HEPublicLinkageTableViewController.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-18.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEPublicBaseViewController.h"

@interface HEPublicLinkageTableViewController : HEPublicBaseViewController<UITableViewDataSource,UITableViewDelegate>

@property (strong, nonatomic) IBOutlet UITableView *firstTableView;
@property (strong, nonatomic) IBOutlet UITableView *secandTableView;


-(NSString *)loadFileName;
-(void) secandTableDidSelected:(UITableView *)secandTableView indexPath:(NSIndexPath *) indexPath firstTableViewSelectIndex:(NSInteger) firstTableViewSelectIndex secandTableViewSelectContent:(NSString *)secandTableViewSelectContent;


@end
