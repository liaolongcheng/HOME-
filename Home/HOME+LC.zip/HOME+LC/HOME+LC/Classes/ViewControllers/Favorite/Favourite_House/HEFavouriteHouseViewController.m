//
//  HEFavouriteHouseViewController.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-15.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEFavouriteHouseViewController.h"
#import "HEFavouriteHouseCell.h"
#import "HEUserLogin.h"
#import "HEFavourite.h"
#import "AreaAndLinesUtily.h"

#import "HEHomeHouseDetailViewController.h"

@interface HEFavouriteHouseViewController ()
{
    NSMutableArray *_sourceArray;
    HEFavourite *_favourite;
}

@end

@implementation HEFavouriteHouseViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    _sourceArray=[[NSMutableArray alloc] init];
    _favourite=[[HEFavourite alloc] init];
    _favourite.page=0;
    
    if (!USER_ISLOGIN)
    {
        BH_ALERT(@"You are not logged in.");
        return;
    }
    [self publicRetriteval:NO svType:SVProgressHUDMaskTypeClear];
    
}

-(void) publicRetriteval:(BOOL) isMore svType:(SVProgressHUDMaskType) svType
{
    [_favourite retrievalFavoureteHouse:^(id responesObject) {
        
        if (!isMore)
        {
            [_sourceArray removeAllObjects];
            [_sourceArray addObjectsFromArray:responesObject];
           
            [self.tableView reloadData];
            [self endRefresh];
        }
        else
        {
           
            [_sourceArray addObjectsFromArray:responesObject];
       
            [self.tableView reloadData];
            [self endRefresh];
        }
        
    } reteriealError:^{
        [self endRefresh];
    } svType:svType];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(BOOL)usesRefreshHeaderView
{
    return YES;
}
-(BOOL)usesRefreshFooterView
{
    return NO;
}
-(BOOL)usesAutoRefresh
{
    return NO;
}

-(void)didStartLoadingMoreObjects
{
    _favourite.page += 1;
    [self publicRetriteval:YES svType:SVProgressHUDMaskTypeNil];
}
-(void)didStartLoadingNewObjects
{
    _favourite.page = 0;
    [self publicRetriteval:NO svType:SVProgressHUDMaskTypeNil];
}
-(void) endRefresh
{
    [super didEndLoadingMoreObjects];
    [super didEndLoadingNewObjects];;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [_sourceArray count];
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *str=@"Cell";
    HEFavouriteHouseCell *cell=[tableView dequeueReusableCellWithIdentifier:str];
    if (!cell)
    {
        cell = [[NSBundle mainBundle] loadNibNamed:@"HEFavouriteHouseCell" owner:nil options:nil][0];
    }
    
    NSDictionary *house=_sourceArray[indexPath.row];
    
    cell.titleLable.text=house[@"name_en"];
    cell.timeLable.text=[NSString formatterTimeWithString:house[@"publishDate"]];
    cell.priceLable.text=[NSString stringWithFormat:@"%@ RMB",house[@"price"]];
    cell.roomLable.text = [NSString stringWithFormat:@"%@ bedroom",house[@"bedrooms"]];

    if ([house[@"metro"] count] >= 1)
    {
        NSString *lineInfoStr = [[AreaAndLinesUtily sharedAreaLines] enNameWithMetroId:house[@"metro"][0]];
        cell.lineLable.text = [lineInfoStr substringToIndex:[lineInfoStr rangeOfString:@" "].location + 2];
    }
    else
    {
        cell.lineLable.text = @"";
    }
    if ([house[@"area"] count] >= 1)
    {
        NSString *addInfoStr = [[AreaAndLinesUtily sharedAreaLines] enNameWithAreaId:house[@"area"][0]];
        
        cell.addressLable.text = [addInfoStr substringToIndex:[addInfoStr rangeOfString:@" "].location + 2];
    }
    else
    {
        cell.addressLable.text = @"";
    }
    if ([[_sourceArray[indexPath.row] allKeys] containsObject:@"expiredAt"] && [NSString expiredWithDateString:_sourceArray[indexPath.row][@"expiredAt"]])
    {
        cell.expiredImageView.hidden = NO;
    }
    else
    {
        cell.expiredImageView.hidden = YES;
    }
    [cell.houseImageView setImageWithURL:IMAGEURLCREATE(house[@"picture"]) placeholderImage:DEFAULTIMAGE];

    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 231;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    HEHomeHouseDetailViewController *detail=[HEHomeHouseDetailViewController sharedHouseDetail];
    detail.houseId=_sourceArray[indexPath.row][@"_id"];
    [detail releadeHouseInfo];
    [self.viewController.navigationController pushViewController:detail animated:YES];
}


@end
