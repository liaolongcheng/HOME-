//
//  HEFavoriteViewController.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-15.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEFavoriteViewController.h"
#import "HESegmentControl.h"
#import "HEFavouriteHouseViewController.h"
#import "HEFavouriteDiningViewController.h"
#import "HEFavouriteAgentViewController.h"


@interface HEFavoriteViewController ()
{
    HEFavouriteHouseViewController *_favouriteHome;
    HEFavouriteDiningViewController *_favouriteDining;
    HEFavouriteAgentViewController *_favouriteAgent;
    HESegmentControl *seg;
}

@end

@implementation HEFavoriteViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self showTabBar];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    seg=[[HESegmentControl alloc] initWithFrame:CGRectMake(0, 0, 280, 30)];
    
    seg.center=self.navigationImageView.center;
    seg.NormalIcons=
    @[
      LOAD_IMAGE(@"btn_radio_left.png"),
      LOAD_IMAGE(@"btn_radio_mid.png"),
      LOAD_IMAGE(@"btn_radio_right.png")
      ];
    seg.SelectIcons=
    @[
      LOAD_IMAGE(@"btn_radio_left_selected.png"),
      LOAD_IMAGE(@"btn_radio_mid_selected.png"),
      LOAD_IMAGE(@"btn_radio_right_selected.png")
      ];
    seg.titleNormalIcons=
    @[
      LOAD_IMAGE(@"title_house.png"),
      LOAD_IMAGE(@"title_restaurant.png"),
      LOAD_IMAGE(@"title_agent.png")
      ];
    seg.titleSelectedIcons=
    @[
      LOAD_IMAGE(@"title_house_selected.png"),
      LOAD_IMAGE(@"title_restaurant_selected.png"),
      LOAD_IMAGE(@"title_agent_selected.png")
      ];

    
    [seg createSegmentControlWithSegType:SegmentControlTitleIconAndBackGround selectedBlock:^(NSInteger selectIndex, UIView *selectView) {
        [_mainScrollView setContentOffset:CGPointMake(selectIndex * CGRectGetWidth(_mainScrollView.frame), 0) animated:YES];
    }];
    seg.tag=10;
    [seg selectAtIndex:0];
    seg.isDoubleClcik=YES;
    seg.backgroundColor=[UIColor clearColor];
    [self.view addSubview:seg];
    
    UIEdgeInsets insets = UIEdgeInsetsMake(20.0f, 0.0f, 20.0f, 0.0f);
    UIImage *image=LOAD_IMAGE(@"background2.png");
    UIImage *tempImage= IMAGE_STRRTCHABLE(image, insets.left, insets.top);
    self.contentView.image=tempImage;
    
    _mainScrollView.contentSize=CGSizeMake(CGRectGetWidth(_mainScrollView.frame)*3, CGRectGetHeight(_mainScrollView.frame));
    _mainScrollView.pagingEnabled=YES;
    _mainScrollView.showsVerticalScrollIndicator=NO;
    _mainScrollView.delegate=self;
    
    _favouriteHome = [[HEFavouriteHouseViewController alloc] init];
    _favouriteHome.view.frame=_mainScrollView.bounds;
    _favouriteHome.tableView.backgroundColor=[UIColor clearColor];
    _favouriteHome.viewController=self;

    [_mainScrollView addSubview:_favouriteHome.view];
    
    _favouriteDining = [[HEFavouriteDiningViewController alloc] init];
    _favouriteDining.view.frame=CGRectMake(CGRectGetWidth(_mainScrollView.frame), 0, CGRectGetWidth(_mainScrollView.frame), CGRectGetHeight(_mainScrollView.frame));
    _favouriteDining.tableView.backgroundColor=[UIColor clearColor];
    [_mainScrollView addSubview:_favouriteDining.view];
    
    _favouriteAgent  = [[HEFavouriteAgentViewController alloc] init];
    _favouriteAgent.view.frame=CGRectMake(CGRectGetWidth(_mainScrollView.frame)*2, 0, CGRectGetWidth(_mainScrollView.frame), CGRectGetHeight(_mainScrollView.frame));
    _favouriteAgent.tableView.backgroundColor=[UIColor clearColor];
    _favouriteAgent.viewContoller=self;
    [_mainScrollView addSubview:_favouriteAgent.view];
    
}


-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    [seg selectAtIndex:scrollView.contentOffset.x/CGRectGetWidth(scrollView.frame)];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}
-(BOOL)useline
{
    return YES;
}


@end
