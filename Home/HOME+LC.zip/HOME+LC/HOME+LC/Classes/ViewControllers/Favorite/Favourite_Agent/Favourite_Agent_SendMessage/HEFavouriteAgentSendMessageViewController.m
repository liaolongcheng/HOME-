//
//  HEFavouriteAgentSendMessageViewController.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-6-1.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEFavouriteAgentSendMessageViewController.h"
#import "HEMessage.h"

@interface HEFavouriteAgentSendMessageViewController ()
{
    NSString *_name;
    NSString *_phone;
}

@end

@implementation HEFavouriteAgentSendMessageViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.contentImageView.frame=CGRectMake(self.contentImageView.frame.origin.x, self.contentImageView.frame.origin.y, self.contentImageView.frame.size.width, 200);
    self.nameLable.shouldUnderline=YES;
    self.nameLable.textColor = [UIColor blueColor];
    
    self.nameLable.text=[NSString stringWithFormat:@"%@(%@)",_name,_phone];
}

-(instancetype)initWithName:(NSString *)name phone:(NSString *)phone
{
    self=[super initWithNibName:@"HEFavouriteAgentSendMessageViewController" bundle:nil];
    if (self) {
        
        _name=name;
        _phone=phone;
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSString *)navBarTitle
{
    return @"Send Message";
}

- (IBAction)sendClick:(id)sender
{
    HEMessage *message=[[HEMessage alloc] init];
    message.toUserId=_phone;
    message.messageContent=self.messageText.text;
    [message sendMessageToUser:^(id responesObject) {
        
        [SVProgressHUD showSuccessWithStatus:@"发送成功..." duration:2.0];
        [self.navigationController popViewControllerAnimated:YES];
        
    } error:nil];
    
}
@end
