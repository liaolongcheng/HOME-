//
//  HEFavouriteAgentSendMessageViewController.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-6-1.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEPublicBaseViewController.h"
#import "HEUnderLineLable.h"

@interface HEFavouriteAgentSendMessageViewController : HEPublicBaseViewController
@property (strong, nonatomic) IBOutlet HEUnderLineLable *nameLable;
@property (strong, nonatomic) IBOutlet UITextView *messageText;

-(instancetype) initWithName:(NSString *)name phone:(NSString *)phone;

- (IBAction)sendClick:(id)sender;

@end
