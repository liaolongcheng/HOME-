//
//  HEFavouriteAgentViewController.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-15.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEFavouriteAgentViewController.h"
#import "HEAgentInfo.h"
#import "HEAgentCell.h"
#import "HEHomeHouseAgentViewController.h"

@interface HEFavouriteAgentViewController ()
{
    HEAgentInfo *_agent;
    NSMutableArray *_sourceArray;
}
@end

@implementation HEFavouriteAgentViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    _sourceArray=[[NSMutableArray alloc] init];
    _agent=[[HEAgentInfo alloc] init];
    _agent.page=0;
    
    
    if (!USER_ISLOGIN)
    {
        BH_ALERT(@"You are not logged in.");
        return;
    }
    
}
-(void) publicRequest:(BOOL) isMore svType:(SVProgressHUDMaskType) svType
{
    [_agent requestFavouriteAgentWith:^(id response) {
        if (!isMore)
        {
            [_sourceArray removeAllObjects];
            [_sourceArray addObjectsFromArray:response];
            [self.tableView reloadData];
            [self endRefresh];
        }
        else
        {
            [_sourceArray addObjectsFromArray:response];
            [self.tableView reloadData];
            [self endRefresh];
        }
        
    } errorBlock:^{
         [self endRefresh];
    } svType:svType];

}

-(BOOL)usesRefreshHeaderView
{
    return YES;
}
-(BOOL)usesRefreshFooterView
{
    return NO;
}
-(BOOL)usesAutoRefresh
{
    return NO;
}

-(void)didStartLoadingMoreObjects
{
    _agent.page += 1;
    [self publicRequest:YES svType:SVProgressHUDMaskTypeNil];
}
-(void)didStartLoadingNewObjects
{
    _agent.page = 0;
    [self publicRequest:NO svType:SVProgressHUDMaskTypeNil];
}

-(void) endRefresh
{
    [super didEndLoadingMoreObjects];
    [super didEndLoadingNewObjects];;
}


-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [_sourceArray count];
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *str=@"Cell";
    HEAgentCell *cell=[tableView dequeueReusableCellWithIdentifier:str];
    if (!cell) {
        cell = LOAD_TABLEVIEWCELL(@"HEAgentCell");
    }
    NSDictionary *agent=_sourceArray[indexPath.row];
    cell.nameLable.text=agent[@"name"];
    cell.nameContentLable.text=agent[@"company"];
    [cell.PhotoImageView setImageWithURL:IMAGEURLCREATE(agent[@"profile_image"]) placeholderImage:DEFAULTIMAGE];
    cell.publisherPhone=agent[@"phone"];
    cell.viewController=(HEBaseViewController*)self.viewContoller;
    cell.publisherName=agent[@"name"];
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 92;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{

    HEHomeHouseAgentViewController *agent = [[HEHomeHouseAgentViewController alloc] initWithPublishId:_sourceArray[indexPath.row][@"_id"] houseId:nil houseArray:nil];
    [self.viewContoller.navigationController pushViewController:agent animated:YES];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
