//
//  HomeViewController.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-14.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HESegmentControl.h"

@interface HomeViewController : UIViewController
- (IBAction)postThree:(id)sender;
- (IBAction)postUpdate:(id)sender;

@end
