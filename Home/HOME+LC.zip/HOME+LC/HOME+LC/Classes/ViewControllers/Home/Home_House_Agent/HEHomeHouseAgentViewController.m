//
//  HEHomeHouseAgentViewController.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-29.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEHomeHouseAgentViewController.h"
#import "HEAgentInfo.h"
#import "HEHTTPSearchHouse.h"
#import "HEFavouriteHouseCell.h"
#import "HEHomeHouseDetailViewController.h"
#import <QuartzCore/QuartzCore.h>
#import "HEHouseInfo.h"
#import "AreaAndLinesUtily.h"

@interface HEHomeHouseAgentViewController ()
{
    NSString *_publisherId;
    NSString *_houseId;
    NSArray *_sourceArray;
    NSDictionary *_agentInfoDic;
}

@end

@implementation HEHomeHouseAgentViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(instancetype) initWithPublishId:(NSString *)publishId houseId:(NSString *)houseId houseArray:(NSArray *) houseArray
{
    self=[super init];
    if (self) {
        _publisherId=publishId;
        _houseId = houseId;
    }
    return self;
}



- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.contentImageView.hidden=YES;
    self.headerImageView.image = IMAGE_STRRTCHABLE(self.headerImageView.image, 20, 20);
    self.tableContentImageView.image = IMAGE_STRRTCHABLE(self.tableContentImageView.image, 20, 20);
    self.ivatarImageView.layer.masksToBounds = YES;
    self.ivatarImageView.layer.cornerRadius = 5;
    
    self.view.hidden=YES;
    
    
    _emailLable.shouldUnderline=YES;

    _starView.backgroundColor=[UIColor clearColor];
    _starView.padding = 10;
    _starView.alignment = RateViewAlignmentRight;
    _starView.numOfStars = 3;
    _starView.rate=0;
    
    self.houseTableView.backgroundColor=[UIColor clearColor];
    
    
    HEAgentInfo *agenInfo=[[HEAgentInfo alloc] init];
    agenInfo.publisherId=_publisherId;
    agenInfo.houseId=_houseId;
    
    if (USER_ISLOGIN && _houseId)
    {
        [agenInfo addContactToCurrentUser:^(id response) {
            TOST_SHOW(@"addContact success");
        } errorBlock:^{
            TOST_SHOW(@"addContact error");
        }];
    }
    
  
  
    [agenInfo requestAgentInfoWith:^(id response) {
        
        _agentInfoDic = response;
        
        self.nameLable.text=response[@"name"];
        self.nameContentLable.text=response[@"company"];
        self.addressLable.text=response[@"address"];
        self.phoneLable.text=[NSString stringWithFormat:@"%@",response[@"phone"]];
        _starView.rate = [response[@"score"] floatValue];
        self.commentLable.text=[NSString stringWithFormat:@"%@ comments",response[@"count"]];
        [self.ivatarImageView setImageWithURL:IMAGEURLCREATE(response[@"profile_image"]) placeholderImage:DEFAULTIMAGE];
        
        if (USER_ISLOGIN)
        {
            agenInfo.page=0;
            [agenInfo requestFavouriteAgentWith:^(id response) {
                
                NSArray *array=response;
                for (int i=0; i<[array count]; i++)
                {
                    if ([[NSString stringWithFormat:@"%@",array[i][@"_id"]] isEqualToString:[NSString stringWithFormat:@"%@",_publisherId]])
                    {
                        self.agentButton.selected=YES;
                    }
                }
                
            } errorBlock:nil svType:SVProgressHUDMaskTypeNil];
        }

    } errorBlock:nil];
    
    self.houseTableView.delegate=self;
    self.houseTableView.dataSource=self;
    
    HEHouseInfo *houseInfo = [[HEHouseInfo alloc] init];
    houseInfo.publisherId = _publisherId;
    
    [houseInfo requestCurrentUserPostHouse:^(id houseInfo) {
        self.view.hidden=NO;
        _sourceArray=houseInfo;
        [self.houseTableView reloadData];
    } requestError:nil svType:SVProgressHUDMaskTypeNil];

    
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [_sourceArray count];
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *str=@"Cell";
    HEFavouriteHouseCell *cell=[tableView dequeueReusableCellWithIdentifier:str];
    if (!cell)
    {
        cell = LOAD_TABLEVIEWCELL(@"HEFavouriteHouseCell");
    }
    
    NSDictionary *house=_sourceArray[indexPath.row];
    
    cell.titleLable.text=house[@"name_en"];
    cell.timeLable.text=[NSString formatterTimeWithString:house[@"publishDate"]];
    cell.priceLable.text=[NSString stringWithFormat:@"%@ RMB",house[@"price"]];
    cell.roomLable.text = [NSString stringWithFormat:@"%@ bedroom",house[@"bedrooms"]];
    if ([house[@"metro"] count] >= 1)
    {
        NSString *lineInfoStr = [[AreaAndLinesUtily sharedAreaLines] enNameWithMetroId:house[@"metro"][0]];
        cell.lineLable.text = [lineInfoStr substringToIndex:[lineInfoStr rangeOfString:@" "].location + 2];
    }
    else
    {
        cell.lineLable.text = @"";
    }
    if ([house[@"area"] count] >= 1)
    {
        NSString *addInfoStr = [[AreaAndLinesUtily sharedAreaLines] enNameWithAreaId:house[@"area"][0]];
        cell.addressLable.text = [addInfoStr substringToIndex:[addInfoStr rangeOfString:@" "].location + 2];
    }
    else
    {
        cell.addressLable.text =@"";
    }
    
    [cell.houseImageView setImageWithURL:IMAGEURLCREATE(house[@"picture"]) placeholderImage:DEFAULTIMAGE];    [cell.houseImageView setImageWithURL:IMAGEURLCREATE(house[@"picture"]) placeholderImage:DEFAULTIMAGE];
    
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 231;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    HEHomeHouseDetailViewController *detail=[HEHomeHouseDetailViewController sharedHouseDetail];
    detail.houseId=_sourceArray[indexPath.row][@"_id"];
    [detail releadeHouseInfo];
    
    NSArray *viewContollers=[self.navigationController viewControllers];
    if ([viewContollers containsObject:detail])
    {
        [self.navigationController popToViewController:detail animated:YES];
    }
    else
    {
        [self.navigationController pushViewController:detail animated:YES];
    }
    
}

- (IBAction)AgentClick:(id)sender
{
    
    if (!USER_ISLOGIN)
    {
        BH_ALERT(@"You are not logged in.");
        return;
    }
    
//    if ([_agentInfoDic[@"type"] isEqualToString:@"consumer"]) {
//        
//        BH_ALERT(@"The listing information disintermediation");
//        
//        return;
//    }
    HEAgentInfo *agent=[[HEAgentInfo alloc] init];
    agent.publisherId=_publisherId;
    
    if (self.agentButton.selected)
    {
        [agent removeAgentFromFavourite:^(id response) {
            TOST_SHOW(@"delete agent success");
            self.agentButton.selected=NO;
        } errorBlock:^{
            TOST_SHOW(@"delete agent error");
        }];
    }
    else
    {
        [agent addAgentToFavourite:^(id response) {
            self.agentButton.selected=YES;
            TOST_SHOW(@"Collection agency success");
        } errorBlock:^{
            TOST_SHOW(@"Collection agency error");
        }];
    }
}

-(NSString *)navBarTitle
{
    return @"Agent";
}
-(BOOL)isCreateSegmenetControllExpand
{
    return NO;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
