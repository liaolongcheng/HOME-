//
//  HEHomeHouseAgentViewController.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-29.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEPublicBaseViewController.h"
#import "HEUnderLineLable.h"
#import "HERateStartView.h"

@interface HEHomeHouseAgentViewController : HEPublicBaseViewController<UITableViewDataSource,UITableViewDelegate>
@property (strong, nonatomic) IBOutlet UIImageView *headerImageView;
@property (strong, nonatomic) IBOutlet UIImageView *ivatarImageView;
@property (strong, nonatomic) IBOutlet UILabel *nameLable;
@property (strong, nonatomic) IBOutlet UILabel *nameContentLable;
@property (strong, nonatomic) IBOutlet UILabel *addressLable;
@property (strong, nonatomic) IBOutlet UILabel *phoneLable;
@property (strong, nonatomic) IBOutlet HEUnderLineLable *emailLable;
@property (strong, nonatomic) IBOutlet HERateStartView *starView;
@property (strong, nonatomic) IBOutlet UILabel *commentLable;

@property (strong, nonatomic) IBOutlet UIImageView *tableContentImageView;
@property (strong, nonatomic) IBOutlet UITableView *houseTableView;
@property (strong, nonatomic) IBOutlet UIButton *agentButton;

-(instancetype) initWithPublishId:(NSString *)publishId houseId:(NSString *)houseId houseArray:(NSArray *) houseArray;
- (IBAction)AgentClick:(id)sender;
@end
