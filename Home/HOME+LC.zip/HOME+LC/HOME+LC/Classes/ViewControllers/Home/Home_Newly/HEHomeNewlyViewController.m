//
//  HEHomeNewlyViewController.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-18.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEHomeNewlyViewController.h"
#import "HEHTTPSearchHouse.h"
#import "HEFavouriteHouseCell.h"

@interface HEHomeNewlyViewController ()
{

}

@end

@implementation HEHomeNewlyViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
  
    [super viewDidLoad];
    HEHTTPSearchHouse *_search=[HEHTTPSearchHouse sharedHouse];
    _search.orderBy=ORDER_BY_PUBLISH_TIME;

}
-(BOOL)isCreateListAndMap
{
    return NO;
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(NSString *)navBarTitle
{
    return @"NewLy";
}


@end
