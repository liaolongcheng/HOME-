//
//  HEHomeHouseDetailViewController.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-27.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEPublicBaseViewController.h"

@interface HEHomeHouseDetailViewController : HEPublicBaseViewController<UITableViewDataSource,UITableViewDelegate>
@property (strong, nonatomic) IBOutlet UITableView *houseDetailTableView;

+(instancetype) sharedHouseDetail;
@property (nonatomic,strong) NSString *houseId;
@property (strong, nonatomic) IBOutlet UIButton *favouriteBtn;


-(void) releadeHouseInfo;
-(instancetype) initWithHouseId:(NSString *) houseId;
- (IBAction)favouriteBtnClick:(id)sender;

@end
