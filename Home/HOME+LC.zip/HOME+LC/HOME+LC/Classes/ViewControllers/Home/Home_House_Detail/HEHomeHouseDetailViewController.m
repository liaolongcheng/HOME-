//
//  HEHomeHouseDetailViewController.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-27.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEHomeHouseDetailViewController.h"
#import "HEHouseDetailCell.h"
#import "HEHouseInfo.h"
#import "HEUserLogin.h"
#import "HEFavourite.h"


@interface HEHomeHouseDetailViewController ()
{
    NSDictionary *_houseInfoDic;
    NSArray *_favouriteArray;
    HEHouseDetailCell *detailCell;
}

@end

@implementation HEHomeHouseDetailViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}


+(instancetype)sharedHouseDetail
{
    static HEHomeHouseDetailViewController *detail;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        detail=[[HEHomeHouseDetailViewController alloc] init];
    });
    return detail;
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self hiddenTabBar];
}
-(instancetype)initWithHouseId:(NSString *)houseId
{
    self=[super init];
    if (self) {
        _houseId=houseId;
    }
    return self;
}

//删除或者添加收藏
- (IBAction)favouriteBtnClick:(id)sender
{
    if (USER_ISLOGIN)
    {
        HEFavourite *favourite=[[HEFavourite alloc] init];
        favourite.houseId=_houseInfoDic[@"_id"];
        
        //添加到收藏
        if (!self.favouriteBtn.selected)
        {
            [favourite addHouseToFavourite:^(id responesObject) {
                
                TOST_SHOW(@"Add to Favorites Success");
                self.favouriteBtn.selected=YES;
            } reteriealError:^{
                TOST_SHOW(@"Add to Favorites Error");
            } svType:SVProgressHUDMaskTypeNil];
        }
        //删除收藏
        else
        {
            [favourite removeHouseFromFavourite:^(id responesObject) {
                TOST_SHOW(@"remove to Favorites Success");
                self.favouriteBtn.selected=NO;
            } reteriealError:^{
                TOST_SHOW(@"remove to Favorites Error");
            } svType:SVProgressHUDMaskTypeNil];
        }
    }
    else
    {
        BH_ALERT(@"You are not logged in.");
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.contentImageView.hidden=YES;
    
      // Do any additional setup after loading the view from its nib.
}


-(void)releadeHouseInfo
{
    self.favouriteBtn.selected=NO;
    self.contentImageView.hidden=YES;
    self.houseDetailTableView.hidden=YES;
   

    HEHouseInfo *houseInfo=[[HEHouseInfo alloc] init];
    houseInfo.houseId=_houseId;
    
    [houseInfo requestHouseInfoWithSuccess:^(id houseInfo) {
        
        _houseInfoDic=houseInfo;
        self.houseDetailTableView.hidden=NO;
        self.houseDetailTableView.dataSource=self;
        self.houseDetailTableView.delegate=self;
        self.houseDetailTableView.backgroundColor=[UIColor clearColor];
        [self.houseDetailTableView reloadData];
        
        
        if(USER_ISLOGIN)
        {
            HEFavourite *favourite=[[HEFavourite alloc] init];
            [favourite retrievalFavoureteHouse:^(id responesObject) {
                _favouriteArray=responesObject;
                
                for (int i=0; i<[_favouriteArray count]; i++)
                {
                    if ([_houseInfoDic[@"_id"] isEqualToString:_favouriteArray[i][@"_id"] ])
                    {
                        self.favouriteBtn.selected=YES;
                        break;
                    }
                }
                
            } reteriealError:Nil svType:SVProgressHUDMaskTypeNil];
        }
    } requestError:nil];
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    detailCell.houseInfoDic=_houseInfoDic;
    detailCell.viewController=self;
    return detailCell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (detailCell == nil)
    {
        detailCell=LOAD_TABLEVIEWCELL(@"HEHouseDetailCell");
    }

    CGFloat tepHeight = [_houseInfoDic[@"description_en"] getHeightByWidth:detailCell.descrpitionText.frame.size.width font:detailCell.descrpitionText.font];
    if (detailCell.openDescButton.selected && tepHeight > 54)
    {
        return 767 + tepHeight + 26;
    }
    detailCell.descrpitionText.frame = CGRectMake(detailCell.descrpitionText.frame.origin.x, detailCell.descrpitionText.frame.origin.y, CGRectGetWidth(detailCell.descrpitionText.frame), 54);
    return 821;
}

-(BOOL)useline
{
    return YES;
}

-(BOOL)isCreateSegmenetControllExpand
{
    return NO;
}
-(NSString *)navBarTitle
{
    return @"Detail";
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
