//
//  HEHomeHotspotSearchViewController.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-27.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEHomeHotspotSearchViewController.h"
#import "HEHTTPSearchHouse.h"

@interface HEHomeHotspotSearchViewController ()
{
    HEHTTPSearchHouse *_search;
    NSString *_area;
}

@end

@implementation HEHomeHotspotSearchViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(instancetype)initWtihArea:(NSString *)area
{
    self = [super init];
    if (self)
    {
        _area = area;
    }
    return self;
}

- (void)viewDidLoad
{
    _search = [HEHTTPSearchHouse sharedHouse];
    _search.area=_area;

    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
}
-(SearchConditionType)searchConditionType
{
    return SearchConditionTypeWithHotspot;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
