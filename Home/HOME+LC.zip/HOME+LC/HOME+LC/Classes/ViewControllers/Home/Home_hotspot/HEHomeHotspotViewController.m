//
//  HEHomeHotspotViewController.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-18.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEHomeHotspotViewController.h"
#import "HEHomeHotspotSearchViewController.h"

@interface HEHomeHotspotViewController ()
{

}

@end

@implementation HEHomeHotspotViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
   
}
-(void)secandTableDidSelected:(UITableView *)secandTableView indexPath:(NSIndexPath *)indexPath firstTableViewSelectIndex:(NSInteger)firstTableViewSelectIndex secandTableViewSelectContent:(NSString *)secandTableViewSelectContent
{
    HEHomeHotspotSearchViewController *homeSearch=[[HEHomeHotspotSearchViewController alloc] initWtihArea:secandTableViewSelectContent];
    [self.navigationController pushViewController:homeSearch animated:YES];
}
-(NSString *)loadFileName
{
    return @"areasInfo";
}
-(NSString *)navBarTitle
{
    return @"Hotspot";
}
@end
