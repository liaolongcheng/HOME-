//
//  HEHomeViewController.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-15.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HEBaseViewController.h"

@interface HEHomeViewController : HEBaseViewController
- (IBAction)NearbyClick:(id)sender;
- (IBAction)HostspotClick:(id)sender;
- (IBAction)MetroClick:(id)sender;
- (IBAction)NewlyClick:(id)sender;
- (IBAction)MapClick:(id)sender;
- (IBAction)PostClick:(id)sender;

@end
