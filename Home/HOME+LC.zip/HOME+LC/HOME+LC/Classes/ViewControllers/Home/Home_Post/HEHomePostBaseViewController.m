//
//  HEHomePostBaseViewController.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-18.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEHomePostBaseViewController.h"

@interface HEHomePostBaseViewController ()

@end

@implementation HEHomePostBaseViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    self.contentImageView.frame=CGRectMake(self.contentImageView.frame.origin.x, self.contentImageView.frame.origin.y, CGRectGetWidth(self.contentImageView.frame), CGRectGetHeight(self.contentImageView.frame)-50);
    self.contentImageView.userInteractionEnabled=YES;

    _leftButton=[[UIButton alloc] initWithFrame:CGRectMake(self.contentImageView.frame.origin.x, self.contentImageView.frame.origin.y+CGRectGetHeight(self.contentImageView.frame)+10, 130, 30)];
    [_leftButton setBackgroundImage:LOAD_IMAGE(@"btn_back.png") forState:UIControlStateNormal];
    [_leftButton setTitleColor:[UIColor darkGrayColor] forState:UIControlStateNormal];
    _leftButton.titleLabel.font=FONT(16);
    [_leftButton addTarget:self action:@selector(leftButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    [_leftButton setTitle:[self leftButtonTitle] forState:UIControlStateNormal];
    [self.view addSubview:_leftButton];
    _leftButton.autoresizesSubviews=YES;
    //[self.view insertSubview:_leftButton atIndex:100];
    
    _rightbutton=[[UIButton alloc] initWithFrame:CGRectMake(320-self.contentImageView.frame.origin.x-130, self.contentImageView.frame.origin.y+CGRectGetHeight(self.contentImageView.frame)+10, 130, 30)];
    
    [_rightbutton setBackgroundImage:LOAD_IMAGE(@"btn_back.png") forState:UIControlStateNormal];
    [_rightbutton setTitleColor:[UIColor darkGrayColor] forState:UIControlStateNormal];
    _rightbutton.titleLabel.font=FONT(16);
    [_rightbutton addTarget:self action:@selector(rightButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    [_rightbutton setTitle:[self rightButtonTitle] forState:UIControlStateNormal];
    _rightbutton.autoresizesSubviews=YES;
    [self.view addSubview:_rightbutton];
    
}

-(void)leftButtonClick:(UIButton *)btn
{
    [self.navigationController popViewControllerAnimated:YES];
    
   
}
-(void)rightButtonClick:(UIButton *)btn
{
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(NSString *)leftButtonTitle
{
    return @"Cancel";
}
-(NSString *)rightButtonTitle
{
    return @"Next Step";
}


@end
