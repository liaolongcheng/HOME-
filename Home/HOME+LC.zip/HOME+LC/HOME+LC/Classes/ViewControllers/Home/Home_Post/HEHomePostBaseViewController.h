//
//  HEHomePostBaseViewController.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-18.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEBaseViewController.h"
#import "HEPublicContentImageViewController.h"

@interface HEHomePostBaseViewController : HEPublicContentImageViewController

@property (nonatomic,strong) UIButton *leftButton;
@property (nonatomic,strong) UIButton *rightbutton;

-(NSString *)leftButtonTitle;
-(NSString *)rightButtonTitle;

-(void) leftButtonClick:(UIButton *) btn;
-(void) rightButtonClick:(UIButton *) btn;


@end
