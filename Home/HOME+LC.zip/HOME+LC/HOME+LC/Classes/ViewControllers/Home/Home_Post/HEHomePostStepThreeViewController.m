//
//  HEHomePostStepThreeViewController.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-18.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEHomePostStepThreeViewController.h"
#import "HEHomeMapViewController.h"
#import "HEHouseInfo.h"
#import "HELinkageExView.h"
@interface HEHomePostStepThreeViewController ()
{
    NSMutableDictionary *_dic;
    NSString *_area;
    NSString *_metro;
}

@end

@implementation HEHomePostStepThreeViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    _area = @"51e370f7cf71bf5d2e000009";
    _metro = @"51e370f7cf71bf5d2e000017";
    
    HELinkageExView *areaTempView=[[HELinkageExView alloc] initWithFrame:self.areaLinkView.frame fileName:@"areasInfo"];
    [self.view addSubview:areaTempView];
    areaTempView.selectBlock = ^(NSString *str)
    {
        _area=str;
    };
    
    HELinkageExView *metroTempView=[[HELinkageExView alloc] initWithFrame:self.metroLinkView.frame fileName:@"linesInfo"];
    [self.view insertSubview:metroTempView belowSubview:areaTempView];
    metroTempView.selectBlock = ^(NSString *str)
    {
        _metro=str;
    };
 
}



-(instancetype)initWithHouseDic:(NSMutableDictionary *)dic
{
    self = [super init];
    if (self)
    {
        _dic = dic;
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSString *)navBarTitle
{
    return @"Step3";
}
-(NSString *)rightButtonTitle
{
    return @"Post House";
}
-(NSString *)leftButtonTitle
{
    return @"Pre Step";
}
-(void)rightButtonClick:(UIButton *)btn
{
    if (IS_KONG_STRING(self.addressText.text)) {
        BH_ALERT(@"Please fill in address");
        return;
    }
    if (IS_KONG_STRING(self.descriptionText.text)) {
        BH_ALERT(@"Please fill in descriptionText");
        return;
    }
   
    HEHouseInfo *house=[[HEHouseInfo alloc] init];
    house.housePhotos = _dic[@"photos"];
    house.nameEN = _dic[@"title"];
    house.floor = [_dic[@"floor"] intValue];
    house.totalFloor = [_dic[@"totalFloor"] intValue];
    house.longitude = @"121.48";
    house.latitude = @"31.22";
    house.area = _area;
    house.metro = _metro;
    house.descriptionEN = self.descriptionText.text;
    house.address = self.addressText.text;
    house.price = _dic[@"price"];
    house.outspace = [_dic[@"outspace"] boolValue];
    house.size = _dic[@"size"];
    house.share = [_dic[@"shared"] boolValue];
    house.bedrooms = _dic[@"bedrooms"];
    house.bathrooms = _dic[@"bathrooms"];
    house.livingrooms = _dic[@"livingrooms"];
    
    [house postHouse:^(id houseInfo) {
        
        [self.navigationController popToRootViewControllerAnimated:YES];
    } requestError:^{
        [SVProgressHUD showErrorWithStatus:@"post house error" duration:1.0];
    } svType:SVProgressHUDMaskTypeClear];
}
-(void)gpsButtonClick:(id)sender
{
    HEHomeMapViewController *mapViewController = [[HEHomeMapViewController alloc] initWithLongTapMapBlock:^(NSString *Longitude, NSString *Latitude, NSString *addressInfo) {
        self.addressText.text = addressInfo;
    }];
    [self.navigationController pushViewController:mapViewController animated:YES];
}

@end
