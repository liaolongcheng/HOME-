//
//  HEHomePostStepThreeViewController.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-18.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEHomePostBaseViewController.h"
#import "HELinkageView.h"

@interface HEHomePostStepThreeViewController : HEHomePostBaseViewController<UITextFieldDelegate,UITextViewDelegate>

@property (strong, nonatomic) IBOutlet UIView *areaLinkView;
@property (strong, nonatomic) IBOutlet UIView *metroLinkView;
@property (strong, nonatomic) IBOutlet UITextField *addressText;
@property (strong, nonatomic) IBOutlet UITextView *descriptionText;
- (IBAction)gpsButtonClick:(id)sender;

-(instancetype) initWithHouseDic:(NSMutableDictionary *) dic;


@end
