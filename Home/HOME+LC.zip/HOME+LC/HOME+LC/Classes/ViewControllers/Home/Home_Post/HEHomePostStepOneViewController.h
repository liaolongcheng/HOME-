//
//  HEHomePostStepOneViewController.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-18.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEHomePostBaseViewController.h"

@interface HEHomePostStepOneViewController : HEHomePostBaseViewController<UIScrollViewDelegate>

@end
