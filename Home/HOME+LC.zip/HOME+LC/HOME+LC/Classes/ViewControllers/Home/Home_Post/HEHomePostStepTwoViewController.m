//
//  HEHomePostStepTwoViewController.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-18.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//
#define ACCEPTABLE_CHARECTERS @"0123456789."

#import "HEHomePostStepTwoViewController.h"
#import "HEHomePostStepThreeViewController.h"
#import "HECheckRoomsView.h"
#import "AlertCustom.h"
#import "KeyboardManager.h"

@interface HEHomePostStepTwoViewController ()
{
    BOOL _isAllowed;
    
    CGRect _frame;
    
    NSArray *_photpsArray;

}

@end

@implementation HEHomePostStepTwoViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;

}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    _isAllowed=YES;
    
    _frame=self.view.frame;
    
    self.view.autoresizesSubviews=YES;
}

- (IBAction)outSpaceClcik:(id)sender
{
    _outspaceButton.selected = !_outspaceButton.selected;
}

- (IBAction)sharedClick:(id)sender
{
    _sharedButton.selected = !_sharedButton.selected;
}

-(instancetype)initWithPhotos:(NSArray *)photoArray
{
    self=[super init];
    if (self) {
        _photpsArray = [NSArray arrayWithArray:photoArray];
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



-(NSString *)leftButtonTitle
{
    return @"Pre Step";
}
-(NSString *)navBarTitle
{
    return @"Step2";
}


-(void)rightButtonClick:(UIButton *)btn
{
    
    
    if (IS_KONG_STRING(self.titleText.text)) {
        BH_ALERT(@"Please fill in the title");
        return;
    }
    if (IS_KONG_STRING(self.priceText.text)) {
        BH_ALERT(@"Please fill in the price");
        return;
    }
    if (IS_KONG_STRING(self.bedroomsText.text)) {
        BH_ALERT(@"Please fill in the bedroomsText");
        return;
    }
    if (IS_KONG_STRING(self.bathroomsText.text)) {
        BH_ALERT(@"Please fill in bathroomsText");
        return;
    }
    if (IS_KONG_STRING(self.livingroomsText.text)) {
        BH_ALERT(@"Please fill in livingroomsText");
        return;
    }
    if (IS_KONG_STRING(self.sizeText.text)) {
        BH_ALERT(@"Please fill in size");
        return;
    }
    if (IS_KONG_STRING(self.floorText.text)) {
        BH_ALERT(@"Please fill in floor");
        return;
    }
    if (IS_KONG_STRING(self.totalText.text)) {
        BH_ALERT(@"Please fill in totalFloor");
        return;
    }
    if ([self.floorText.text intValue] > [self.totalText.text intValue])
    {
        BH_ALERT(@"floor data error");
        return;
    }
    
    
    NSMutableDictionary *dic=[[NSMutableDictionary alloc] init];
    [dic setObject:_photpsArray forKey:@"photos"];
    [dic setObject:self.titleText.text forKey:@"title"];
    [dic setObject:self.priceText.text forKey:@"price"];
    [dic setObject:self.bedroomsText.text forKey:@"bedrooms"];
    [dic setObject:self.bathroomsText.text forKey:@"bathrooms"];
    [dic setObject:self.livingroomsText.text forKey:@"livingrooms"];
    [dic setObject:@(self.outspaceButton.selected) forKey:@"outspace"];
    [dic setObject:@(self.sharedButton.selected) forKey:@"shared"];
    [dic setObject:self.sizeText.text forKey:@"size"];
    [dic setObject:self.floorText.text forKey:@"floor"];
    [dic setObject:self.totalText.text forKey:@"totalFloor"];
    
    HEHomePostStepThreeViewController *stepThree=[[HEHomePostStepThreeViewController alloc] initWithHouseDic:dic];
    [self.navigationController pushViewController:stepThree animated:YES];
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)strin
{
    if (textField.tag == 104)
    {
        if (textField.text.length < 4 || [strin isEqualToString:@""])
        {
            return YES;
        }
        else
        {
            return NO;
        }
    }
    if (textField.tag == 101 || textField.tag == 102 || textField.tag == 103)
    {
        return NO;
    }
    if (textField.tag == 105 || textField.tag == 106)
    {
        if (textField.text.length < 2 || [strin isEqualToString:@""])
        {
            return YES;
        }
        else
        {
            return NO;
        }
        
    }
    return YES;
}
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    if (textField.tag == 101 || textField.tag == 102 || textField.tag == 103)
    {
    
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.01 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            
            RESIGNFIRSTRESPONDER;
            HECheckRoomsView *rooms = [[HECheckRoomsView alloc] initWithUITextField:textField];
            [AlertCustom showWithView:rooms];
        });
       
    }
}

- (IBAction)click:(id)sender
{
}
@end
