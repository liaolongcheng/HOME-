//
//  HEHomePostStepTwoViewController.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-18.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEHomePostBaseViewController.h"
#import "ComBoxView.h"

@interface HEHomePostStepTwoViewController : HEHomePostBaseViewController<UITextFieldDelegate>
@property (strong, nonatomic) IBOutlet UITextField *bedroomsText;
@property (strong, nonatomic) IBOutlet UITextField *bathroomsText;
@property (strong, nonatomic) IBOutlet UITextField *livingroomsText;
@property (strong, nonatomic) IBOutlet UITextField *titleText;
@property (strong, nonatomic) IBOutlet UITextField *priceText;
@property (strong, nonatomic) IBOutlet UIButton *outspaceButton;
@property (strong, nonatomic) IBOutlet UIButton *sharedButton;
@property (strong, nonatomic) IBOutlet UITextField *sizeText;
@property (strong, nonatomic) IBOutlet UITextField *floorText;
@property (strong, nonatomic) IBOutlet UITextField *totalText;
- (IBAction)outSpaceClcik:(id)sender;
- (IBAction)sharedClick:(id)sender;

-(instancetype) initWithPhotos:(NSArray *)photoArray;
- (IBAction)click:(id)sender;

@end
