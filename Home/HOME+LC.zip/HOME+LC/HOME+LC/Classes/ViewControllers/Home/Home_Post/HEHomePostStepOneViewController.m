//
//  HEHomePostStepOneViewController.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-18.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEHomePostStepOneViewController.h"
#import "HECheckPhotoView.h"
#import "AlertCustom.h"
#import "HEHomePostStepTwoViewController.h"


@interface HEHomePostStepOneViewController ()
{
    UIScrollView *_imageScrollView;
    NSMutableArray *_photosArray;
    UIPageControl *_pageControl;
}

@end

@implementation HEHomePostStepOneViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    _photosArray = [[NSMutableArray alloc] init];
    
    UIButton *addPhotoButton=[[UIButton alloc] initWithFrame:CGRectMake(0, 0, 40, 30)];
    addPhotoButton.center=CGPointMake(CGRectGetMidX(self.contentImageView.frame), 100);
    [addPhotoButton setImage:LOAD_IMAGE(@"btn_photo.png") forState:UIControlStateNormal];
    [addPhotoButton addTarget:self action:@selector(takePhotoClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.contentImageView addSubview:addPhotoButton];
    
    UILabel *lable=[[UILabel alloc] initWithFrame:CGRectMake(0, 0, 320, 30)];
    lable.center=CGPointMake(CGRectGetMidX(self.contentImageView.frame), 300);
    lable.text=@"Add photos to your listings";
    lable.font=FONT(18);
    lable.textColor=[UIColor darkGrayColor];
    lable.textAlignment=NSTextAlignmentCenter;
    [self.contentImageView addSubview:lable];
    
    _imageScrollView=[[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, 260, 180)];
    _imageScrollView.backgroundColor=[UIColor clearColor];
    _imageScrollView.center = CGPointMake(CGRectGetMidX(self.contentImageView.frame), 250);
    _imageScrollView.userInteractionEnabled = YES;
    _imageScrollView.delegate = self;
    _imageScrollView.pagingEnabled = YES;
    [self.contentImageView addSubview:_imageScrollView];
    
    
    
    _pageControl=[[UIPageControl alloc] initWithFrame:CGRectMake(0,0,100, 10)];
    _pageControl.center = CGPointMake(_imageScrollView.center.x, _imageScrollView.center.y + (CGRectGetHeight(_imageScrollView.frame)/2 + 60));
    _pageControl.userInteractionEnabled = NO;
    _pageControl.numberOfPages = 0;
    _pageControl.currentPageIndicatorTintColor = [UIColor orangeColor];
    [self.view addSubview:_pageControl];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) takePhotoClick:(UIButton *) btn
{
    HECheckPhotoView *checkView=[[HECheckPhotoView alloc] initWith:^(UIImage *ckeckedImage) {
        //[_photosArray count] * CGRectGetWidth(_imageScrollView.frame)
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake([_photosArray count] * CGRectGetWidth(_imageScrollView.frame), 0, CGRectGetWidth(_imageScrollView.frame), CGRectGetHeight(_imageScrollView.frame))];
        imageView.tag = [_photosArray count] + 100;
        imageView.userInteractionEnabled = YES;
        imageView.backgroundColor = [UIColor yellowColor];
        imageView.image = ckeckedImage;
        [_imageScrollView addSubview:imageView];
        
        UITapGestureRecognizer *tap=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(deletePhoto:)];
        [imageView addGestureRecognizer:tap];
        
        
        [_photosArray addObject:ckeckedImage];
        _pageControl.numberOfPages = [_photosArray count];
        _pageControl.currentPage = [_photosArray count];
        
        [_imageScrollView setContentOffset:CGPointMake([_photosArray count] * CGRectGetWidth(_imageScrollView.frame), 0)];
        [_imageScrollView setContentSize:CGSizeMake(CGRectGetWidth(_imageScrollView.frame) * [_photosArray count], CGRectGetHeight(_imageScrollView.frame))];
    }];
    [AlertCustom showWithView:checkView];
    
}
-(void)rightButtonClick:(UIButton *)btn
{

    if (![_photosArray count] == 0)
    {
        HEHomePostStepTwoViewController *stepTwo = [[HEHomePostStepTwoViewController alloc] initWithPhotos:_photosArray];
        [self.navigationController pushViewController:stepTwo animated:YES];
    }
    else
    {
        BH_ALERT(@"您还没有选择图片");
    }
}
-(NSString *)navBarTitle
{
    return @"Step1";
}

-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    _pageControl.currentPage = scrollView.contentOffset.x / CGRectGetWidth(scrollView.frame);
}

-(void) deletePhoto:(UIGestureRecognizer *) ges
{
    
    HECheckPhotoView *check=[[HECheckPhotoView alloc] initWithDelete:^{
        UIImageView *imageView = (UIImageView *)[ges view];
        [_photosArray removeObjectAtIndex:imageView.tag - 100];
        [imageView removeFromSuperview];
        _imageScrollView.contentSize = CGSizeMake(CGRectGetWidth(_imageScrollView.frame) * [_photosArray count], CGRectGetHeight(_imageScrollView.frame));
        _pageControl.numberOfPages = [_photosArray count];
    }];
    [AlertCustom showWithView:check];
}

@end
