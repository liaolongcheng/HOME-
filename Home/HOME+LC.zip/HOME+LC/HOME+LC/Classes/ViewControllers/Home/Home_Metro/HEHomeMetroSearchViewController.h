//
//  HEHomeMetroSearchViewController.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-27.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEHomeNearbyViewController.h"

@interface HEHomeMetroSearchViewController : HEHomeNearbyViewController

-(instancetype) initWithMetroId:(NSString *)metroId;

@end
