//
//  HEHomeMetroSearchViewController.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-27.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEHomeMetroSearchViewController.h"
#import "HEHTTPSearchHouse.h"

@interface HEHomeMetroSearchViewController ()
{
    NSString *_metro;
}

@end

@implementation HEHomeMetroSearchViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    HEHTTPSearchHouse *_search=[HEHTTPSearchHouse sharedHouse];
    _search.metro=_metro;
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}
-(SearchConditionType)searchConditionType
{
    return SearchConditionTypeWithMetro;
}
-(instancetype)initWithMetroId:(NSString *)metroId
{
    self=[super init];
    if (self) {
        _metro=metroId;
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
