//
//  HEHomeNearbyListViewController.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-17.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

typedef NS_ENUM(NSInteger, ListSearchType)
{
    ListSearchWithTime=0,
    ListSearchWithPrice=1,
    ListSearchWithRoom=2,
    ListSearchWithStar=3
};


#import "CABaseRefreshViewController.h"
#import "HESegmentControllExpand.h"
#import "HEHTTPSearchHouse.h"

@interface HEHomeNearbyListViewController : CABaseRefreshViewController

@property (nonatomic,strong) UIViewController *superViewController;

-(void) listUpatateSearchWithType:(ListSearchType)searchType searchCondition:(SearchConditionType)searchCondition segExpand:(HESegmentControllExpand *)segExpand;



@end
