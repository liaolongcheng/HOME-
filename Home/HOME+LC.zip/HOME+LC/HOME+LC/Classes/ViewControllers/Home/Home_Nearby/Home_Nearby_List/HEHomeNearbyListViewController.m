//
//  HEHomeNearbyListViewController.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-17.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEHomeNearbyListViewController.h"
#import "HEFavouriteHouseCell.h"
#import "HEHTTPSearchHouse.h"
#import "HEHomeHouseDetailViewController.h"
#import "AreaAndLinesUtily.h"


@interface HEHomeNearbyListViewController ()
{
    HEHTTPSearchHouse *_search;
    NSMutableArray *_sourceArray;
    SearchConditionType _searchType;
}

@end

@implementation HEHomeNearbyListViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    _sourceArray=[[NSMutableArray alloc] init];
    _search=[HEHTTPSearchHouse sharedHouse];
    _search.page=0;
    [self publicSearch:SVProgressHUDMaskTypeClear isMore:NO];
}

-(void) publicSearch:(SVProgressHUDMaskType) svtype isMore:(BOOL) isMore
{
    //537a1984f78aa76948421a8d
    [_search searchWithNorMal:^(NSMutableArray *responesArray) {
       
        if ([responesArray count] == 0)
        {
            TOST_SHOW(@"I'm sorry there is no more data");
            [self endRefresh];
            return ;
        }
        
        if (isMore)
        {
            [_sourceArray addObjectsFromArray:responesArray];
           
        }
        else
        {
            [_sourceArray removeAllObjects];
            [_sourceArray addObjectsFromArray:responesArray];
            if ([_sourceArray count] < 10)
            {
                self.tableView.refreshTableFooterView.hidden = YES;
            }
            else
            {
                self.tableView.refreshTableFooterView.hidden = NO;
            }
        }
        [self.tableView reloadData];
        [self endRefresh];
    } svType:svtype];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(BOOL)usesRefreshHeaderView
{
    return YES;
}
-(BOOL)usesRefreshFooterView
{
    return YES;
}
-(BOOL)usesAutoRefresh
{
    return NO;
}
-(void)listUpatateSearchWithType:(ListSearchType)searchType searchCondition:(SearchConditionType)searchCondition segExpand:(HESegmentControllExpand *)segExpand
{
    [_search clearUrl];
    _search.page=0;
   // _search.orderBy = ORDER_BY_PUBLISH_TIME_DESC;
    _search.searchType=searchCondition;
   
    switch (searchType)
    {
        case ListSearchWithTime:
        {
            if (segExpand.selctTime)
            {
                _search.orderBy=ORDER_BY_PUBLISH_TIME;
            }
            else
            {
                _search.orderBy=ORDER_BY_PUBLISH_TIME_DESC;
            }
            [self publicSearch:SVProgressHUDMaskTypeClear isMore:NO];
        }
        break;
        case ListSearchWithPrice:
        {
            _search.price=segExpand.selectPrice;
            [self publicSearch:SVProgressHUDMaskTypeClear isMore:NO];
        }
        break;
        case ListSearchWithRoom:
        {
            _search.bedrooms=segExpand.selectRoom;
            [self publicSearch:SVProgressHUDMaskTypeClear isMore:NO];
        }
        break;
        case ListSearchWithStar:
        {
            if(segExpand.selectStar)
            {
                _search.orderBy=ORDER_BY_STAR_DESC;
            }
            else
            {
                _search.orderBy=ORDER_BY_STAR;
            }
            [self publicSearch:SVProgressHUDMaskTypeClear isMore:YES];
        }
        break;
    }
}
-(void)didStartLoadingMoreObjects
{
    _search.page += 1;
      [self publicSearch:SVProgressHUDMaskTypeNil isMore:YES];
}

-(void)didStartLoadingNewObjects
{
    _search.page = 0;
    [self publicSearch:SVProgressHUDMaskTypeNil isMore:NO];
   
}
-(void) endRefresh
{
    [super didEndLoadingNewObjects];
    [super didEndLoadingMoreObjects];
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [_sourceArray count];
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *str=@"Cell";
    HEFavouriteHouseCell *cell=[tableView dequeueReusableCellWithIdentifier:str];
    if (!cell)
    {
        cell = [[NSBundle mainBundle] loadNibNamed:@"HEFavouriteHouseCell" owner:nil options:nil][0];
        cell.frame = CGRectMake(0, 0, 313, 0);
    }
   
    NSDictionary *house=_sourceArray[indexPath.row];
   
    cell.titleLable.text=house[@"name_en"];
    cell.timeLable.text=[NSString formatterTimeWithString:house[@"publishDate"]];
    cell.priceLable.text=[NSString stringWithFormat:@"%@ RMB",house[@"price"]];
    cell.roomLable.text = [NSString stringWithFormat:@"%@ bedroom",house[@"bedrooms"]];
    if ([house[@"metro"] count] >= 1)
    {
        NSString *lineInfoStr = [[AreaAndLinesUtily sharedAreaLines] enNameWithMetroId:house[@"metro"][0]];
        cell.lineLable.text = [lineInfoStr substringToIndex:[lineInfoStr rangeOfString:@" "].location + 2];
    }
    else
    {
        cell.lineLable.text = @"";
    }
    if ([house[@"area"] count] >= 1)
    {
        NSString *addInfoStr = [[AreaAndLinesUtily sharedAreaLines] enNameWithAreaId:house[@"area"][0]];
        cell.addressLable.text = [addInfoStr substringToIndex:[addInfoStr rangeOfString:@" "].location + 2];
    }
    else
    {
        cell.addressLable.text =@"";
    }
    
    [cell.houseImageView setImageWithURL:IMAGEURLCREATE(house[@"picture"]) placeholderImage:DEFAULTIMAGE];
   
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 231;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
//    HEHomeHouseDetailViewController *detail=[HEHomeHouseDetailViewController sharedHouseDetail];
//    detail.houseId=_sourceArray[indexPath.row][@"_id"];
//    [detail releadeHouseInfo];
//    [self.superViewController.navigationController pushViewController:detail animated:YES];
    HEHomeHouseDetailViewController *detail=[[HEHomeHouseDetailViewController alloc] initWithHouseId:_sourceArray[indexPath.row][@"_id"]];
    [detail releadeHouseInfo];
    [self.superViewController.navigationController pushViewController:detail animated:YES];
}



@end
