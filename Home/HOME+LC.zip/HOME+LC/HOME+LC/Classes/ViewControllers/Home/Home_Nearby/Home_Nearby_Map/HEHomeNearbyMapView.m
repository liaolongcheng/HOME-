//
//  HEHomeNearbyMapView.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-18.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEHomeNearbyMapView.h"

@implementation HEHomeNearbyMapView
{
    BMKLocationService *_locationService;
    BMKMapView *_mapView;
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}
-(void)willMoveToSuperview:(UIView *)newSuperview
{
    _locationService = [[BMKLocationService alloc] init];
    _locationService.delegate = self;
    [_locationService startUserLocationService];
    _mapView = [[BMKMapView alloc] initWithFrame:self.bounds];
    _mapView.showsUserLocation = YES;
    _mapView.zoomLevel = 14;
    _mapView.layer.masksToBounds = YES;
    _mapView.layer.cornerRadius = 4.0f;
    [self addSubview:_mapView];
    [_mapView viewWillAppear];
    _mapView.delegate = self;
    
}
-(void)removeFromSuperview
{
    _locationService.delegate = nil;
    [_mapView viewWillDisappear];
    _mapView.delegate = nil;
}
-(void)didUpdateUserLocation:(BMKUserLocation *)userLocation
{
    [_mapView updateLocationData:userLocation];
    [_mapView setCenterCoordinate:userLocation.location.coordinate animated:YES];
    [_locationService stopUserLocationService];
}
@end

