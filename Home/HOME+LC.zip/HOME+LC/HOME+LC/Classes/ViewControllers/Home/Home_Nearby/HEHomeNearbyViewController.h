//
//  HEHomeNearbyViewController.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-17.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEPublicListMapViewController.h"
#import "HEHomeNearbyListViewController.h"
#import "HEHomeNearbyMapView.h"

@interface HEHomeNearbyViewController : HEPublicListMapViewController

@property (nonatomic,strong) HEHomeNearbyListViewController *homeNearbyList;
@property (nonatomic,strong) HEHomeNearbyMapView *homeNearMap;

-(SearchConditionType) searchConditionType;

-(BOOL) isCreateListView;
-(BOOL) isCreateMapView;

@end
