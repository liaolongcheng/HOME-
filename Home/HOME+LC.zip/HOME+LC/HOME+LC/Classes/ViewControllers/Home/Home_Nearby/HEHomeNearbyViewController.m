//
//  HEHomeNearbyViewController.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-17.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEHomeNearbyViewController.h"
#import "HEHTTPSearchHouse.h"


@interface HEHomeNearbyViewController ()
{
   
}

@end

@implementation HEHomeNearbyViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    HEHTTPSearchHouse *_search=[HEHTTPSearchHouse sharedHouse];
    _search.orderBy=ORDER_BY_PUBLISH_TIME_DESC;
    
    if ([self isCreateListView])
    {
        _homeNearbyList=[[HEHomeNearbyListViewController alloc] init];
        _homeNearbyList.view.frame=CGRectMake(1, self.segExpand.frame.origin.x+self.segExpand.frame.size.height+8, CGRectGetWidth(self.contentImageView.frame)-2, CGRectGetHeight(self.contentImageView.frame)-(self.segExpand.frame.origin.x+self.segExpand.frame.size.height+8));
        _homeNearbyList.tableView.backgroundColor=[UIColor clearColor];
        _homeNearbyList.superViewController=self;
        [self.contentImageView insertSubview:_homeNearbyList.view atIndex:0];
    }
    if ([self isCreateMapView])
    {
        _homeNearMap = [[HEHomeNearbyMapView alloc] init];
        _homeNearMap.frame = self.contentImageView.bounds;
        [self.contentImageView addSubview:_homeNearMap];
    }
    
   
    //List Map 切换
    [self.segControll createSegmentControlWithSegType:SegmentControlTitleIconAndBackGround selectedBlock:^(NSInteger selectIndex, UIView *selectView) {
        
        if (selectIndex == 0)
        {
            _homeNearbyList.view.hidden=NO;
            _homeNearMap.hidden=YES;
            [_homeNearMap removeFromSuperview];
            
            if (_homeNearbyList == nil)
            {
                _homeNearbyList=[[HEHomeNearbyListViewController alloc] init];
                _homeNearbyList.view.frame=CGRectMake(1, self.segExpand.frame.origin.x+self.segExpand.frame.size.height+8, CGRectGetWidth(self.contentImageView.frame)-2, CGRectGetHeight(self.contentImageView.frame)-(self.segExpand.frame.origin.x+self.segExpand.frame.size.height+8));
                _homeNearbyList.tableView.backgroundColor=[UIColor clearColor];
                _homeNearbyList.superViewController=self;
                [self.contentImageView insertSubview:_homeNearbyList.view atIndex:0];
            }
            
        }
        if (selectIndex == 1)
        {
            if (_homeNearMap == nil)
            {
                _homeNearMap = [[HEHomeNearbyMapView alloc] init];
                _homeNearMap.frame = self.contentImageView.bounds;
                [self.contentImageView addSubview:_homeNearMap];
            }
            _homeNearMap.hidden=NO;
            _homeNearbyList.view.hidden=YES;
        }
        
    }];
    [self.segControll selectAtIndex:0];
    
    //搜索切换
    [self.segExpand createSegmentExpand:^(HESegmentControllExpand *segExpand, NSInteger index, UIView *currentView) {
  
        switch (index)
        {
            case 0:
            {
                //[_homeNearbyList listUpatateSearchWithType:ListSearchWithTime segExpand:segExpand];
                [_homeNearbyList listUpatateSearchWithType:ListSearchWithTime searchCondition:[self searchConditionType] segExpand:segExpand];
            }
            break;
            case 1:
            {
                //[_homeNearbyList listUpatateSearchWithType:ListSearchWithPrice segExpand:segExpand];
                [_homeNearbyList listUpatateSearchWithType:ListSearchWithPrice searchCondition:[self searchConditionType] segExpand:segExpand];
            }
            break;
            case 2:
            {
                //[_homeNearbyList listUpatateSearchWithType:ListSearchWithRoom segExpand:segExpand];
                 [_homeNearbyList listUpatateSearchWithType:ListSearchWithRoom searchCondition:[self searchConditionType] segExpand:segExpand];
            }
            break;
            case 3:
            {
                 //[_homeNearbyList listUpatateSearchWithType:ListSearchWithStar segExpand:segExpand];
                 [_homeNearbyList listUpatateSearchWithType:ListSearchWithStar searchCondition:[self searchConditionType] segExpand:segExpand];
            }
            break;
        }
    }];
    
    
}

-(BOOL)isCreateListView
{
    return YES;
}
-(BOOL)isCreateMapView
{
    return NO;
}
-(SearchConditionType) searchConditionType
{
    return SearchConditionTypeWithNormal;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
