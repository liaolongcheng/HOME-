//
//  HEHomeMapViewController.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-18.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEHomeMapViewController.h"

@interface HEHomeMapViewController ()
{
    NSInteger _mapType;
    BMKLocationService *_locationServer;
    LongTapBlock _longTapBlock;
    BMKGeoCodeSearch *_geoSearch;
}

@end

@implementation HEHomeMapViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(instancetype)initWithLongTapMapBlock:(LongTapBlock)tapBlock
{
    self = [super init];
    if (self)
    {
        _mapType = 1;
        _longTapBlock = tapBlock;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.contentImageView.hidden = YES;
    _mapView = [[BMKMapView alloc] initWithFrame:self.contentImageView.frame];
    _mapView.zoomLevel = 14;
    _mapView.layer.masksToBounds = YES;
    _mapView.layer.cornerRadius = 3;
    [_mapView setShowsUserLocation:YES];
    [self.view addSubview:_mapView];
    if (_mapType == 1)
    {
        _mapView.frame = CGRectMake(_mapView.frame.origin.x, self.contentImageView.frame.origin.y + 30, _mapView.frame.size.width, _mapView.frame.size.height - 30);
        UILabel *lable = [[UILabel alloc] initWithFrame:CGRectMake(self.contentImageView.frame.origin.x, self.contentImageView.frame.origin.y, self.contentImageView.frame.size.width, 30)];
        lable.textColor = [UIColor lightGrayColor];
        lable.text = @"plsease long press the map to locte";
        [self.view addSubview:lable];
    }
    
    _locationServer = [[BMKLocationService alloc] init];
    [_locationServer startUserLocationService];
    _mapView.showsUserLocation = YES;
    _geoSearch = [[BMKGeoCodeSearch alloc] init];
}
-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [_mapView viewWillAppear];
    _mapView.delegate = self; // 此处记得不用的时候需要置nil，否则影响内存的释放
    _locationServer.delegate = self;
    _geoSearch.delegate  = self;
}

-(void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [_mapView viewWillDisappear];
    _mapView.delegate = nil; // 不用时，置nil
    _locationServer.delegate = nil;
    _geoSearch.delegate = nil;
}
/**
 *在地图View将要启动定位时，会调用此函数
 *@param mapView 地图View
 */
- (void)willStartLocatingUser
{
    
}

/**
 *用户方向更新后，会调用此函数
 *@param userLocation 新的用户位置
 */
- (void)didUpdateUserHeading:(BMKUserLocation *)userLocation
{
    
}

/**
 *用户位置更新后，会调用此函数
 *@param userLocation 新的用户位置
 */
- (void)didUpdateUserLocation:(BMKUserLocation *)userLocation
{
    [_mapView updateLocationData:userLocation];
    [_mapView setCenterCoordinate:userLocation.location.coordinate animated:YES];
    [_locationServer stopUserLocationService];
}

/**
 *在地图View停止定位后，会调用此函数
 *@param mapView 地图View
 */
- (void)didStopLocatingUser
{
    DLog(@"stop locate");
}

/**
 *定位失败后，会调用此函数
 *@param mapView 地图View
 *@param error 错误号，参考CLError.h中定义的错误号
 */
- (void)didFailToLocateUserWithError:(NSError *)error
{
    //CLError
    DLog(@"location error:%@",error);
}
- (void)mapview:(BMKMapView *)mapView onLongClick:(CLLocationCoordinate2D)coordinate
{
    if (_mapType == 1)
    {
        BMKReverseGeoCodeOption *reversGeo = [[BMKReverseGeoCodeOption alloc] init];
        reversGeo.reverseGeoPoint = coordinate;
        [_geoSearch reverseGeoCode:reversGeo];
    }
}

/**
 *返回反地理编码搜索结果
 *@param searcher 搜索对象
 *@param result 搜索结果
 *@param error 错误号，@see BMKSearchErrorCode
 */
- (void)onGetReverseGeoCodeResult:(BMKGeoCodeSearch *)searcher result:(BMKReverseGeoCodeResult *)result errorCode:(BMKSearchErrorCode)error
{
    NSString *strURL = [NSString stringWithFormat:@"http://fanyi.youdao.com/openapi.do?keyfrom=adsfasd&key=1134200580&type=data&doctype=json&version=1.1&q=%@",[result.address urlEncodedString]];
    [HttpHelper GET:strURL parameters:nil svText:@"loding..." errorsvText:@"load Error..." svMarkType:SVProgressHUDMaskTypeClear success:^(AFHTTPRequestOperation *operation, id responseObject) {
        if (_longTapBlock)
        {
            _longTapBlock([NSString stringWithFormat:@"%f",result.location.longitude],[NSString stringWithFormat:@"%f",result.location.latitude],responseObject[@"translation"][0]);
        }
        [self.navigationController popViewControllerAnimated:YES];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"加载出错");
    }];

}


-(NSString *)navBarTitle
{
    return @"Map";
}

-(BOOL)isCreateSegmenetControllExpand
{
    return NO;
}
@end
