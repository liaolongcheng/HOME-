//
//  HEHomeViewController.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-15.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEHomeViewController.h"
#import "HEPublicListMapViewController.h"
#import "HEHomeNearbyViewController.h"
#import "HEHomeHotspotViewController.h"
#import "HEHomeMetroViewController.h"
#import "HEHomeNewlyViewController.h"
#import "HEHomeMapViewController.h"
#import "HEHomePostStepOneViewController.h"
#import "HELoginViewController.h"
#import "HEUserRegister.h"
#import "HEUserLogin.h"



@interface HEHomeViewController ()

@end

@implementation HEHomeViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}


-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self showTabBar];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    RESIGNFIRSTRESPONDER;
}

- (IBAction)NearbyClick:(id)sender
{
    [self hiddenTabBar];
    HEHomeNearbyViewController *homeNearby = [[HEHomeNearbyViewController alloc] init];
    [self.navigationController pushViewController:homeNearby animated:YES];
}

- (IBAction)HostspotClick:(id)sender
{
    [self hiddenTabBar];
    HEHomeHotspotViewController *homeHotspot=[[HEHomeHotspotViewController alloc] initWithNibName:@"HEPublicLinkageTableViewController" bundle:nil];
    [self.navigationController pushViewController:homeHotspot animated:YES];
}

- (IBAction)MetroClick:(id)sender
{
    [self hiddenTabBar];
    HEHomeMetroViewController *homeHotspot=[[HEHomeMetroViewController alloc] initWithNibName:@"HEPublicLinkageTableViewController" bundle:nil];
    [self.navigationController pushViewController:homeHotspot animated:YES];
}

- (IBAction)NewlyClick:(id)sender
{
    [self hiddenTabBar];
    HEHomeNewlyViewController *homeNewly=[[HEHomeNewlyViewController alloc] init];
    [self.navigationController pushViewController:homeNewly animated:YES];
}

- (IBAction)MapClick:(id)sender
{
    [self hiddenTabBar];
    HEHomeMapViewController *homeMap=[[HEHomeMapViewController alloc] init];
    [self.navigationController pushViewController:homeMap animated:YES];
}

- (IBAction)PostClick:(id)sender
{
    [self hiddenTabBar];
    
    HEUserLogin *loginObj=[HEUserLogin sharedLogin];
    if (loginObj.access_token)
    {
        HEHomePostStepOneViewController *homePost=[[HEHomePostStepOneViewController alloc] init];
        [self.navigationController pushViewController:homePost animated:YES];

    }
    else
    {
        HELoginViewController *login=[[HELoginViewController alloc] init];
        [self.navigationController pushViewController:login animated:YES];
    }
}
@end
