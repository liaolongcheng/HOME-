//
//  HERegisterViewController.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-25.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEPublicBaseViewController.h"

@interface HERegisterViewController : HEPublicBaseViewController<UITableViewDataSource,UITableViewDelegate>
@property (strong, nonatomic) IBOutlet UITableView *registerMainTableView;
@property (assign, nonatomic) NSInteger defaultHeight;


@end
