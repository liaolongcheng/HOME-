//
//  HERegisterViewController.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-25.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HERegisterViewController.h"
#import "HERegisterContentCell.h"
#import "HERegisterPhotoCell.h"
#import "HEUserRegister.h"

@interface HERegisterViewController ()
{
    HERegisterPhotoCell *photoCell;
}

@end

@implementation HERegisterViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
    //69
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.contentImageView.hidden = YES;
    
//    if ([[HEUserLogin sharedLogin].type isEqualToString:@"seller"] && USER_ISLOGIN)
//    {
//        self.defaultHeight=500;
//    }
//    else
//    {
//        
//        self.defaultHeight=430;
//    }
    self.defaultHeight = 430;
    
    self.registerMainTableView.backgroundColor=[UIColor clearColor];
    self.registerMainTableView.dataSource=self;
    self.registerMainTableView.delegate=self;
    self.registerMainTableView.separatorStyle=UITableViewCellSeparatorStyleNone;
    
    HEUserRegister *registe = [HEUserRegister sharedRegister];
    registe.name = nil;
    registe.phone = nil;
    registe.pass = nil;
    registe.company = nil;
    registe.address = nil;
    registe.profile_image = nil;
    registe.email = nil;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0)
    {
        if (photoCell == nil)
        {
            photoCell = LOAD_TABLEVIEWCELL(@"HERegisterPhotoCell");
        }
        
        
//        static HERegisterPhotoCell *photoCell = nil;
//        static dispatch_once_t onceToken;
//        dispatch_once(&onceToken, ^{
//            photoCell = LOAD_TABLEVIEWCELL(@"HERegisterPhotoCell");
//            photoCell.registerViewController=self;
//        });
        
        return photoCell;
    }
    else if(indexPath.section == 1)
    {
        HERegisterContentCell *contentCell = LOAD_TABLEVIEWCELL(@"HERegisterContentCell");
        
        if (self.defaultHeight == 500)
        {
            contentCell.agencyView.hidden=NO;
            [contentCell.privateButton setUserInteractionEnabled:YES];
            [contentCell.privateButton setSelected:NO];
            [contentCell.AgencyButton setUserInteractionEnabled:NO];
            [contentCell.AgencyButton setSelected:YES];
        }
        else
        {
            contentCell.agencyView.hidden=YES;
            [contentCell.privateButton setUserInteractionEnabled:NO];
            [contentCell.privateButton setSelected:YES];
            [contentCell.AgencyButton setUserInteractionEnabled:YES];
            [contentCell.AgencyButton setSelected:NO];
        }
        contentCell.registerViewController=self;
        return contentCell;
    }
    return nil;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section == 0)
    {
        return 50;
    }
    else if(indexPath.section == 1)
    {
        return self.defaultHeight;
    }
    return 0;
}
-(NSString *)navBarTitle
{
    return @"Register";
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
