//
//  HELoginViewController.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-25.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HELoginViewController.h"
#import "HERegisterViewController.h"
#import "HEUserLogin.h"
#import "HEHomePostStepOneViewController.h"

@interface HELoginViewController ()

@end

@implementation HELoginViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.contentImageView.frame=CGRectMake(self.contentImageView.frame.origin.x, self.contentImageView.frame.origin.y, CGRectGetWidth(self.contentImageView.frame), 200);
  
    self.registerLable.shouldUnderline=YES;
    [self.registerLable addTarget:self action:@selector(resgisterLableClick:)];
    
}
-(void) resgisterLableClick:(UILabel *)lable
{
    HERegisterViewController *registerViewController = [[HERegisterViewController alloc] init];
    [self.navigationController pushViewController:registerViewController animated:YES];
    
}
-(NSString *)navBarTitle
{
    return @"Login";
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)cancelClick:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)loginClick:(id)sender
{
    if (IS_KONG_STRING(self.telephoneText.text))
    {
        BH_ALERT(@"Please fill in the phone");
        return;
    }
    else if (IS_KONG_STRING(self.pwdText.text))
    {
        BH_ALERT(@"Please fill in the password");
        return;
    }
    HEUserLogin *login=[HEUserLogin sharedLogin];
    login.phone=self.telephoneText.text;
    login.passWord=self.pwdText.text;
    [login login:^{
        
        [self.navigationController popViewControllerAnimated:YES];
        
    } :^{
        [self.navigationController popViewControllerAnimated:YES];
        
    }];
}
@end
