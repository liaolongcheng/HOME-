//
//  HELoginViewController.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-25.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEPublicBaseViewController.h"
#import "HEUnderLineLable.h"

@interface HELoginViewController : HEPublicBaseViewController
@property (strong, nonatomic) IBOutlet HEUnderLineLable *registerLable;
@property (strong, nonatomic) IBOutlet UITextField *telephoneText;
@property (strong, nonatomic) IBOutlet UITextField *pwdText;
- (IBAction)cancelClick:(id)sender;
- (IBAction)loginClick:(id)sender;

@end
