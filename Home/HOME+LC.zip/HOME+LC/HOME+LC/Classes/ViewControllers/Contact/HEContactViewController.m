//
//  HEContactViewController.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-15.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEContactViewController.h"
#import "HESegmentControl.h"
#import "HEContactHouseViewController.h"
#import "HeContactDiningViewController.h"

@interface HEContactViewController ()
{
    HEContactHouseViewController *contactHouse;
    HeContactDiningViewController *contactDining;
    HESegmentControl *seg;
}

@end

@implementation HEContactViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self showTabBar];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    
    
    seg=[[HESegmentControl alloc] initWithFrame:CGRectMake(0, 0, 200, 30)];
    
    seg.center=self.navigationImageView.center;
    seg.NormalIcons=
    @[
      LOAD_IMAGE(@"btn_radio_left.png"),
      LOAD_IMAGE(@"btn_radio_right.png")
      ];
    seg.SelectIcons=
    @[
      LOAD_IMAGE(@"btn_radio_left_selected.png"),
      LOAD_IMAGE(@"btn_radio_right_selected.png")
      ];
    seg.titleNormalIcons=
    @[
      LOAD_IMAGE(@"title_house.png"),
      LOAD_IMAGE(@"title_restaurant.png")
      ];
    seg.titleSelectedIcons=
    @[
      LOAD_IMAGE(@"title_house_selected.png"),
      LOAD_IMAGE(@"title_restaurant_selected.png")
      ];
    
    
    [seg createSegmentControlWithSegType:SegmentControlTitleIconAndBackGround selectedBlock:^(NSInteger selectIndex, UIView *selectView) {
        [_mainScrollView setContentOffset:CGPointMake(selectIndex * CGRectGetWidth(_mainScrollView.frame), 0) animated:YES];
    }];
    seg.isDoubleClcik=YES;
    seg.tag=10;
    [seg selectAtIndex:0];
    seg.backgroundColor=[UIColor clearColor];
    [self.view addSubview:seg];
    
    UIImage *image = LOAD_IMAGE(@"background2.png");
    UIImage *tempImage = IMAGE_STRRTCHABLE(image, 20, 20);
    self.contentView.image=tempImage;
    
    _mainScrollView.contentSize=CGSizeMake(CGRectGetWidth(_mainScrollView.frame)*2, CGRectGetHeight(_mainScrollView.frame));
    _mainScrollView.pagingEnabled=YES;
    _mainScrollView.showsVerticalScrollIndicator=NO;
    _mainScrollView.delegate=self;
    

    contactHouse = [[HEContactHouseViewController alloc] init];
    contactHouse.view.frame=_mainScrollView.bounds;
    contactHouse.tableView.backgroundColor=[UIColor clearColor];
    contactHouse.viewController=self;
    [_mainScrollView addSubview:contactHouse.view];
    
    contactDining = [[HeContactDiningViewController alloc] init];
    contactDining.view.frame=CGRectMake(CGRectGetWidth(_mainScrollView.frame), 0, CGRectGetWidth(_mainScrollView.frame), CGRectGetHeight(_mainScrollView.frame));
    contactDining.tableView.backgroundColor=[UIColor clearColor];
    [_mainScrollView addSubview:contactDining.view];
    
}
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    [seg selectAtIndex:scrollView.contentOffset.x/CGRectGetWidth(scrollView.frame)];
}
-(UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    RESIGNFIRSTRESPONDER;
}

@end
