//
//  HEContactViewController.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-15.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HEBaseViewController.h"

@interface HEContactViewController : HEBaseViewController<UIScrollViewDelegate>
@property (strong, nonatomic) IBOutlet UIScrollView *mainScrollView;
@property (strong, nonatomic) IBOutlet UIImageView *contentView;

@end
