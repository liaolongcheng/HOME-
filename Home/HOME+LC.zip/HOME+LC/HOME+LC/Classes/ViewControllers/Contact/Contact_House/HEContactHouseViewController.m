//
//  HEContactHouseViewController.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-16.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEContactHouseViewController.h"
#import "HEContactHouseCell.h"
#import "HEHouseInfo.h"
#import "HEHomeHouseDetailViewController.h"
#import "NSString+HETime.h"

@interface HEContactHouseViewController ()
{
    
    HEHouseInfo *_house;
}

@end

@implementation HEContactHouseViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}
-(void) publicRequest:(BOOL) isMore svType:(SVProgressHUDMaskType) svType
{
    _house=[[HEHouseInfo alloc] init];
    
    [_house requestAllContactHouseWith:^(id houseArray) {
        
        if (isMore)
        {
            [_sourceArray addObjectsFromArray:houseArray];
            [self.tableView reloadData];
           
        }
        else
        {
            [_sourceArray removeAllObjects];
            [_cellArray removeAllObjects];
            
            
            for (int i = 0; i < [houseArray count]; i++)
            {
                NSMutableDictionary *houseInfo = [houseArray[i] mutableCopy];
                [_sourceArray addObject:houseInfo];
                
                __weak HEContactHouseViewController *wealSelf = self;
         
                HEContactHouseCell *cell = [[HEContactHouseCell alloc] initWtihSendClick:^(NSIndexPath *indexPath, UITableViewCell *cell, UITableView *listTableView, NSInteger rate, NSString *content) {
                    
                    if (!USER_ISLOGIN)
                    {
                        BH_ALERT(@"You are not logged in.");
                        return ;
                    }
                    if (rate == 0)
                    {
                        BH_ALERT(@"Please mark first!");
                        return;
                    }
                    
                    NSDictionary *house=_sourceArray[indexPath.row];
                    HEHouseInfo *houseInfo=[[HEHouseInfo alloc] init];
                    houseInfo.publisherId = house[@"publisher"];
                    houseInfo.houseId = house[@"_id"];
                    houseInfo.score=rate;
                    houseInfo.content = content;
                    [houseInfo sendGreadToHouse:^(id houseInfo) {
                        [SVProgressHUD showSuccessWithStatus:@"Send success" duration:1.0];
                    } requestError:nil svType:SVProgressHUDMaskTypeClear];
                    
                } lableBlock:^(NSIndexPath *indexPath, UITableViewCell *cell, UITableView *listTableView) {
                   
                    HEHomeHouseDetailViewController *houseDetail = [HEHomeHouseDetailViewController sharedHouseDetail];
                    houseDetail.houseId=_sourceArray[indexPath.row][@"_id"];
                    [houseDetail releadeHouseInfo];
                    if ([self.viewController.navigationController.viewControllers containsObject:houseDetail]) {
                        [wealSelf.viewController.navigationController popToViewController:houseDetail animated:YES];
                    }
                    else
                    {
                        [wealSelf.viewController.navigationController pushViewController:houseDetail animated:YES];
                    }

                }];
                cell.indexPath = [NSIndexPath indexPathForRow:i inSection:0];
                [_cellArray addObject:cell];
            }
            
//            for (int i=0; i < [_sourceArray count]; i++)
//            {
//                if ([[_sourceArray[i] allKeys] containsObject:@"expiredAt"])
//                {
//                    NSLog(@"YES---%@",_sourceArray[i][@"expiredAt"]);
//                }
//                else
//                {
//                    NSLog(@"NO");
//                }
//            }
            [self.tableView reloadData];
        }
        [self endRefresh];
        
    } requestError:^{
        [self endRefresh];
    } svType:svType];
}


- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    self.tableView.separatorStyle=UITableViewCellSeparatorStyleNone;
    _sourceArray=[[NSMutableArray alloc] init];
    _cellArray = [[NSMutableArray alloc] init];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeRate:) name:CHANGE_RATA object:nil];
  
    if (USER_ISLOGIN)
    {
        [self publicRequest:NO svType:SVProgressHUDMaskTypeClear];
    }
    else
    {
        BH_ALERT(@"You are not logged in.");
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(BOOL)usesAutoRefresh
{
    return NO;
}
-(BOOL)usesRefreshFooterView
{
    return NO;
}
-(void)didStartLoadingNewObjects
{
    [self publicRequest:NO svType:SVProgressHUDMaskTypeNil];
}
-(void) endRefresh
{
    [super didEndLoadingMoreObjects];
    [super didEndLoadingNewObjects];;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [_sourceArray count];
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{

    HEContactHouseCell *cell = _cellArray[indexPath.row];
    cell.gradeView = self.view;
    NSDictionary *house=_sourceArray[indexPath.row];
    cell.titleLable.text=house[@"name_en"];
    cell.starView.rate=[house[@"score"] floatValue];
      
    if ([[_sourceArray[indexPath.row] allKeys] containsObject:@"expiredAt"] && [NSString expiredWithDateString:_sourceArray[indexPath.row][@"expiredAt"]])
    {
        
        cell.contentTextView.hidden = YES;
        cell.sendButton.hidden = YES;
        cell.expiredImageView.hidden = NO;
        cell.contentTextViewBackImageView.hidden = YES;
            
        
    }
    else
    {
        cell.contentTextView.hidden = NO;
        cell.sendButton.hidden = NO;
        cell.expiredImageView.hidden = YES;
        cell.contentTextViewBackImageView.hidden = NO;
    }
 
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if ([[_sourceArray[indexPath.row] allKeys] containsObject:@"expiredAt"] && [NSString expiredWithDateString:_sourceArray[indexPath.row][@"expiredAt"]])
    {
        return 93;
    }
    return 152;
}

#pragma mark -改变星星通知
-(void) changeRate:(NSNotification *) not
{
    NSNumber *num = [not object][@"num"];
    NSIndexPath *indexPath = [not object][@"indexPath"];
    self.sourceArray[indexPath.row][@"score"] = [NSString stringWithFormat:@"%@",num];
}

@end
