//
//  HEMoreMuCommentsSentViewController.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-6-17.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEMoreMuCommentsSentViewController.h"
#import "HEMoreMyCommentCell.h"
#import "HEAgentInfo.h"

@interface HEMoreMuCommentsSentViewController ()
{
    NSMutableArray *_sourceArray;
}

@end

@implementation HEMoreMuCommentsSentViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    self.tableView.backgroundColor = [UIColor clearColor];
    _sourceArray = [[NSMutableArray alloc] init];
    
    [self publicRequset:SVProgressHUDMaskTypeClear];
    
}

-(void) publicRequset:(SVProgressHUDMaskType)svType
{
    HEAgentInfo *agent = [[HEAgentInfo alloc] init];
    [agent requestAgentSentGread:^(id response) {
        if ([response count] == 0)
        {
            TOST_SHOW(@"I'm sorry there is no more data");
            [self endRefresh];
            return ;
        }
        [_sourceArray removeAllObjects];
        [_sourceArray addObjectsFromArray:response];
        [self.tableView reloadData];
        [self endRefresh];
    } errorBlock:^{
        [self endRefresh];
    } svType:svType];
    
    

    
}

-(BOOL)usesAutoRefresh
{
    return NO;
}
-(BOOL)usesRefreshHeaderView
{
    return YES;
}
-(BOOL)usesRefreshFooterView
{
    return NO;
}
-(void) endRefresh
{
    [self didEndLoadingNewObjects];
}

-(void)didStartLoadingNewObjects
{
    [self publicRequset:SVProgressHUDMaskTypeNil];
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [_sourceArray count];
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *str = @"Cell";
    HEMoreMyCommentCell *cell = [tableView dequeueReusableCellWithIdentifier:str];
    if (!cell)
    {
        cell = LOAD_TABLEVIEWCELL(@"HEMoreMyCommentCell");
        cell.targetLable.text = @"To:";
    }
    
    NSDictionary *gread = _sourceArray[indexPath.row];

    cell.starView.rate = [gread[@"score"] intValue];
    cell.nameLable.text = gread[@"from_name"];
    cell.contentText.text = gread[@"content"];
    cell.timeLable.text = @"just";
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}



@end
