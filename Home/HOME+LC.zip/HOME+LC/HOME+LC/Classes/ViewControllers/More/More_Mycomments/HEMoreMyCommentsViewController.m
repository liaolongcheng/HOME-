//
//  HEMoreMyCommentsViewController.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-6-17.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEMoreMyCommentsViewController.h"
#import "HESegmentControl.h"
#import "HEMoreCommentReceiveViewController.h"
#import "HEMoreMuCommentsSentViewController.h"

@interface HEMoreMyCommentsViewController ()
{
    HESegmentControl *seg;
    
    UIScrollView *_mainScrollView;
    HEMoreCommentReceiveViewController *_receiveViewController;
    HEMoreMuCommentsSentViewController *_sentViewController;
}

@end

@implementation HEMoreMyCommentsViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    self.contentImageView.frame=CGRectMake(self.contentImageView.frame.origin.x, self.contentImageView.frame.origin.y + 45, self.contentImageView.frame.size.width, self.contentImageView.frame.size.height - 45);
    
    seg=[[HESegmentControl alloc] initWithFrame:CGRectMake(0, 100, 200, 30)];
    
    seg.center=CGPointMake(320/2, NAVIGATIONBAR_HEIGHT + STATUSBAR_HEIGHT +30);
    seg.NormalIcons=
    @[
      LOAD_IMAGE(@"btn_radio_left.png"),
      LOAD_IMAGE(@"btn_radio_right.png")
      ];
    seg.SelectIcons=
    @[
      LOAD_IMAGE(@"btn_radio_left_selected.png"),
      LOAD_IMAGE(@"btn_radio_right_selected.png")
      ];
    seg.titleNormalIcons=
    @[
      LOAD_IMAGE(@"title_house.png"),
      LOAD_IMAGE(@"title_restaurant.png")
      ];
    seg.titleSelectedIcons=
    @[
      LOAD_IMAGE(@"title_house_selected.png"),
      LOAD_IMAGE(@"title_restaurant_selected.png")
      ];
    
    seg.isDoubleClcik=YES;
    seg.tag=10;
    
    seg.backgroundColor=[UIColor clearColor];
    [self.view addSubview:seg];
    
    _mainScrollView = [[UIScrollView alloc] init];
    _mainScrollView.frame=self.contentImageView.frame;
    _mainScrollView.contentSize=CGSizeMake(CGRectGetWidth(_mainScrollView.frame)*2, CGRectGetHeight(_mainScrollView.frame));
    _mainScrollView.pagingEnabled=YES;
    _mainScrollView.showsVerticalScrollIndicator=NO;
    _mainScrollView.delegate=self;
    [self.view addSubview:_mainScrollView];
    
    [seg createSegmentControlWithSegType:SegmentControlTitleIconAndBackGround selectedBlock:^(NSInteger selectIndex, UIView *selectView) {
        
        [_mainScrollView setContentOffset:CGPointMake(selectIndex * CGRectGetWidth(_mainScrollView.frame), 0) animated:YES];
    }];
    [seg selectAtIndex:0];
    
    _receiveViewController = [[HEMoreCommentReceiveViewController alloc] init];
    _receiveViewController.viewController=self;
    _receiveViewController.view.backgroundColor=[UIColor clearColor];
    _receiveViewController.view.frame=_mainScrollView.bounds;
    [_mainScrollView addSubview:_receiveViewController.view];
    
    _sentViewController = [[HEMoreMuCommentsSentViewController alloc] init];
    _sentViewController.viewController=self;
    _sentViewController.view.backgroundColor=[UIColor clearColor];
    _sentViewController.view.frame = CGRectMake(CGRectGetWidth(_mainScrollView.frame), 0, CGRectGetWidth(_mainScrollView.frame), CGRectGetHeight(_mainScrollView.frame));
    [_mainScrollView addSubview:_sentViewController.view];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    [seg selectAtIndex:scrollView.contentOffset.x/CGRectGetWidth(scrollView.frame)];
}

-(NSString *)navBarTitle
{
    return @"My Comments";
}

@end
