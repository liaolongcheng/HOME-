//
//  HEMoreMyCommentsViewController.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-6-17.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEPublicBaseViewController.h"

@interface HEMoreMyCommentsViewController : HEPublicBaseViewController<UIScrollViewDelegate>

@end
