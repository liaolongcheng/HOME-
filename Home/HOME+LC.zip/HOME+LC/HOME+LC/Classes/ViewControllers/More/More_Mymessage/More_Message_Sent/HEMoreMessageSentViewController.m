//
//  HEMoreMessageSentViewController.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-6-9.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEMoreMessageSentViewController.h"
#import "HEMessage.h"
#import "HEReceiveMessageCell.h"
#import "HEMoreMessageReplyViewController.h"

@interface HEMoreMessageSentViewController ()
{
    NSMutableArray *_sourceArray;
    NSMutableArray *_openArray;
}

@end

@implementation HEMoreMessageSentViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    _sourceArray = [[NSMutableArray alloc] init];
    _openArray = [[NSMutableArray alloc] init];
    self.tableView.backgroundColor=[UIColor clearColor];
    [self publicRequest:SVProgressHUDMaskTypeClear];
}

-(void) publicRequest:(SVProgressHUDMaskType)svType
{
    HEMessage *message=[[HEMessage alloc] init];
    [message requestSentMessage:^(id responesObject) {
        
        if ([responesObject count] == 0)
        {
            TOST_SHOW(@"I'm sorry there is no more data");
            [self endRefresh];
            return ;
        }
        
        [_sourceArray  removeAllObjects];
        [_sourceArray addObjectsFromArray:responesObject];
        
        [_openArray removeAllObjects];
        for(int i=0; i<[_sourceArray count]; i++)
        {
            [_openArray addObject:@(NO)];
        }
        [self.tableView reloadData];
        [self endRefresh];
        
    } error:^{
        [self endRefresh];
    }svType:svType];
}

-(BOOL)usesAutoRefresh
{
    return NO;
}
-(BOOL)usesRefreshFooterView
{
    return NO;
}
-(void)endRefresh
{
    [super didEndLoadingNewObjects];
}

-(void)didStartLoadingNewObjects
{
    [self publicRequest:SVProgressHUDMaskTypeNil];
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [_sourceArray count];
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *str=@"Cell";
    HEReceiveMessageCell *cell=[tableView dequeueReusableCellWithIdentifier:str];
    if (!cell)
    {
        __weak HEMoreMessageSentViewController *weakSelf = self;
        cell = [[HEReceiveMessageCell alloc] initWtihOpenClick:^(NSIndexPath *buttonIndexPath, UIButton *button, BOOL isOpen) {
            
            _openArray[buttonIndexPath.row] = @(isOpen);
            [tableView reloadRowsAtIndexPaths:@[buttonIndexPath] withRowAnimation:UITableViewRowAnimationFade];
            
        } delteButtonClick:^(NSIndexPath *buttonIndexPath, UIButton *button) {
            
            HEMessage *message=[[HEMessage alloc] init];
            message.messagesIds = _sourceArray[buttonIndexPath.row][@"_id"];
            [message deleteMessageToSent:^(id responesObject) {
                [_sourceArray removeObjectAtIndex:buttonIndexPath.row];
                [_openArray removeObjectAtIndex:buttonIndexPath.row];
                
                [weakSelf.tableView reloadData];
            } error:nil svType:SVProgressHUDMaskTypeClear];
            
        } replyButtonClick:^(NSIndexPath *ButtonIndexPath, UIButton *button) {
            
            HEMoreMessageReplyViewController *reply = [[HEMoreMessageReplyViewController alloc] initWithName:_sourceArray[ButtonIndexPath.row][@"to_name"] phone:_sourceArray[indexPath.row][@"to"]];
            [weakSelf.viewController.navigationController pushViewController:reply animated:YES];
            
        }];
    }
    if ([_openArray[indexPath.row] boolValue])
    {
        cell.deleteButton.hidden = NO;
        cell.replyButton.hidden = NO;
    }
    else
    {
        cell.deleteButton.hidden = YES;
        cell.replyButton.hidden = YES;
    }
    cell.closeButton.selected=[_openArray[indexPath.row] boolValue];
    cell.fromLable.text=_sourceArray[indexPath.row][@"to_name"];
    cell.targetLable.text = @"To:";
    /*有待提问*/
    cell.timeLable.text=@"just";
    cell.messageText.text=_sourceArray[indexPath.row][@"message"];
    return cell;

}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([_openArray[indexPath.row] boolValue])
    {
        return 140;
    }
    else
    {
        return 110;
    }
    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
