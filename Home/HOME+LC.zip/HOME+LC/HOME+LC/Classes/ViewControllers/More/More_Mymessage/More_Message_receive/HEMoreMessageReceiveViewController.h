//
//  HEMoreMessageReceiveViewController.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-6-9.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "CABaseRefreshViewController.h"

@interface HEMoreMessageReceiveViewController : CABaseRefreshViewController
@property (nonatomic,assign) UIViewController *viewController;


@end
