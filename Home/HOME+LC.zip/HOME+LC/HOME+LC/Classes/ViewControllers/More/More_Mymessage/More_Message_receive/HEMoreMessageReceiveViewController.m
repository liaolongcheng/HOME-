
//
//  HEMoreMessageReceiveViewController.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-6-9.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEMoreMessageReceiveViewController.h"
#import "HEReceiveMessageCell.h"
#import "HEMessage.h"
#pragma 回复消息
#import "HEMoreMessageReplyViewController.h"

@interface HEMoreMessageReceiveViewController ()
{
    NSMutableArray *_sourceArray;
    NSMutableArray *_openArray;
}

@end

@implementation HEMoreMessageReceiveViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    self.tableView.backgroundColor=[UIColor clearColor];
    
    _sourceArray = [[NSMutableArray alloc] init];
    
    _openArray = [[NSMutableArray alloc] init];

    [self publicRequest:SVProgressHUDMaskTypeClear];
    

}

-(void) publicRequest:(SVProgressHUDMaskType) svType
{
    HEMessage *message=[[HEMessage alloc] init];
    [message requestZanMessage:^(id responesObject) {
       
        if ([responesObject count] == 0)
        {
            TOST_SHOW(@"I'm sorry there is no more data");
            [self endRefresh];
            return ;
        }
        
        [_sourceArray  removeAllObjects];
        [_sourceArray addObjectsFromArray:responesObject];
        
        [_openArray removeAllObjects];
        for(int i=0; i<[_sourceArray count]; i++)
        {
            [_openArray addObject:@(NO)];
        }
        [self.tableView reloadData];
        [self endRefresh];
    } error:^{
        [self endRefresh];
    } svType:svType];
}

-(void) endRefresh
{
    [super didEndLoadingMoreObjects];
    [super didEndLoadingNewObjects];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [_sourceArray count];
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *str=@"Cell";
    HEReceiveMessageCell *cell=[tableView dequeueReusableCellWithIdentifier:str];
    if (!cell)
    {
       cell = [[HEReceiveMessageCell alloc] initWtihOpenClick:^(NSIndexPath *buttonIndexPath, UIButton *button, BOOL isOpen) {
    
           _openArray[buttonIndexPath.row] = @(isOpen);
           [tableView reloadRowsAtIndexPaths:@[buttonIndexPath] withRowAnimation:UITableViewRowAnimationFade];
           
       } delteButtonClick:^(NSIndexPath *buttonIndexPath, UIButton *button) {
           
           HEMessage *message=[[HEMessage alloc] init];
           message.messagesIds = _sourceArray[buttonIndexPath.row][@"_id"];
           [message deleteMessageFromReceived:^(id responesObject) {
               
               [_sourceArray removeObjectAtIndex:buttonIndexPath.row];
               [_openArray removeObjectAtIndex:buttonIndexPath.row];
               
               [self.tableView reloadData];
               
           } error:nil svType:SVProgressHUDMaskTypeClear];
           
       } replyButtonClick:^(NSIndexPath *ButtonIndexPath, UIButton *button) {
           
           HEMoreMessageReplyViewController *reply = [[HEMoreMessageReplyViewController alloc] initWithName:_sourceArray[ButtonIndexPath.row][@"from_name"] phone:_sourceArray[indexPath.row][@"from"]];
           [self.viewController.navigationController pushViewController:reply animated:YES];
           
       }];
       
    }
    if ([_openArray[indexPath.row] boolValue])
    {
        cell.deleteButton.hidden = NO;
        cell.replyButton.hidden = NO;
    }
    else
    {
        cell.deleteButton.hidden = YES;
        cell.replyButton.hidden = YES;
    }
    cell.closeButton.selected=[_openArray[indexPath.row] boolValue];
    cell.fromLable.text=_sourceArray[indexPath.row][@"from_name"];
    /*有待提问*/
    cell.timeLable.text=@"just";
    cell.messageText.text=_sourceArray[indexPath.row][@"message"];
    return cell;
}
//140 110

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([_openArray[indexPath.row] boolValue] == YES)
    {
        return 140;
    }
    else
    {
        return 110;
    }

}
-(void)didStartLoadingNewObjects
{
    [self publicRequest:SVProgressHUDMaskTypeNil];
}

-(BOOL)usesAutoRefresh
{
    return NO;
}
-(BOOL)usesRefreshHeaderView
{
    return YES;
}
-(BOOL)usesRefreshFooterView
{
    return NO;
}

@end
