//
//  HEMoreMyPostUpdateViewController.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-6-11.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEPublicBaseViewController.h"

@interface HEMoreMyPostUpdateViewController : HEPublicBaseViewController<UITableViewDataSource,UITableViewDelegate>


-(instancetype) initWithHouseId:(NSString *)houseId;

@end
