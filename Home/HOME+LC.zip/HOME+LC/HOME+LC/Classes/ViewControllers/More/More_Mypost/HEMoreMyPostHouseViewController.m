//
//  HEMoreMyPostHouseViewController.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-6-10.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEMoreMyPostHouseViewController.h"
#import "HEMoreMyPostListViewController.h"


@interface HEMoreMyPostHouseViewController ()
{
    HEMoreMyPostListViewController *_postList;
}

@end

@implementation HEMoreMyPostHouseViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    _postList = [[HEMoreMyPostListViewController alloc] init];
    _postList.view.frame=self.contentImageView.frame;
    _postList.viewController=self;
    [self.view addSubview:_postList.view];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(BOOL)isCreateSegmenetControllExpand
{
    return NO;
}

-(NSString *)navBarTitle
{
    return @"My Post";
}
@end
