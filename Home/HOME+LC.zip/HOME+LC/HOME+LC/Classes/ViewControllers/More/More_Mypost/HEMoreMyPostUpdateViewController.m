//
//  HEMoreMyPostUpdateViewController.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-6-11.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEMoreMyPostUpdateViewController.h"
#import "HEMyPostUpdateHouseCell.h"

@interface HEMoreMyPostUpdateViewController ()
{
    UITableView *_updateTableView;
    NSString *_houseId;
}

@end

@implementation HEMoreMyPostUpdateViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(instancetype)initWithHouseId:(NSString *)houseId
{
    self = [super init];
    if (self) {
        _houseId = houseId;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    _updateTableView = [[UITableView alloc] initWithFrame:self.contentImageView.frame style:UITableViewStylePlain];
    _updateTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    _updateTableView.dataSource=self;
    _updateTableView.delegate=self;
    _updateTableView.backgroundColor = [UIColor clearColor];

    [self.view addSubview:_updateTableView];
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    HEMyPostUpdateHouseCell *updataCell = [[HEMyPostUpdateHouseCell alloc] initWithNibAndHouseId:_houseId];
    updataCell.viewController=self;
    return updataCell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 902;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSString *)navBarTitle
{
    return @"Update House";
}

@end
