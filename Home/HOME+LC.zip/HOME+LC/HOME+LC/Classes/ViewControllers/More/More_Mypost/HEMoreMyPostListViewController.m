
//
//  HEMoreMyPostListViewController.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-6-10.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEMoreMyPostListViewController.h"
#import "HEHomeHouseDetailViewController.h"
#import "HEMoreMyPostUpdateViewController.h"
#import "HEMyPostCell.h"
#import "HEHouseInfo.h"

@interface HEMoreMyPostListViewController ()
{
    NSMutableArray *_sourceArray;
    NSMutableArray *_openArray;
}

@end

@implementation HEMoreMyPostListViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    self.tableView.backgroundColor=[UIColor clearColor];
    
    _sourceArray = [[NSMutableArray alloc] init];
    _openArray = [[NSMutableArray alloc] init];
    
    [self publicRequest:SVProgressHUDMaskTypeClear];
    
}


-(void) publicRequest:(SVProgressHUDMaskType) svType
{
    HEHouseInfo *house=[[HEHouseInfo alloc] init];
    house.publisherId = [HEUserLogin sharedLogin].userId;
    [house requestCurrentUserPostHouse:^(id houseInfo) {
        if ([houseInfo count] == 0)
        {
            TOST_SHOW(@"I'm sorry there is no more data");
            [self endRefresh];
            return ;
        }
        
        [_sourceArray  removeAllObjects];
        [_sourceArray addObjectsFromArray:houseInfo];
        
        [_openArray removeAllObjects];
        for(int i=0; i<[_sourceArray count]; i++)
        {
            [_openArray addObject:@(NO)];
        }
        [self.tableView reloadData];
        [self endRefresh];
    } requestError:^{
        [self endRefresh];
    } svType:svType];
    
}

//160 130


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [_sourceArray count];
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *str=@"Cell";
    HEMyPostCell *cell = [tableView dequeueReusableCellWithIdentifier:str];
    if (!cell)
    {
        
        __weak typeof(self) wself = self;
        cell = [[HEMyPostCell alloc] initWtihOpenClick:^(NSIndexPath *buttonIndexPath, UIButton *button, BOOL isOpen) {
            
            _openArray[buttonIndexPath.row] = @(isOpen);
            [tableView reloadRowsAtIndexPaths:@[buttonIndexPath] withRowAnimation:UITableViewRowAnimationFade];
            
        } delteButtonClick:^(NSIndexPath *buttonIndexPath, UIButton *button) {
            
            HEHouseInfo *house = [[HEHouseInfo alloc] init];
            house.houseId = _sourceArray[indexPath.row][@"_id"];
            
            [house deleteHouseForCurrentUser:^(id houseInfo) {
               
                [_sourceArray removeObjectAtIndex:buttonIndexPath.row];
                [_openArray removeObjectAtIndex:buttonIndexPath.row];
                
                [tableView deleteRowsAtIndexPaths:@[buttonIndexPath] withRowAnimation:UITableViewRowAnimationFade];
            } requestError:nil svType:0];
            
        } replyButtonClick:^(NSIndexPath *ButtonIndexPath, UIButton *button) {
            
            HEMoreMyPostUpdateViewController *houseUpdate = [[HEMoreMyPostUpdateViewController alloc] initWithHouseId:_sourceArray[indexPath.row][@"_id"]];
            [wself.viewController.navigationController pushViewController:houseUpdate animated:YES];
            
        }];
    }
    
    if ([_openArray[indexPath.row] boolValue] == YES)
    {
        cell.updateButton.hidden = NO;
        cell.deleteButton.hidden = NO;
    }
    else
    {
        cell.updateButton.hidden = YES;
        cell.deleteButton.hidden = YES;
    }
    
    cell.nameLable.text = _sourceArray[indexPath.row][@"name_en"];
    cell.priceLable.text = [NSString stringWithFormat:@"%@RMB",_sourceArray[indexPath.row][@"price"]];
    [cell.photoImageView setImageWithURL:IMAGEURLCREATE(_sourceArray[indexPath.row][@"picture"]) placeholderImage:DEFAULTIMAGE];
    cell.descriptionText.text = _sourceArray[indexPath.row][@"description_en"];
    cell.closeButton.selected = [_openArray[indexPath.row] boolValue];
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    HEHomeHouseDetailViewController *houseDetail=[HEHomeHouseDetailViewController sharedHouseDetail];
    houseDetail.houseId = _sourceArray[indexPath.row][@"_id"];
    [houseDetail releadeHouseInfo];
    [self.viewController.navigationController pushViewController:houseDetail animated:YES];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([_openArray[indexPath.row] boolValue] == YES)
    {
        return 160;
    }
    else
    {
        return 130;
    }
    
}


-(BOOL)usesAutoRefresh
{
    return NO;
}
-(BOOL)usesRefreshFooterView
{
    return NO;
}
-(void)didStartLoadingNewObjects
{
    [self publicRequest:SVProgressHUDMaskTypeNil];
}
-(void) endRefresh
{
    [super didEndLoadingNewObjects];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
