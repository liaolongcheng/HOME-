//
//  HEMoreViewController.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-15.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEMoreViewController.h"
#import "HEMoreAccountCell.h"
#import "HEMorePostCell.h"
#import "HEMoreSettingsCell.h"
#import "HEMoreStatementCell.h"
#import "HEMoreContactCell.h"

@interface HEMoreViewController ()

@end

@implementation HEMoreViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self showTabBar];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    UIImageView *imageView=[[UIImageView alloc] initWithFrame:self.mainTableView.bounds];
    imageView.image=LOAD_IMAGE(@"background1.png");
    self.mainTableView.backgroundView=imageView;
}


-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 5;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell;
    
    if (indexPath.section == 0)
    {
        cell=LOAD_TABLEVIEWCELL(@"HEMoreAccountCell");
        HEMoreAccountCell *accountCell=(HEMoreAccountCell *)cell;
        accountCell.viewController=self;
    }
    else if(indexPath.section == 1)
    {
        cell=LOAD_TABLEVIEWCELL(@"HEMorePostCell");
        HEMorePostCell *postCell=(HEMorePostCell *)cell;
        postCell.viewController=self;
    }
    else if(indexPath.section == 2)
    {
        cell = LOAD_TABLEVIEWCELL(@"HEMoreContactCell");
        HEMoreContactCell *contactCell = (HEMoreContactCell *)cell;
        contactCell.viewController = self;
    }
    else if(indexPath.section == 3)
    {
        cell=LOAD_TABLEVIEWCELL(@"HEMoreSettingsCell");
        HEMoreSettingsCell *settingCell=(HEMoreSettingsCell *)cell;
        settingCell.mainViewController=self;
        if (_isClose)
        {
            settingCell.pushLable.hidden = YES;
            settingCell.updateLable.hidden = YES;
            settingCell.switc1.hidden = YES;
            settingCell.switc2.hidden = YES;
            settingCell.line1View.hidden = YES;
        }
        else
        {
            settingCell.pushLable.hidden = NO;
            settingCell.updateLable.hidden = NO;
            settingCell.switc1.hidden = NO;
            settingCell.switc2.hidden = NO;
            settingCell.line1View.hidden = NO;
        }
    }
    else if(indexPath.section == 4)
    {
        cell=LOAD_TABLEVIEWCELL(@"HEMoreStatementCell");
        HEMoreStatementCell *statmentCell=(HEMoreStatementCell *)cell;
        statmentCell.mainTableView=tableView;
    }

    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0)
    {
       return 161;
    }
    else if(indexPath.section == 1)
    {
         return 116;
    }
    else if(indexPath.section == 2)
    {
        return 118;
    }
    else if(indexPath.section == 3)
    {
        if (_isClose)
        {
            return 42;
        }
        else
        {
            return 121;
        }
    }
    else if(indexPath.section == 4)
    {
        return 43;
    }
    return 0;
}

-(UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
