//
//  HEMoreMyPasswordViewController.m
//  HOME+LC
//
//  Created by user on 14/10/30.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEMoreMyPasswordViewController.h"
#import "HEUserRegister.h"

@interface HEMoreMyPasswordViewController ()

@end

@implementation HEMoreMyPasswordViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    HEUserRegister *registe = [HEUserRegister sharedRegister];
    registe.name = nil;
    registe.phone = nil;
    registe.pass = nil;
    registe.company = nil;
    registe.address = nil;
    registe.profile_image = nil;
    registe.email = nil;
    
    self.contentImageView.frame=CGRectMake(self.contentImageView.frame.origin.x, self.contentImageView.frame.origin.y, CGRectGetWidth(self.contentImageView.frame), 220);
}
- (IBAction)sureButtonClick:(id)sender
{
    if (IS_KONG_STRING(_oldPwdText.text))
    {
        BH_ALERT(@"Please enter the initial password");return;
    }
    if (IS_KONG_STRING(_xNewPwdText.text))
    {
        BH_ALERT(@"Please enter your new password");return;
    }
    if (IS_KONG_STRING(_confirmPwdText.text))
    {
        BH_ALERT(@"Please confirm your new password");return;
    }
    if (![_xNewPwdText.text isEqualToString:_confirmPwdText.text])
    {
        BH_ALERT(@"Two passwords do not match");return;
    }
    HEUserLogin *login = [HEUserLogin sharedLogin];
    if (![_oldPwdText.text isEqualToString:login.passWord])
    {
        BH_ALERT(@"Old password you entered is incorrect");return;
    }
    
    HEUserRegister *registe = [HEUserRegister sharedRegister];
    registe.pass = _xNewPwdText.text;
    [registe updateUserInfoWithSuccess:^(id successObject) {
        [SVProgressHUD showSuccessWithStatus:@"修改成功..." duration:0.5];
    } registerError:^{
        [SVProgressHUD showErrorWithStatus:@"修改失败..." duration:0.4];
    }];
}

- (IBAction)cancelButtonClick:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
-(NSString *)navBarTitle
{
    return @"Change Password";
}
@end
