//
//  HEMoreMyPasswordViewController.h
//  HOME+LC
//
//  Created by user on 14/10/30.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEPublicBaseViewController.h"

@interface HEMoreMyPasswordViewController : HEPublicBaseViewController
@property (weak, nonatomic) IBOutlet UITextField *oldPwdText;
@property (weak, nonatomic) IBOutlet UITextField *xNewPwdText;
@property (weak, nonatomic) IBOutlet UITextField *confirmPwdText;
- (IBAction)sureButtonClick:(id)sender;
- (IBAction)cancelButtonClick:(id)sender;

@end
