//
//  HEMoreViewController.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-15.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HEBaseViewController.h"


@interface HEMoreViewController : HEBaseViewController<UITableViewDataSource,UITableViewDelegate>
@property (strong, nonatomic) IBOutlet UITableView *mainTableView;
@property (assign, nonatomic) BOOL isClose;

@end
