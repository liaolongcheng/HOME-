//
//  HEMoreMyAccountViewController.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-31.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HERegisterViewController.h"

@interface HEMoreMyAccountViewController : HEPublicBaseViewController<UITableViewDataSource,UITableViewDelegate>

@property (strong, nonatomic) IBOutlet UITableView *updateUserInfoTableView;
@end
