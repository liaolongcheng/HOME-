//
//  HEMoreMyAccountViewController.m
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-31.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "HEMoreMyAccountViewController.h"
#import "HERegisterContentCell.h"
#import "HEUpdateUserInfoCell.h"
#import "HERegisterPhotoCell.h"
#import "HEUserRegister.h"

@interface HEMoreMyAccountViewController ()
{
    HERegisterPhotoCell *photoCell;
}

@end

@implementation HEMoreMyAccountViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
     self.contentImageView.hidden = YES;
    // Do any additional setup after loading the view from its nib.
    self.updateUserInfoTableView.backgroundColor=[UIColor clearColor];
    self.updateUserInfoTableView.dataSource=self;
    self.updateUserInfoTableView.delegate=self;
    self.updateUserInfoTableView.separatorStyle=UITableViewCellSeparatorStyleNone;
    
    HEUserRegister *registe = [HEUserRegister sharedRegister];
    registe.name = nil;
    registe.phone = nil;
    registe.pass = nil;
    registe.company = nil;
    registe.address = nil;
    registe.profile_image = nil;
    registe.email = nil;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0)
    {
        if (photoCell == nil)
        {
            photoCell = LOAD_TABLEVIEWCELL(@"HERegisterPhotoCell");
            photoCell.isUpdate = YES;
        }
        
        return photoCell;
    }
    else if(indexPath.section == 1)
    {
        HEUpdateUserInfoCell *contentCell = LOAD_TABLEVIEWCELL(@"HEUpdateUserInfoCell");
        contentCell.viewController = self;
        return contentCell;
    }
    return nil;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section == 0)
    {
        return 50;
    }
    else if(indexPath.section == 1)
    {
        HEUserLogin *login = [HEUserLogin sharedLogin];
        if ([login.type isEqualToString:@"seller"])
        {
            return 457;
        }
        return 387;
    }
    return 0;
}
-(NSString *)navBarTitle
{
    return @"Account";
}


@end
