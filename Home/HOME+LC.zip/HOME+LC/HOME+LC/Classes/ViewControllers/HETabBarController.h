//
//  HETabBarController.h
//  HOME+LC
//
//  Created by liaolongcheng on 14-5-14.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//


#import <UIKit/UIKit.h>

@interface HENavgaionViewController : UINavigationController

@end


@interface HETabBarController : UITabBarController

-(void) setHiddenTabBar;
-(void) setShowTabBar;

@end
