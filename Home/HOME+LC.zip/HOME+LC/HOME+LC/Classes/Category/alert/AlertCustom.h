//
//  AlertCustom.h
//  BaiHuoGou
//
//  Created by liaolongcheng on 14-2-21.
//  Copyright (c) 2014年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AlertCustom : NSObject

+(void)showWithView:(UIView *) view;
+(void)dismissWithView:(UIView *) view;
//只会隐藏不会移除
+(void)hiddenWithView:(UIView *)view;

+(void)tapSome;
@end
