//
//  AlertCustom.m
//  BaiHuoGou
//
//  Created by liaolongcheng on 14-2-21.
//  Copyright (c) 2014年 apple. All rights reserved.
//

#define WINDOW [[UIApplication sharedApplication] keyWindow]

#import "AlertCustom.h"
#import "viewCategory.h"


@implementation AlertCustom

+(void) showWithView:(UIView *) view
{

    UIView *backView=[[UIView alloc] initWithFrame:WINDOW.bounds];
    backView.userInteractionEnabled=YES;
    backView.tag=100000;
    backView.backgroundColor=[UIColor blackColor];
    backView.alpha=0.4;
    [WINDOW addSubview:backView];
    UITapGestureRecognizer *tapBack=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapSome)];
    [backView addGestureRecognizer:tapBack];
    
    view.userInteractionEnabled=YES;
    view.center=backView.center;
    view.tag=100001;
    [WINDOW addSubview:view];

    [view animationAlert];
}

+(void)tapSome
{
    [self remove];
}

+(void) remove
{
    [UIView animateWithDuration:0.5 animations:^{
        [WINDOW viewWithTag:100000].alpha=0.0;
        [WINDOW viewWithTag:100001].alpha=0.0;
    } completion:^(BOOL finished) {
        [[WINDOW viewWithTag:100000] removeFromSuperview];
        [[WINDOW viewWithTag:100001] removeFromSuperview];
        
    }];
}
+(void)dismissWithView:(UIView*)view
{
    [self remove];
}
+(void)hiddenWithView:(UIView *)view
{
    [UIView animateWithDuration:0.5 animations:^{
        [WINDOW viewWithTag:100000].alpha=0.0;
        [WINDOW viewWithTag:100001].alpha=0.0;
    } completion:^(BOOL finished) {
    }];
}

@end
