//
//  UITableViewCell+Category.h
//  HOME+LC
//
//  Created by user on 14/10/27.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITableViewCell (Category)

-(UITableView *)tableViewOfcurrentCell;

-(NSIndexPath *)indexPathOfcurrentCell;
@end
