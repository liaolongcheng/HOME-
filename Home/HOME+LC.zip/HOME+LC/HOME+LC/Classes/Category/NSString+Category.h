//
//  NSString+MKNetworkKitAdditions.h
//  MKNetworkKitDemo
//
//  Created by Mugunth Kumar (@mugunthkumar) on 11/11/11.
//  Copyright (C) 2011-2020 by Steinlogic Consulting and Training Pte Ltd

//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in
//  all copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
//  THE SOFTWARE.
/*
 
 后面验证虚拓展.  部分可适用本项目
 
 */

@interface NSString (NSStringCategory)
typedef enum RegexType{
    isNill,
    isError,
    isRight
}RegexType;

typedef enum {
    imageSmallType,
    imageMiddlType,
    imageBigType,
}imageType;

-(NSString*)replaceControlString;
-(NSString*)imagePathType:(imageType)__type;
- (CGFloat)getHeightByWidth:(NSInteger)_width font:(UIFont *)_font;
//- (NSString *)indentString:(NSString*)_string font:(UIFont *)_font;
- (NSString *)indentLength:(CGFloat)_len font:(UIFont *)_font;
- (BOOL)notEmptyOrNull;
+ (NSString *)replaceEmptyOrNull:(NSString *)checkString;
-(NSString*)replaceTime;
-(NSString*)replaceStoreKey;
- (NSString*)soapMessage:(NSString *)key,...;


//加密  md5  sha 
- (NSString *) md5;
- (NSString*) sha;
//DES加密
+(NSString *) encryptUseDES:(NSString *)plainText key:(NSString *)key;
//DES解密
+(NSString *) decryptUseDES:(NSString *)plainText key:(NSString *)key;
- (NSString*) uniqueString;
//ios iphone html特殊字符转码  
- (NSString*) urlEncodedString;
- (NSString*) urlDecodedString;
//Unicode转换为汉字
+ (NSString *)replaceUnicode:(NSString *)unicodeStr;
//验证用户名是否是7-13位
+(RegexType)ValidateUserName:(NSString *)userName withMsg:(NSString *)msg;
//验证用户密码
+(RegexType)ValidatePsw:(NSString *)psw withMsg:(NSString *)msg;
//验证用户昵称
+(RegexType)ValidateNickName:(NSString *)nickName withMsg:(NSString *)msg;
+(RegexType)ValidateUserNameDefault:(NSString *)userName withMsg:(NSString *)msg;
//邮箱验证格式
+ (RegexType) validateEmail: (NSString *) candidate;
//电话号码限制
+ (RegexType) validateTel: (NSString *) candidate;
//只能是汉字或字母
+ (RegexType) validateCharacter:(NSString *)candidate;
//限制特殊符号
+ (RegexType) validateCharacternum:(NSString *)candidate;
//验证是否是数字
+ (RegexType)validateNumeric:(NSString *)str;
//不能以下划线开头
+(RegexType)isValidateUserName:(NSString *)userName withMsg:(NSString *)msg;
//验证密码
+(RegexType)isValidateUserNameDefault:(NSString *)userName withMsg:(NSString *)msg;
+(RegexType)isValidatePsw:(NSString *)psw withMsg:(NSString *)msg;
+(RegexType)isValidateBlank:(NSString*)blank;
+(RegexType)isValidateDigtal:(NSString *)blank;

@end
