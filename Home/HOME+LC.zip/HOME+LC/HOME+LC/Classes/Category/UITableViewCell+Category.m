//
//  UITableViewCell+Category.m
//  HOME+LC
//
//  Created by user on 14/10/27.
//  Copyright (c) 2014年 liaolongcheng. All rights reserved.
//

#import "UITableViewCell+Category.h"

@implementation UITableViewCell (Category)

-(UITableView *)tableViewOfcurrentCell
{
    UIView *wrapperView=[self superview];
    UITableView *superTableView=(UITableView *)[wrapperView superview];
    return superTableView;
}

-(NSIndexPath *)indexPathOfcurrentCell
{
    UITableView *superTableView=[self tableViewOfcurrentCell];
    NSIndexPath *index=[superTableView indexPathForCell:self];
    return index;
}

@end
