//
//  NSString+MKNetworkKitAdditions.m
//  MKNetworkKitDemo
//
//  Created by Mugunth Kumar (@mugunthkumar) on 11/11/11.
//  Copyright (C) 2011-2020 by Steinlogic Consulting and Training Pte Ltd

//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in
//  all copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
//  THE SOFTWARE.

#import "NSString+Category.h"
#import <CommonCrypto/CommonDigest.h>
#import <CommonCrypto/CommonCryptor.h>
#import "NSData+Base64.h"

@implementation NSString (NSStringCategory)

-(NSString*)replaceControlString
{
	self=[self stringByReplacingOccurrencesOfString:@"\\" withString:@"\\\\"];
	self=[self stringByReplacingOccurrencesOfString:@"\b" withString:@"\\b"];
	self=[self stringByReplacingOccurrencesOfString:@"\f" withString:@"\\f"];
	self=[self stringByReplacingOccurrencesOfString:@"\r" withString:@"\\t"];
	self=[self stringByReplacingOccurrencesOfString:@"\t" withString:@"\\r"];
	self=[self stringByReplacingOccurrencesOfString:@"\n" withString:@"\\n"];
	self=[self stringByReplacingOccurrencesOfString:@"\"" withString:@"\\\""];
	
	return self;
}
-(NSString*)replaceStoreKey
{
    NSRange range=[self rangeOfString:@"user.lat="];
    if (range.length==0) {
        range=[self rangeOfString:@"loc.latOffset="];
        if (range.length==0) {
            range=[self rangeOfString:@"lat="];
            if (range.length!=0) {
                NSInteger l=[[self substringFromIndex:[self rangeOfString:@"lng="].location] rangeOfString:@"&"].location;
                range.length=[self rangeOfString:@"lng="].location-range.location+l;
                self=[self stringByReplacingCharactersInRange:range withString:@""];
            }
        }else{
            NSInteger l=[[self substringFromIndex:[self rangeOfString:@"loc.lngOffset="].location] rangeOfString:@"&"].location;
            range.length=[self rangeOfString:@"loc.lngOffset="].location-range.location+l;
            self=[self stringByReplacingCharactersInRange:range withString:@""];
        }
    }else{
        NSInteger l=[[self substringFromIndex:[self rangeOfString:@"user.lng="].location] rangeOfString:@"&"].location;
        range.length=[self rangeOfString:@"user.lng="].location-range.location+l;
        self=[self stringByReplacingCharactersInRange:range withString:@""];
    }
    return self;
}

//"upload/".length=7
-(NSString*)imagePathType:(imageType)__type
{
    if ((__type != imageSmallType && __type != imageBigType)) {
        return self;
    }else{
        return [self stringByReplacingOccurrencesOfString:@"/" withString:__type==imageSmallType?@"/s":@"/b" options:0 range:NSMakeRange(7, [self length]-7)];
    }
}
- (CGFloat)getHeightByWidth:(NSInteger)_width font:(UIFont *)_font
{
    //!self不会调用，不用判断了
    //return [self sizeWithFont:_font constrainedToSize:CGSizeMake(_width, 1000) lineBreakMode:UILineBreakModeCharacterWrap].height;
    
    NSDictionary *attribute = @{NSFontAttributeName:_font};
    
    CGSize retSize = [self boundingRectWithSize:CGSizeMake(_width, 0)
                                             options:
                      NSStringDrawingTruncatesLastVisibleLine |
                      NSStringDrawingUsesLineFragmentOrigin |
                      NSStringDrawingUsesFontLeading
                                          attributes:attribute
                                             context:nil].size;
    
    return retSize.height;
}

//- (NSString *)indentString:(NSString*)_string font:(UIFont *)_font
//{
//    if (!_string) {
//        return self;
//    }else{
//        CGSize  size=[_string sizeWithFont:_font];
//        NSLog(@"%f,%f",size.width/[@" " sizeWithFont:_font].width,[@" " sizeWithFont:_font].width);
//        return [NSString stringWithFormat:@"%@%@",[@"" stringByPaddingToLength:(size.width/[@"_" sizeWithFont:_font].width+2)*2 withString:@" " startingAtIndex:0],self];
//    }
//}
- (NSString *)indentLength:(CGFloat)_len font:(UIFont *)_font
{
    NSString *str=@"";
    CGFloat temp=0.0;
    while (temp<=_len) {
        str=[str stringByAppendingString:@" "];
        temp=[str sizeWithFont:_font].width;
    }
    return [NSString stringWithFormat:@"%@%@",str,self];
    //[@"" stringByPaddingToLength:(_len/[@"_" sizeWithFont:_font].width+1) withString:@"_" startingAtIndex:0]
}
- (BOOL)notEmptyOrNull
{
    if ([self isEqualToString:@""]||[self isEqualToString:@"null"] || [self isEqualToString:@"\"\""] || [self isEqualToString:@"''"]) {
        return NO;
    }
    return YES;
}

+ (NSString *)replaceEmptyOrNull:(NSString *)checkString
{
    if (!checkString || [checkString isEqualToString:@""]||[checkString isEqualToString:@"null"]) {
        return @"";
    }
    return checkString;
}
-(NSString*)replaceTime
{
    self=[self stringByReplacingOccurrencesOfString:@"-" withString:@"年" options:0 range:NSMakeRange(0, 5)];
    self=[self stringByReplacingOccurrencesOfString:@"-" withString:@"月"];
    self=[self stringByAppendingString:@"日"];
    return self;
}

- (NSString*)soapMessage:(NSString *)key,...
{
    NSString *akey;
    va_list ap;
    va_start(ap, key);
    NSString *obj = nil;
    if (key) {
        if ([key rangeOfString:@"<"].length == 0)
            obj=[NSString stringWithFormat:@"<%@>%@</%@>",key,@"%@",key];
        else
            obj = key;
        
        while (obj&&(akey=va_arg(ap,id))) {
            if ([akey rangeOfString:@"<"].length == 0)
                obj=[obj stringByAppendingFormat:@"<%@>%@</%@>",akey,@"%@",akey];
            else
                obj = [obj stringByAppendingString:akey];
        }
        va_end(ap);
    }
    
    return [NSString stringWithFormat:@"<?xml version=\"1.0\" encoding=\"UTF-8\"?><soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:soap=\"http://soap.csc.iofd.cn/\"> <soapenv:Header/> <soapenv:Body><soap:%@>%@</soap:%@></soapenv:Body></soapenv:Envelope>",self,obj?obj:@"",self];;
}



- (NSString *) md5
{
    const char *cStr = [self UTF8String];
    unsigned char result[16];
    CC_MD5( cStr, (unsigned int) strlen(cStr), result);
    return [NSString stringWithFormat:
			@"%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x",
			result[0], result[1], result[2], result[3], 
			result[4], result[5], result[6], result[7],
			result[8], result[9], result[10], result[11],
			result[12], result[13], result[14], result[15]
			];      
}
- (NSString*) sha
{
    const char *cstr = [self cStringUsingEncoding:NSUTF8StringEncoding];
    NSData *data = [NSData dataWithBytes:cstr length:self.length];
    
    uint8_t digest[CC_SHA1_DIGEST_LENGTH];
    
    CC_SHA1(data.bytes, data.length, digest);
    
    NSMutableString* output = [NSMutableString stringWithCapacity:CC_SHA1_DIGEST_LENGTH * 2];
    
    for(int i = 0; i < CC_SHA1_DIGEST_LENGTH; i++)
        [output appendFormat:@"%02x", digest[i]];
    
    return output;
}
//加密
+(NSString *) encryptUseDES:(NSString *)plainText key:(NSString *)key;
{
    NSString *ciphertext = nil;
    const char *textBytes = [plainText UTF8String];
    NSUInteger dataLength = [plainText length];
    unsigned char buffer[1024];
    memset(buffer, 0, sizeof(char));
    size_t numBytesEncrypted = 0;
    CCCryptorStatus cryptStatus = CCCrypt(kCCEncrypt, kCCAlgorithmDES,
                                          kCCOptionPKCS7Padding,
                                          [key UTF8String], kCCKeySizeDES,
                                          NULL,
                                          textBytes, dataLength,
                                          buffer, 1024,
                                          &numBytesEncrypted);
    if (cryptStatus == kCCSuccess) {
        NSData *data = [NSData dataWithBytes:buffer length:(NSUInteger)numBytesEncrypted];
        ciphertext = [NSData dataTohexString:data];
    }
    
    return ciphertext;
}

//解密
+(NSString *) decryptUseDES:(NSString *)plainText key:(NSString *)key
{
    NSString *cleartext = nil;
    NSData *textData = [NSData hexStringToData:plainText];
    NSUInteger dataLength = [textData length];
    unsigned char buffer[1024];
    memset(buffer, 0, sizeof(char));
    size_t numBytesEncrypted = 0;
    
    CCCryptorStatus cryptStatus = CCCrypt(kCCDecrypt, kCCAlgorithmDES,kCCOptionPKCS7Padding,
                                          [key UTF8String], kCCKeySizeDES,
                                          NULL,
                                          [textData bytes]  , dataLength,
                                          buffer, 1024,
                                          &numBytesEncrypted);
    if (cryptStatus == kCCSuccess) {
        //NSLog(@"DES解密成功");
        NSData *data = [NSData dataWithBytes:buffer length:(NSUInteger)numBytesEncrypted];
        cleartext = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    }else{
        //NSLog(@"DES解密失败");
    }
    return cleartext;
}

- (NSString*) uniqueString
{
	CFUUIDRef	uuidObj = CFUUIDCreate(nil);
	NSString	*uuidString = ( NSString*)CFUUIDCreateString(nil, uuidObj);
	CFRelease(uuidObj);
	return uuidString;
}

- (NSString*) urlEncodedString {
    CFStringRef encodedCFString = CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault,
                                                                        ( CFStringRef) self, 
                                                                        nil,
                                                                        CFSTR("?!@#$^&%*+,:;='\"`<>()[]{}/\\| "), 
                                                                        kCFStringEncodingUTF8);
    
    NSString *encodedString = [[NSString alloc] initWithString:( NSString*) encodedCFString];    

    if(!encodedString)
        encodedString = @"";    
    
    return encodedString;
}

- (NSString*) urlDecodedString {

    CFStringRef decodedCFString = CFURLCreateStringByReplacingPercentEscapesUsingEncoding(kCFAllocatorDefault, 
                                                                                          ( CFStringRef) self,
                                                                                          CFSTR(""),
                                                                                          kCFStringEncodingUTF8);
    
    // We need to replace "+" with " " because the CF method above doesn't do it
    NSString *decodedString = [[NSString alloc] initWithString:( NSString*) decodedCFString];    
    return (!decodedString) ? @"" : [decodedString stringByReplacingOccurrencesOfString:@"+" withString:@" "];
}

+ (NSString *)replaceUnicode:(NSString *)unicodeStr {
    
    NSString *tempStr1 = [unicodeStr stringByReplacingOccurrencesOfString:@"\\u"withString:@"\\U"];
    
    NSString *tempStr2 = [tempStr1 stringByReplacingOccurrencesOfString:@"\""withString:@"\\\""];
    
    NSString *tempStr3 = [[@"\""stringByAppendingString:tempStr2]stringByAppendingString:@"\""];
    
    NSData *tempData = [tempStr3 dataUsingEncoding:NSUTF8StringEncoding];
    
    NSString* returnStr = [NSPropertyListSerialization propertyListFromData:tempData
                           
                                                          mutabilityOption:NSPropertyListImmutable
                           
                                                                    format:NULL
                           
                                                          errorDescription:NULL];
    
    
    
    return [returnStr stringByReplacingOccurrencesOfString:@"\\r\\n"withString:@"\n"];  
    
    
    
}


+(RegexType)ValidateUserName:(NSString *)userName withMsg:(NSString *)msg{
    if (userName == nil || [userName isEqualToString:@""]) {
        return isNill;
    }
    //    NSString *regex = @"^[a-z,A-Z,@,-,0-9]{5,16}$";
    NSString *regex = @"^[a-z,A-Z][a-z,A-Z,@,-,0-9]{7,13}$"; // change tianzhu0719
    NSPredicate *test = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",regex];
    if ([test evaluateWithObject:userName]) {
        return isRight;
    }else{
        return isError;
    }
}


+(RegexType)isValidateUserName:(NSString *)userName withMsg:(NSString *)msg{
    if (userName == nil || [userName isEqualToString:@""]) {
        return isNill;
    }
    //    NSString *regex = @"^[a-z,A-Z,@,-,0-9]{5,16}$";
    
    NSString *regex = @"^[a-z,A-Z][a-z,A-Z,0-9,_]{1,13}$"; // change tianzhu0719
    NSPredicate *test = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",regex];
    if ([test evaluateWithObject:userName]) {
        return isRight;
    }else{
        return isError;
    }
}

+(RegexType)isValidateDigtal:(NSString *)blank{
    if (blank == nil || [blank isEqualToString:@""]) {
        return isNill;
    }
    NSString *regex = @"^\\d{0,10}$"; // change tianzhu0719
    NSPredicate *test = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",regex];
    if ([test evaluateWithObject:blank]) {
        return isError;
    }else{
        return isRight;
    }
}

+(RegexType)ValidatePsw:(NSString *)psw withMsg:(NSString *)msg{
    if (psw == nil || [psw isEqualToString:@""]) {
        return isNill;
    }
    NSString *regex = @"^[a-z,A-Z,@,-,0-9]{6,14}$"; //change tianzhu0719
    NSPredicate *test = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",regex];
    if ([test evaluateWithObject:psw]) {
        return isRight;
    }else{
        
        return isError;
    }
    
}
+(RegexType)ValidateNickName:(NSString *)nickName withMsg:(NSString *)msg{
    if (nickName == nil || [nickName isEqualToString:@""]) {
        return isNill;
    }
    //    NSString *regex = @"^[a-z,A-Z,@,-,0-9]{5,16}$";
    NSString *regex = @"^[a-z,A-Z,/\u4e00-\u9fa5][a-z,A-Z,@,-,0-9,/\u4e00-\u9fa5]{1,6}$"; // change tianzhu0719
    NSPredicate *test = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",regex];
    if ([test evaluateWithObject:nickName]) {
        return isRight;
    }else{
        return isError;
    }
}

+(RegexType)ValidateUserNameDefault:(NSString *)userName withMsg:(NSString *)msg
{
    if (userName == nil || [userName isEqualToString:@""]) {
        return isNill;
    }
    //    NSString *regex = @"^[a-z,A-Z,@,-,0-9]{5,16}$";
    NSString *regex = @"^[a-z,A-Z,@,-,0-9]{8,14}$"; // change tianzhu0719
    NSPredicate *test = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",regex];
    if ([test evaluateWithObject:userName]) {
        return isRight;
    }else{
        return isError;
    }
}
#pragma mark validateEmail
+ (RegexType) validateEmail: (NSString *) candidate {
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
	if ([emailTest evaluateWithObject:candidate]) {
        return isRight;
    }else{
        return isError;
    }
}
#pragma mark validateTel
+ (RegexType) validateTel: (NSString *) candidate {
    NSString *telRegex = @"^1[358]\\d{9}$";
    NSPredicate *telTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", telRegex];
	if ([telTest evaluateWithObject:candidate]) {
        return isRight;
    }else{
        return isError;
    }
}
#pragma mark character  //限制输入汉子或字母
+(RegexType) validateCharacter:(NSString *)candidate{
    NSString *characterRegex=@"^[\u4E00-\u9FA5A-Za-z_]+$";
    NSPredicate *characterTest=[NSPredicate predicateWithFormat:@"SELF MATCHES %@",characterRegex];
    if ([characterTest evaluateWithObject:candidate]) {
        return isRight;
    }else{
        return isError;
    }
}
+ (RegexType) validateCharacternum:(NSString *)candidate;{
    NSString *characterRegex=@"^[-\u4E00-\u9FA5A-Za-z-\\d-]+$";
    NSPredicate *characterTest=[NSPredicate predicateWithFormat:@"SELF MATCHES %@",characterRegex];
    if ([characterTest evaluateWithObject:candidate]) {
        return isRight;
    }else{
        return isError;
    }
}
+ (RegexType)validateNumeric:(NSString *)str
{
    NSString *regex = @"^[0-9]*$";
    NSPredicate *test = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",regex];
    if ([test evaluateWithObject:str]) {
        return isRight;
    }else{
        return isError;
    }
}

+(RegexType)isValidateUserNameDefault:(NSString *)userName withMsg:(NSString *)msg
{
    if (userName == nil || [userName isEqualToString:@""]) {
        return isNill;
    }
    //    NSString *regex = @"^[a-z,A-Z,@,-,0-9]{5,16}$";
    //0827
    NSString *regex = @"^[a-z,A-Z][a-z,A-Z,0-9,_]{7,13}$"; // change tianzhu0719
    NSPredicate *test = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",regex];
    if ([test evaluateWithObject:userName]) {
        return isRight;
    }else{
        return isError;
    }
}

+(RegexType)isValidatePsw:(NSString *)psw withMsg:(NSString *)msg{
    if (psw == nil || [psw isEqualToString:@""]) {
        return isNill;
    }
    NSString *regex = @"^[a-z,A-Z,0-9][a-z,A-Z,0-9,_]{1,13}$";//change tianzhu0719
    NSPredicate *test = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",regex];
    if ([test evaluateWithObject:psw]) {
        return isRight;
    }else{
        
        return isError;
    }
    
}
+(RegexType)isValidateBlank:(NSString*)blank{
    if (blank == nil || [blank isEqualToString:@""]) {
        return isNill;
    }
    NSString *regex = @"\\s";//change tianzhu0719
    NSPredicate *test = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",regex];
    if ([test evaluateWithObject:blank]) {
        return isRight;
    }else{
        
        return isError;
    }
}
@end