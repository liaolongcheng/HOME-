//
//  HttpHelper.h
//  BaiHuoGou
//
//  Created by liaolongcheng on 14-2-20.
//  Copyright (c) 2014年 apple. All rights reserved.
//



#import "AFHTTPRequestOperationManager.h"
#import "SVProgressHUD.h"

//typedef void(^PhoneNumberInformation)(NSString *province,NSString *city,NSString *Operator)

@interface HttpHelper : AFHTTPRequestOperationManager

+(instancetype) sharedManager;
//启动网络指示器
+(void) startActiveListener;
//启动网络变化监听
+(void) startNetWorkingCheageListener;
//当前网络状态
+(AFNetworkReachabilityStatus) currentReachabilityStatus;
//取消当前请求
+(void)cancelCurrentOperatin;
//取消当前所有请求
+(void)cancelAllOperatins;



//get请求
+ (AFHTTPRequestOperation *)GET:(NSString *)URLString
                     parameters:(NSDictionary *)parameters
                         svText:(NSString *)svText
                    errorsvText:(NSString *)errorsvText
                     svMarkType:(SVProgressHUDMaskType) svMarkType
                        success:(void (^)(AFHTTPRequestOperation *operation, id responseObject))success
                        failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure;


//post请求
+ (AFHTTPRequestOperation *)POST:(NSString *)URLString
                      parameters:(NSDictionary *)parameters
                          svText:(NSString *)svText
                          errorsvText:(NSString *)errorsvText
                      svMarkType:(SVProgressHUDMaskType) svMarkType
                         success:(void (^)(AFHTTPRequestOperation *operation, id responseObject))success
                         failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure;
//带图片的post请求
+ (AFHTTPRequestOperation *)POST:(NSString *)URLString
                      parameters:(NSDictionary *)parameters
                          svText:(NSString *) svText
                      svMarkType:(SVProgressHUDMaskType) svMarkType
                        fileDate:(NSData *)flieDate
                         success:(void (^)(AFHTTPRequestOperation *operation, id responseObject))success
                         failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure;
//有进度条带图片的post请求
+ (AFHTTPRequestOperation *)POST:(NSString *)URLString
                      parameters:(NSDictionary *)parameters
                        progress:(UIProgressView *) progress
                        fileDate:(NSData *)flieDate
                         success:(void (^)(AFHTTPRequestOperation *operation, id responseObject))success
                         failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure;



+ (void) getPhoneNumber:(NSString *)phoneNumber Information:(void(^)(NSString *information))Information;

@end