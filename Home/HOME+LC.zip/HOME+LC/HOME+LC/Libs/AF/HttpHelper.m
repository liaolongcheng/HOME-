//
//  HttpHelper.m
//  BaiHuoGou
//
//  Created by liaolongcheng on 14-2-20.
//  Copyright (c) 2014年 apple. All rights reserved.
//

#import "HttpHelper.h"
#import "AFNetworking.h"
#import "UIProgressView+AFNetworking.h"
#import "NSString+Category.h"


#define MacthingElement @"getMobileCodeInfoResult"

static HttpHelper *manager;
static BOOL firstNetWorkStatusChange;


@interface HttpHelper ()<NSXMLParserDelegate>
{
    NSString *stringWithProvince;
    NSString *stringWithCity;
    NSString *stirngWithOperator;
    void(^PhoneNumberInformation)(NSString *information);
}
@end
@implementation HttpHelper

+(instancetype)sharedManager
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        
      
        manager=[[HttpHelper alloc] initWithBaseURL:nil];
        
    });
    return manager;
}


+(void)startActiveListener
{
    AFNetworkActivityIndicatorManager *activeManager=[AFNetworkActivityIndicatorManager sharedManager];
    [activeManager setEnabled:YES];
}

+(void)startNetWorkingCheageListener
{
    HttpHelper *helper=[[HttpHelper class] sharedManager];
    NSOperationQueue *queue=helper.operationQueue;
    [helper.reachabilityManager setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        
        if (status==AFNetworkReachabilityStatusNotReachable)
        {
            [queue setSuspended:NO];
            UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"系统提示" message:@"" delegate:nil cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];

            alert.message=@"当前网络已断开,请重新连接";
            [alert show];
        }
        else if (status==AFNetworkReachabilityStatusReachableViaWWAN||status==AFNetworkReachabilityStatusReachableViaWiFi)
        {
            [queue setSuspended:YES];
            if (firstNetWorkStatusChange) {
                UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"系统提示" message:@"" delegate:nil cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
                
                alert.message=@"网络已连接";
                [alert show];

            }
            else
            {
                firstNetWorkStatusChange=YES;
            }
            
        }
    }];
}

+(AFNetworkReachabilityStatus)currentReachabilityStatus
{
    HttpHelper *helper=[[HttpHelper class] sharedManager];
    return helper.reachabilityManager.networkReachabilityStatus;
}
+(void)cancelCurrentOperatin
{
    NSOperation *operation=[NSOperationQueue currentQueue];
   
    if ([operation isKindOfClass:[NSOperation class]])
    {
        if ([operation isCancelled]==NO || [operation isFinished]==NO)
        {
            [operation cancel];
        }
    }
    
    
    
}
+(void)cancelAllOperatins
{
    HttpHelper *helper=[[HttpHelper class] sharedManager];
    NSOperationQueue *queue=helper.operationQueue;
    [queue cancelAllOperations];
}
+(AFHTTPRequestOperation *)GET:(NSString *)URLString parameters:(NSDictionary *)parameters svText:(NSString *)svText errorsvText:(NSString *)errorsvText svMarkType:(SVProgressHUDMaskType)svMarkType success:(void (^)(AFHTTPRequestOperation *, id))success failure:(void (^)(AFHTTPRequestOperation *, NSError *))failure
{
    AFHTTPRequestOperation *operation=nil;
    
    if (svMarkType != SVProgressHUDMaskTypeNil)
    {
        [SVProgressHUD showWithStatus:svText maskType:svMarkType clicType:SVProgressHUDClickDefult];
    }
    
    
    operation=[[[HttpHelper class] sharedManager] GET:URLString parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        success(operation,responseObject);
        [SVProgressHUD dismiss];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        if (failure) {
            failure(operation,error);
        }
        
        
        [SVProgressHUD showErrorWithStatus:errorsvText duration:1.0];
        
    }];
    
    return operation;
}

+ (AFHTTPRequestOperation *)POST:(NSString *)URLString
                      parameters:(NSDictionary *)parameters
                          svText:(NSString *)svText
                     errorsvText:(NSString *)errorsvText
                      svMarkType:(SVProgressHUDMaskType) svMarkType
                         success:(void (^)(AFHTTPRequestOperation *operation, id responseObject))success
                         failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure
{
    AFHTTPRequestOperation *operation=nil;
    
    if (svMarkType != SVProgressHUDMaskTypeNil)
    {
        [SVProgressHUD showWithStatus:svText maskType:svMarkType clicType:SVProgressHUDClickDefult];
    }
    
    
    operation=[[[HttpHelper class] sharedManager] POST:URLString parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        [SVProgressHUD dismiss];
        success(operation,responseObject);
       
    
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [SVProgressHUD dismissWithError:errorsvText afterDelay:2.0];
        if (failure)
        {
             failure(operation,error);
        }
    }];
    return operation;
}
//+(AFHTTPRequestOperation *)POST:(NSString *)URLString
//                      parameters:(NSDictionary *)parameters
//                          svText:(NSString *) svText
//                      svMarkType:(SVProgressHUDMaskType) svMarkType
//                        fileDate:(NSData *)flieDate
//                         success:(void (^)(AFHTTPRequestOperation *operation, id responseObject))success
//                         failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure
//{
//    AFHTTPRequestOperation *operation=nil;
//    
//    if (svMarkType != SVProgressHUDMaskTypeNil)
//    {
//        
//        [SVProgressHUD showWithStatus:svText maskType:svMarkType];
//    }
//    operation=[[[HttpHelper class] sharedManager] POST:URLString parameters:parameters constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
//        
//        [formData appendPartWithFileData:flieDate name:@"image" fileName:@"" mimeType:@"JPEG"];
//        
//    } success:^(AFHTTPRequestOperation *operation, id responseObject) {
//        [SVProgressHUD dismiss];
//        success(operation,responseObject);
//    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
//        [SVProgressHUD showErrorWithStatus:@"request error" afterDelay:0.2 delayBlock:^{
//            failure(operation,error);
//        }];
//    }];
//    return operation;
//}
//
//+(AFHTTPRequestOperation *)POST:(NSString *)URLString
//                     parameters:(NSDictionary *)parameters
//                       progress:(UIProgressView *)progress
//                       fileDate:(NSData *)flieDate
//                        success:(void (^)(AFHTTPRequestOperation *, id))success
//                        failure:(void (^)(AFHTTPRequestOperation *, NSError *))failure
//{
//    AFHTTPRequestOperation *operation=[[[HttpHelper class] sharedManager] POST:URLString parameters:parameters constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
//
//        [formData appendPartWithFileData:flieDate name:@"image" fileName:@"" mimeType:@"JPEG"];
//        
//    } success:^(AFHTTPRequestOperation *operation, id responseObject) {
//        success(operation,responseObject);
//    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
//        failure(operation,error);
//    }];
//    [progress setProgressWithUploadProgressOfOperation:operation animated:YES];
//    return operation;
//}

//+ (void) getPhoneNumber:(NSString *)phoneNumber Information:(void(^)(NSString *information))Information
//{
//  
//    if ([NSString validateTel:phoneNumber] != isRight) {
//        [SVProgressHUD showErrorWithStatus:@"电话号码格式不对" duration:2];
//        return;
//    }
//    
//    [HttpHelper sharedManager]->PhoneNumberInformation = [Information copy];
//    NSString *soapMsg= [NSString stringWithFormat:
//                        @"<?xml version=\"1.0\" encoding=\"utf-8\"?>"
//                        "<soap12:Envelope "
//                        "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" "
//                        "xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" "
//                        "xmlns:soap12=\"http://www.w3.org/2003/05/soap-envelope\">"
//                        "<soap12:Body>"
//                        "<getMobileCodeInfo xmlns=\"http://WebXml.com.cn/\">"
//                        "<mobileCode>%@</mobileCode>"
//                        "<userID>%@</userID>"
//                        "</getMobileCodeInfo>"
//                        "</soap12:Body>"
//                        "</soap12:Envelope>", phoneNumber, @""];
//    NSMutableURLRequest *request=[NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://webservice.webxml.com.cn/WebServices/MobileCodeWS.asmx"]];
//    NSString *msgLength=[NSString stringWithFormat:@"%d",[phoneNumber length]];
//    [request addValue:@"application/soap+xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
//    [request addValue:msgLength forHTTPHeaderField:@"Content-Length"];
//    [request setHTTPMethod:@"POST"];
//    [request setHTTPBody:[soapMsg dataUsingEncoding:NSUTF8StringEncoding]];
//    
//   
//    AFHTTPRequestOperationManager *manager = [[AFHTTPRequestOperationManager alloc]init];
//    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
//    [[manager HTTPRequestOperationWithRequest:request success:^(AFHTTPRequestOperation *operation, id responseObject) {
//        NSXMLParser *xmlParser = [[NSXMLParser alloc]initWithData:responseObject];
//        xmlParser.delegate = [[self class]sharedManager];
//        [xmlParser parse];
//    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
//        DLog(@"request error:%@",error)
//    }] start];
//}
//
//- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName;
//{
//    if ([elementName isEqualToString:MacthingElement])
//        [parser abortParsing];
//}
//- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
//{
//    if ([NSString validateTel:string] != isRight)
//        PhoneNumberInformation([string substringFromIndex:1]);
//}
@end
