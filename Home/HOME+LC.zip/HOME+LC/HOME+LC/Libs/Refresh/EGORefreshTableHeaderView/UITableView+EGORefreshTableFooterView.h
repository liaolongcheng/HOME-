//
//  UITableView+EGORefreshTableFooterView.h
//  jishigou
//
//  Created by silence on 13-4-7.
//  Copyright (c) 2013年 cqqlkj. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EGORefreshTableFooterView.h"

@interface UITableView (EGORefreshTableFooterView)

- (void)addRefreshTableFooterView:(id<EGORefreshTableFooterDelegate>)delegate;
- (EGORefreshTableFooterView *)refreshTableFooterView;

@end
