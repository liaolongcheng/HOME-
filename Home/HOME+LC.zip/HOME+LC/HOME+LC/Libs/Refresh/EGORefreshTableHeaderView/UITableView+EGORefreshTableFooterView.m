//
//  UITableView+EGORefreshTableFooterView.m
//  jishigou
//
//  Created by silence on 13-4-7.
//  Copyright (c) 2013年 cqqlkj. All rights reserved.
//

#import "UITableView+EGORefreshTableFooterView.h"
#import <objc/runtime.h>

static const char kEGORefreshTableFooterView;

@implementation UITableView (EGORefreshTableFooterView)

- (void)addRefreshTableFooterView:(id<EGORefreshTableFooterDelegate>)delegate
{
    EGORefreshTableFooterView *refreshTableFooterView =
        [[EGORefreshTableFooterView alloc] initWithFrame:CGRectMake(0.0f,
                                                                    (self.frame.origin.y + self.frame.size.height),
                                                                    self.frame.size.width,
                                                                    650.0f)];
    [refreshTableFooterView setUserInteractionEnabled:NO];
    [refreshTableFooterView setAutoresizesSubviews:YES];
    [refreshTableFooterView setAutoresizingMask:(UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleTopMargin)];
    [refreshTableFooterView setDelegate:delegate];
    objc_setAssociatedObject(self, &kEGORefreshTableFooterView, refreshTableFooterView, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    [self addSubview:refreshTableFooterView];
    EGORF_RELEASE(refreshTableFooterView);
}

- (EGORefreshTableFooterView *)refreshTableFooterView
{
    return objc_getAssociatedObject(self, &kEGORefreshTableFooterView);
}

@end
