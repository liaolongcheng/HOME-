//
//  UITableView+EGORefreshTableHeaderView.h
//  jishigou
//
//  Created by silence on 13-4-7.
//  Copyright (c) 2013年 cqqlkj. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EGORefreshTableHeaderView.h"

@interface UITableView (EGORefreshTableHeaderView)

- (void)addRefreshTableHeaderView:(id<EGORefreshTableHeaderDelegate>)delegate;
- (EGORefreshTableHeaderView *)refreshTableHeaderView;

@end
