//
//  UITableView+EGORefreshTableHeaderView.m
//  jishigou
//
//  Created by silence on 13-4-7.
//  Copyright (c) 2013年 cqqlkj. All rights reserved.
//

#import "UITableView+EGORefreshTableHeaderView.h"
#import <objc/runtime.h>

static const char kEGORefreshTableHeaderView;

@implementation UITableView (EGORefreshTableHeaderView)

- (void)addRefreshTableHeaderView:(id<EGORefreshTableHeaderDelegate>)delegate
{
    EGORefreshTableHeaderView *refreshTableHeaderView =
         [[EGORefreshTableHeaderView alloc] initWithFrame:CGRectMake(0.0f,
                                                                     0.0 - self.bounds.size.height,
                                                                     self.frame.size.width,
                                                                     self.bounds.size.height)];
    [refreshTableHeaderView setUserInteractionEnabled:NO];
    [refreshTableHeaderView setAutoresizesSubviews:YES];
    [refreshTableHeaderView setAutoresizingMask:UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight];
    [refreshTableHeaderView setBackgroundColor:[UIColor clearColor]];
    [refreshTableHeaderView setDelegate:delegate];
    objc_setAssociatedObject(self, &kEGORefreshTableHeaderView, refreshTableHeaderView, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    [self addSubview:refreshTableHeaderView];
    EGORF_RELEASE(refreshTableHeaderView);
}

- (EGORefreshTableHeaderView *)refreshTableHeaderView
{
    return objc_getAssociatedObject(self, &kEGORefreshTableHeaderView);
}

@end
