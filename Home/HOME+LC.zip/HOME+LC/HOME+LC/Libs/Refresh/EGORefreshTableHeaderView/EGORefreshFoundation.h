//
//  EGORefreshFoundation.h
//  NUIDEMO
//
//  Created by ZhuJiaQuan on 13-7-26.
//  Copyright (c) 2013年 5codelab. All rights reserved.
//

#ifndef EGORefreshFoundation_h
#define EGORefreshFoundation_h

#if !defined(__clang__) || __clang_major__ < 3
#ifndef __bridge
#define __bridge
#endif

#ifndef __bridge_retain
#define __bridge_retain
#endif

#ifndef __bridge_retained
#define __bridge_retained
#endif

#ifndef __autoreleasing
#define __autoreleasing
#endif

#ifndef __strong
#define __strong
#endif

#ifndef __unsafe_unretained
#define __unsafe_unretained
#endif

#ifndef __weak
#define __weak
#endif
#endif

#if __has_feature(objc_arc)

#define EGORF_PROP_RETAIN strong
#define EGORF_RETAIN(x) (x)
#define EGORF_RETURN_RETAINED(x) (x)
#define EGORF_RELEASE(x)
#define EGORF_SAFE_RELEASE(x) (x = nil);
#define EGORF_AUTORELEASE(x) (x)
#define EGORF_RETURN_AUTORELEASED(x) (x)
#define EGORF_BLOCK_COPY(x) (x)
#define EGORF_BLOCK_RELEASE(x)
#define EGORF_SUPER_DEALLOC()
#define EGORF_AUTORELEASE_POOL_START() @autoreleasepool {
#define EGORF_AUTORELEASE_POOL_END() }

#else

#define EGORF_PROP_RETAIN retain
#define EGORF_RETAIN(x) ([(x) retain]);
#define EGORF_RETURN_RETAINED SAFE_ARC_RETAIN
#define EGORF_RELEASE(x) ([(x) release]);
#define EGORF_SAFE_RELEASE(x) ([(x) release], (x) = nil);
#define EGORF_AUTORELEASE(x) ([(x) autorelease])
#define EGORF_RETURN_AUTORELEASED NUI_AUTORELEASE
#define EGORF_BLOCK_COPY(x) (Block_copy(x));
#define EGORF_BLOCK_RELEASE(x) (Block_release(x));
#define EGORF_SUPER_DEALLOC() ([super dealloc]);
#define EGORF_AUTORELEASE_POOL_START() NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
#define EGORF_AUTORELEASE_POOL_END() [pool release];

#endif

typedef enum{
	EGOOPullRefreshPulling = 0,
	EGOOPullRefreshNormal,
	EGOOPullRefreshLoading,
} EGOPullRefreshState;

#endif
