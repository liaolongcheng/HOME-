//
//  CABaseRefreshViewController.m
//  CACar
//
//  Created by 梁 珈瑞 on 13-8-14.
//  Copyright (c) 2013年 liaolongcheng. All rights reserved.
//

#import "CABaseRefreshViewController.h"

@interface CABaseRefreshViewController ()

@end

@implementation CABaseRefreshViewController

#pragma mark - properties

@synthesize isReloading = _isReloading;
@synthesize lastUpdated = _lastUpdated;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    [_lastUpdated release];
    [super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    if ([self usesRefreshHeaderView])
    {
        [self addRefreshHeaderView];
    }
    
    if ([self usesRefreshFooterView])
    {
        [self addRefreshFooterView];
    }
    
    if ([self usesAutoRefresh])
    {
        [self reloadData];
    }
    if ([self useRetain])
    {
        [self retain];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)usesRefreshHeaderView
{
    return YES;
}

- (BOOL)usesRefreshFooterView
{
    return YES;
}

- (BOOL)usesAutoRefresh
{
    return YES;
}

- (void)addRefreshHeaderView
{
    [self.tableView addRefreshTableHeaderView:self];
    [self.tableView.refreshTableHeaderView refreshLastUpdatedDate];
}

- (void)addRefreshFooterView
{
    [self.tableView addRefreshTableFooterView:self];
}

- (void)reloadData
{
    if (self.tableView.refreshTableHeaderView)
    {
        [self.tableView setContentOffset:CGPointMake(0, -75) animated:NO];
        [self.tableView.refreshTableHeaderView egoRefreshScrollViewDidEndDragging:self.tableView];
    }
}

#pragma mark -
#pragma mark Data Source Loading / Reloading Methods

- (void)didStartLoadingNewObjects
{
    //  should be calling your tableviews data source model to reload
    //  put here just for demo
    [self setIsReloading:YES];
    [self setLastUpdated:[NSDate date]];
}

- (void)didEndLoadingNewObjects
{
    //  model should call this when its done loading
    [self setIsReloading:NO];
    
	[self.tableView.refreshTableHeaderView egoRefreshScrollViewDataSourceDidFinishedLoading:self.tableView];
    
    CGRect frame = self.tableView.refreshTableFooterView.frame;
    frame.origin.y = self.tableView.contentSize.height;
    [self.tableView.refreshTableFooterView setFrame:frame];
    
    // [self.tableView setContentSize:CGSizeMake(self.tableView.contentSize.width, self.tableView.contentSize.height + 44.0f)];
}


#pragma mark -
#pragma mark UIScrollViewDelegate Methods

- (void)scrollViewWillBeginDecelerating:(UIScrollView *)scrollView
{
	point = scrollView.contentOffset;
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGPoint offset = scrollView.contentOffset;
    if (point.y < offset.y)
    {
        if (self.tableView.refreshTableFooterView.hidden)
        {
            return;
        }
        [self.tableView.refreshTableFooterView egoRefreshScrollViewDidScroll:scrollView];
    }
    else
    {
        [self.tableView.refreshTableHeaderView egoRefreshScrollViewDidScroll:scrollView];
    }
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
	CGPoint pt =scrollView.contentOffset;
	if (point.y < pt.y)
    {
		if (self.tableView.refreshTableFooterView.hidden)
        {
			return;
        }
		[self.tableView.refreshTableFooterView egoRefreshScrollViewDidEndDragging:scrollView];
    }
	else
    {
		[self.tableView.refreshTableHeaderView egoRefreshScrollViewDidEndDragging:scrollView];
    }
}

#pragma mark -
#pragma mark EGORefreshTableHeaderDelegate Methods

- (void)egoRefreshTableHeaderDidTriggerRefresh:(EGORefreshTableHeaderView*)view
{
    if ([self respondsToSelector:@selector(didStartLoadingNewObjects)])
    {
        [self performSelector:@selector(didStartLoadingNewObjects)];
    }
    
    // [self didStartLoadingNewObjects];
    // [self performSelector:@selector(doneLoadingTableViewData) withObject:nil afterDelay:3.0];
}

- (BOOL)egoRefreshTableHeaderDataSourceIsLoading:(EGORefreshTableHeaderView*)view
{
    // should return if data source model is reloading
	return [self isReloading];
}

- (NSDate *)egoRefreshTableHeaderDataSourceLastUpdated:(EGORefreshTableHeaderView*)view
{
    // should return date data source was last changed
	return self.lastUpdated ? self.lastUpdated : [NSDate date];
}

#pragma mark Data Source Loading / Reloading Methods

- (void)didStartLoadingMoreObjects
{
    // should be calling your tableviews data source model to reload
    // put here just for demo
    [self setIsReloading:YES];
}

- (void)didEndLoadingMoreObjects
{
    // model should call this when its done loading
	[self setIsReloading:NO];
	
    [self.tableView.refreshTableFooterView egoRefreshScrollViewDataSourceDidFinishedLoading:self.tableView];
    
    CGRect frame = self.tableView.refreshTableFooterView.frame;
    frame.origin.y = self.tableView.contentSize.height;
    [self.tableView.refreshTableFooterView setFrame:frame];
    
    // [self.tableView setContentSize:CGSizeMake(self.tableView.contentSize.width, self.tableView.contentSize.height+44.0f)];
}

#pragma mark EGORefreshTableHeaderDelegate Methods

- (BOOL)egoRefreshTableFootDataSourceIsLoading:(EGORefreshTableFooterView*)view
{
    // should return if data source model is reloading
	return self.isReloading;
}

- (void)egoRefreshTableFootDidTriggerRefresh:(EGORefreshTableFooterView*)view
{
    if ([self respondsToSelector:@selector(didStartLoadingMoreObjects)])
    {
        [self performSelector:@selector(didStartLoadingMoreObjects)];
    }
    
    // [self didStartLoadingMoreObjects];
    // [self performSelector:@selector(doneLoadingMoreTableViewData) withObject:nil afterDelay:3.0];
}
-(BOOL)useRetain
{
    return NO;
}

@end
