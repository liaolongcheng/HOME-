//
//  CABaseViewController.m
//  CACar
//
//  Created by 梁 珈瑞 on 13-8-14.
//  Copyright (c) 2013年 liaolongcheng. All rights reserved.
//

#import "CABaseViewController.h"

@interface CABaseViewController ()

@end

@implementation CABaseViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    //NSLog(@" %@ %@ ", NSStringFromClass([self class]), NSStringFromSelector(_cmd));
    [super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
//    self.automaticallyAdjustsScrollViewInsets=YES;
//    self.edgesForExtendedLayout=UIRectEdgeNone;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
