//
//  CABaseRefreshViewController.h
//  CACar
//
//  Created by 梁 珈瑞 on 13-8-14.
//  Copyright (c) 2013年 liaolongcheng. All rights reserved.
//

#import "CABaseTableViewController.h"

#import "UITableView+EGORefreshTableHeaderView.h"
#import "UITableView+EGORefreshTableFooterView.h"

@interface CABaseRefreshViewController : CABaseTableViewController<EGORefreshTableHeaderDelegate, EGORefreshTableFooterDelegate>
{
    CGPoint point;
}

@property (nonatomic, assign) BOOL isReloading;
@property (nonatomic, retain) NSDate *lastUpdated;

- (BOOL)usesRefreshHeaderView;
- (BOOL)usesRefreshFooterView;
- (BOOL)usesAutoRefresh;

- (void)addRefreshHeaderView;
- (void)addRefreshFooterView;
- (void)reloadData;

// call super implementation
- (void)didStartLoadingNewObjects;

// call super implementation
- (void)didEndLoadingNewObjects;

// call super implementation
- (void)didStartLoadingMoreObjects;

// call super implementation
- (void)didEndLoadingMoreObjects;

-(BOOL) useRetain;

@end
