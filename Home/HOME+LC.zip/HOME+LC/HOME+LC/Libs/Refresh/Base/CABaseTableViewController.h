//
//  CABaseTableViewController.h
//  CACar
//
//  Created by 梁 珈瑞 on 13-8-14.
//  Copyright (c) 2013年 liaolongcheng. All rights reserved.
//

#import "CABaseViewController.h"

@interface CABaseTableViewController : CABaseViewController<UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) IBOutlet UITableView *tableView;

@end
