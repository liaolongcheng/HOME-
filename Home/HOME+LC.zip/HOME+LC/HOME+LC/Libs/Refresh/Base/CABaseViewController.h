//
//  CABaseViewController.h
//  CACar
//
//  Created by 梁 珈瑞 on 13-8-14.
//  Copyright (c) 2013年 liaolongcheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CABaseViewController : UIViewController

@end
