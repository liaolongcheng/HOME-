<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html>
<head><title>404 Not Found</title></head>
<body bgcolor="white">
<h1>404 Not Found</h1>
<p>The requested URL was not found on this server. Sorry for the inconvenience.<br/>
Please report this message and include the following information to us.<br/>
Thank you very much!</p>
<table>
<tr>
<td>URL:</td>
<td>http://cdn.bang5mai.com/upload/plugin/js/main/b5m.main.js?v=20141018&amp;version=5.2.3&amp;uuid=c62143417efcbcfefc5ad4addafb7a42&amp;source=15083&amp;acd=3&amp;reason=19</td>
</tr>
<tr>
<td>Server:</td>
<td>linux-99-nginx107</td>
</tr>
<tr>
<td>Date:</td>
<td>2014/10/18 13:03:24</td>
</tr>
</table>
<hr/>Powered by Tengine</body>
</html>
